from _typeshed import Incomplete

__all__ = ['ModelError', 'ModelInputError']

class ModelError(RuntimeError):
    """A model failure with an explicit opt-in to retry from a saved boundary.

    retryable is a recovery hint, not a request to automatically retry. Providers
    must leave protocol, configuration and other permanent failures non-retryable.
    """
    retryable: Incomplete
    def __init__(self, message: str, *, retryable: bool = False) -> None: ...

class ModelInputError(ModelError, ValueError):
    """An explicitly rejected input, eligible for one pre-output adaptation.

    Providers must never use this for timeouts, rate limits, authentication,
    ambiguous failures, or context-length failures unrelated to attachments.
    """
    reason: Incomplete
    modalities: Incomplete
    status_code: Incomplete
    def __init__(self, reason: str, *, modalities=(), status_code=None) -> None: ...
