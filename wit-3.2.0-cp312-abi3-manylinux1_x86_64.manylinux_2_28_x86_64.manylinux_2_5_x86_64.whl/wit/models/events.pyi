from _typeshed import Incomplete
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Protocol
from wit.agents import InvocationContext
from wit.models.contracts import ModelEvent, ModelRequest, ModelResult
from wit.models.errors import ModelInputError

__all__ = ['MODEL', 'MODEL_CALL_AFTER_HOOK', 'MODEL_CALL_BEFORE_HOOK', 'MODEL_CALL_HOOK', 'MODEL_CALL_RECOVER_HOOK', 'ModelCallRecovery', 'ModelCallAfter', 'ModelCallBefore', 'ModelCallEvent', 'ModelService']

class ModelService(Protocol):
    async def complete(self, request: ModelRequest, invocation: InvocationContext) -> ModelResult: ...
    def stream(self, request: ModelRequest, invocation: InvocationContext) -> AsyncIterator[ModelEvent]: ...

@dataclass(frozen=True, slots=True)
class ModelCallEvent:
    """Information passed to a Model intercept handler as ``event``.

    Call ``await proceed()`` to continue the chain. Replace the request in a
    MODEL_CALL_BEFORE_HOOK handler; this event observes that effective request.
    """
    invocation: InvocationContext
    request: ModelRequest
    def __post_init__(self) -> None: ...

class ModelCallBefore:
    """Mutable request slot shared by Model call-before Hooks."""
    __slots__: Incomplete
    _invocation: Incomplete
    def __init__(self, invocation: InvocationContext, request: ModelRequest) -> None: ...
    @property
    def invocation(self) -> InvocationContext: ...
    @property
    def request(self) -> ModelRequest: ...
    _request: Incomplete
    @request.setter
    def request(self, value: ModelRequest) -> None: ...

class ModelCallAfter:
    """Mutable result slot shared by Model call-after Hooks."""
    __slots__: Incomplete
    _invocation: Incomplete
    _request: Incomplete
    def __init__(self, invocation: InvocationContext, request: ModelRequest, result: ModelResult) -> None: ...
    @property
    def invocation(self) -> InvocationContext: ...
    @property
    def request(self) -> ModelRequest: ...
    @property
    def result(self) -> ModelResult: ...
    _result: Incomplete
    @result.setter
    def result(self, value: ModelResult) -> None: ...

@dataclass(slots=True)
class ModelCallRecovery:
    """One opportunity to replace explicitly rejected input before any output.

    Set replacement to a new ModelRequest, or leave it None to propagate the
    original failure. This does not repeat the intercept continuation or tools.
    """
    invocation: InvocationContext
    request: ModelRequest
    error: ModelInputError
    replacement: ModelRequest | None = ...

MODEL: Incomplete
MODEL_CALL_BEFORE_HOOK: Incomplete
MODEL_CALL_HOOK: Incomplete
MODEL_CALL_AFTER_HOOK: Incomplete
MODEL_CALL_RECOVER_HOOK: Incomplete
