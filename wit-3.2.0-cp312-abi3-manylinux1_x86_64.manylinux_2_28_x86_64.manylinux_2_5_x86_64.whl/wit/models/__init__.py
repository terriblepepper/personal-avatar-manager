"""Provider-neutral model contracts and component API."""

# Import order is dependency order: contracts must exist before the component.
# ruff: noqa: I001

from wit.models.contracts import ModelEvent, ModelRequest, ModelResult
from wit.models.errors import ModelError, ModelInputError
from wit.models.events import (
    MODEL,
    MODEL_CALL_AFTER_HOOK,
    MODEL_CALL_BEFORE_HOOK,
    MODEL_CALL_HOOK,
    MODEL_CALL_RECOVER_HOOK,
    ModelCallRecovery,
    ModelCallAfter,
    ModelCallBefore,
    ModelCallEvent,
    ModelService,
)
from wit.models.component import BaseModelComponent

__all__ = (
    "MODEL",
    "MODEL_CALL_AFTER_HOOK",
    "MODEL_CALL_BEFORE_HOOK",
    "MODEL_CALL_HOOK",
    "MODEL_CALL_RECOVER_HOOK",
    "ModelCallRecovery",
    "ModelInputError",
    "BaseModelComponent",
    "ModelCallAfter",
    "ModelCallBefore",
    "ModelCallEvent",
    "ModelEvent",
    "ModelError",
    "ModelRequest",
    "ModelResult",
    "ModelService",
)
