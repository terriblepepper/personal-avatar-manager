from collections.abc import Mapping
from dataclasses import dataclass, field
from wit.conversation import AssistantMessage, Message, ToolCall
from wit.conversation.content import ContentPart
from wit.tools.definitions import ToolDescriptor

__all__ = ['ModelEvent', 'ModelRequest', 'ModelResult']

@dataclass(frozen=True, slots=True)
class ModelRequest:
    """Provider-neutral messages, Tools, and options for one model call."""
    messages: tuple[Message, ...]
    tools: tuple[ToolDescriptor, ...] = ...
    options: Mapping[str, object] = field(default_factory=dict)
    metadata: Mapping[str, object] = field(default_factory=dict)
    def __post_init__(self) -> None: ...

@dataclass(frozen=True, slots=True)
class ModelResult:
    """Final provider-neutral output from one model call."""
    message: AssistantMessage
    finish_reason: str | None = ...
    metadata: Mapping[str, object] = field(default_factory=dict)
    def __post_init__(self) -> None: ...
    @property
    def output_parts(self) -> tuple[ContentPart, ...]: ...
    @property
    def final_text(self) -> str: ...
    @property
    def reasoning_text(self) -> str: ...
    @property
    def tool_calls(self) -> tuple[ToolCall, ...]: ...

@dataclass(frozen=True, slots=True)
class ModelEvent:
    """One incremental or terminal event from a model call."""
    kind: str
    data: object = ...
    result: ModelResult | None = ...
    metadata: Mapping[str, object] = field(default_factory=dict)
    def __post_init__(self) -> None: ...
    @property
    def is_terminal(self) -> bool: ...
    @classmethod
    def final(cls, result: ModelResult) -> ModelEvent: ...
