from _typeshed import Incomplete
from collections.abc import AsyncIterator
from typing import final
from wit.agents.execution import ActiveCallTracker
from wit.agents.invocation import InvocationContext
from wit.components import Context
from wit.components.component import WitComponent
from wit.models.contracts import ModelEvent, ModelRequest, ModelResult

__all__ = ['BaseModelComponent']

class _ModelServiceAdapter:
    """Framework-owned Model Service boundary around one Provider."""
    __slots__: Incomplete
    _provider: Incomplete
    def __init__(self, provider: BaseModelComponent) -> None: ...
    async def complete(self, request: ModelRequest, invocation: InvocationContext) -> ModelResult: ...
    def stream(self, request: ModelRequest, invocation: InvocationContext) -> AsyncIterator[ModelEvent]: ...

class BaseModelComponent(WitComponent[object]):
    """Lifecycle and Hook shell around one provider-defined model stream."""
    provides: Incomplete
    def __init_subclass__(cls, **kwargs: object) -> None: ...
    _model_context: Context | None
    _model_calls: ActiveCallTracker | None
    def __init__(self) -> None: ...
    async def setup(self, ctx: Context) -> None: ...
    async def teardown(self, ctx: Context) -> None: ...
    async def setup_model(self, ctx: Context) -> None:
        """Acquire SDK clients or credentials during component setup."""
    async def teardown_model(self, ctx: Context) -> None:
        """Release provider resources during component teardown."""
    @final
    async def complete(self, request: ModelRequest, invocation: InvocationContext) -> ModelResult: ...
    @final
    async def stream(self, request: ModelRequest, invocation: InvocationContext) -> AsyncIterator[ModelEvent]: ...
    async def _run(self, request: ModelRequest, invocation: InvocationContext, *, streaming: bool) -> AsyncIterator[ModelEvent]: ...
    @final
    def _streaming_requested(self) -> bool:
        """Tell the provider flow which public MODEL operation owns this call."""
    async def _stream(self, request: ModelRequest, invocation: InvocationContext) -> AsyncIterator[ModelEvent]:
        """Convert one public request into provider events and one terminal result."""
    def _require_model_context(self) -> Context: ...
    def _require_model_tracker(self) -> ActiveCallTracker: ...
