import abc
from abc import ABC, abstractmethod
from wit.acps.amp.records import AmpRecord

__all__ = ['BaseAmpStore']

class BaseAmpStore(ABC, metaclass=abc.ABCMeta):
    """Replaceable storage boundary for complete AMP records.

    The emitter implementation owns ``open``/``close`` and awaits ``append`` directly; stores
    do not sign records, dispatch them, or add a Journal/Output layer. Implementers
    must document their persistence and concurrency guarantees.
    Choosing an ephemeral store does not provide durable Audit evidence.
    """
    @abstractmethod
    async def open(self) -> None:
        """Prepare storage before any append; repeated calls while open are harmless.

        Raise AmpPersistenceError when the backend cannot be prepared. On failure,
        release resources acquired by this call; the emitter cannot close a store
        whose open failed.
        """
    @abstractmethod
    async def append(self, record: AmpRecord) -> None:
        """Accept one complete record, preserving its identity, body and integrity.

        Normal return means the full record has reached the implementation's
        documented storage boundary, not merely an uncommitted background queue.
        Serialize concurrent appends within the supported concurrency scope so
        records cannot interleave. Raise AmpPersistenceError if storage is closed
        or persistence fails, and TypeError for a non-AmpRecord argument. Never
        silently drop a record or suppress cancellation. A failure or cancellation
        may leave a committed record; this contract does not promise exactly-once
        retries or rollback. Audit signing belongs to the emitter, which propagates
        append failures as AmpAuditError.
        """
    @abstractmethod
    async def close(self) -> None:
        """Finish pending storage work and release resources; safe to repeat.

        Coordinate with in-flight appends and reject new appends until reopened.
        Raise AmpPersistenceError on a storage finalization failure. Previously
        acknowledged records retain the persistence guarantee of this backend.
        """
