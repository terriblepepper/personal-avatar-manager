from typing import Protocol
from wit.acps.amp.records import AmpIntegrity
from wit.acps.identity.models import ActiveIdentity

__all__ = ['AmpSigner']

class AmpSigner(Protocol):
    async def sign(self, canonical_record: bytes, identity: ActiveIdentity) -> AmpIntegrity: ...
