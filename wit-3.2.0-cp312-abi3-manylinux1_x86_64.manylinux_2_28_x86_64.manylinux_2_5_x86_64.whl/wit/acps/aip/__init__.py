"""AIP component calling context. Protocol payloads are ordinary mappings."""

from wit.acps.aip.base import AipContext

__all__ = ("AipContext",)
