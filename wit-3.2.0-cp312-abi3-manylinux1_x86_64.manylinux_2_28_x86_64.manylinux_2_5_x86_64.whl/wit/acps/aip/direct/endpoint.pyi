from _typeshed import Incomplete
from collections.abc import AsyncIterator, Mapping
from typing import Protocol
from wit.acps.aip._operations import managed_call, managed_stream
from wit.acps.aip.base import AipContext, _AipComponent
from wit.acps.identity.entity import LocalEntity, VerifiedPeer
from wit.components import Context

__all__ = ['DIRECT_PARTNER', 'DIRECT_PARTNER_ENDPOINT', 'BaseDirectPartnerComponent', 'DirectPartnerEndpoint']

class DirectPartnerEndpoint(Protocol):
    server_name: str
    base_path: str
    public_endpoint: str
    async def deliver_asgi(self, scope, receive, send, *, entity: LocalEntity, peer: VerifiedPeer, tls_server_name: str | None) -> None: ...

DIRECT_PARTNER_ENDPOINT: Incomplete
DIRECT_PARTNER: Incomplete

class BaseDirectPartnerComponent(_AipComponent):
    """Implement _handle(command, *, context); install only this subclass.

    The ASGI endpoint is included. Pass a configured listener component to own a
    socket, or mount deliver_asgi on an existing authenticated transport. Merely
    installing a handler does not invent certificates or network configuration.
    """
    name: str
    provides: Incomplete
    _public_methods: Incomplete
    server_name: Incomplete
    base_path: Incomplete
    public_endpoint: Incomplete
    listener: Incomplete
    max_body_bytes: Incomplete
    def __init__(self, *, server_name: str = 'localhost', base_path: str = '', public_endpoint: str | None = None, listener=None, max_body_bytes: int = ...) -> None: ...
    async def _mount(self, ctx: Context) -> None: ...
    def _command(self, command, context, *, stream: bool = False): ...
    @managed_call
    async def handle(self, command: Mapping[str, object], *, context: AipContext) -> Mapping[str, object]: ...
    async def _handle(self, command: Mapping[str, object], *, context: AipContext) -> Mapping[str, object]: ...
    @managed_stream
    async def handle_stream(self, command: Mapping[str, object], *, context: AipContext) -> AsyncIterator[Mapping[str, object]]: ...
    async def _handle_stream(self, command: Mapping[str, object], *, context: AipContext) -> AsyncIterator[Mapping[str, object]]: ...
    def _transport_context(self, peer_aic, peer, headers): ...
    async def handle_rpc(self, request: Mapping[str, object], *, peer_aic: str, headers: Mapping[str, str] | None = None, peer: VerifiedPeer | None = None): ...
    async def stream_rpc(self, request: Mapping[str, object], *, peer_aic: str, headers: Mapping[str, str] | None = None, peer: VerifiedPeer | None = None): ...
    @managed_call
    async def handle_notification(self, request: Mapping[str, object], *, peer_aic: str, headers: Mapping[str, str] | None = None, peer: VerifiedPeer | None = None): ...
    async def _set_notification(self, params, *, context) -> None: ...
    async def _get_notification(self, params, *, context) -> None: ...
    async def _delete_notification(self, params, *, context) -> None: ...
    async def _start_task_with_notification(self, command, *, context) -> None: ...
    async def deliver_asgi(self, scope, receive, send, *, entity: LocalEntity, peer: VerifiedPeer, tls_server_name: str | None) -> None:
        """Trusted TLS handoff with a pinned entity and the actual, optional SNI."""
    async def asgi_app(self, scope, receive, send) -> None:
        """Untrusted ASGI mount: no scope/header field can create a verified Peer."""
    async def _asgi_app(self, scope, receive, send, *, peer_aic: str | None, peer: VerifiedPeer | None) -> None: ...
