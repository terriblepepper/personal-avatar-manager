from _typeshed import Incomplete
from typing import Protocol
from wit.components import Context as Context, ServiceKey as ServiceKey, WitComponent as WitComponent

class MtlsServer(Protocol):
    @property
    def serving(self) -> bool: ...
    @property
    def port(self) -> int: ...
    async def close_admission(self) -> None: ...
    async def drain(self) -> None: ...
    async def stop(self) -> None:
        """Close admission, drain work and release resources; safe to repeat."""

DIRECT_MTLS_SERVER: Incomplete

class BaseAipListenerComponent(WitComponent[object]):
    """Publish an injected listener and own its shutdown through component effects.

    Implementations own authenticated connection admission, HTTP handling and
    trusted Endpoint delivery. Failed acquisition must roll back its resources.
    This base does not create sockets or choose a server implementation.
    """
    name: str
    provides: Incomplete
    async def _open_listener(self, ctx: Context) -> MtlsServer: ...
    async def setup(self, ctx: Context) -> None: ...
