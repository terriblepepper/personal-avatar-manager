from dataclasses import dataclass
from typing import Protocol

__all__ = ['GroupSubscription', 'GroupSubscriptionStore']

@dataclass(frozen=True, slots=True)
class GroupSubscription:
    local_aic: str
    leader_aic: str
    group_id: str
    def __post_init__(self) -> None: ...

class GroupSubscriptionStore(Protocol):
    """Durable binding intents; pages are ordered by group_id within one entity."""
    async def put(self, subscription: GroupSubscription) -> None: ...
    async def page(self, local_aic: str, *, after_group_id: str | None, limit: int) -> tuple[GroupSubscription, ...]: ...
