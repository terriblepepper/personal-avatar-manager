class GroupAdmissionError(ValueError):
    """Transport established that wire data or authority is invalid; reject permanently."""
class GroupReceiverUnavailable(ValueError):
    """An admitted queue has no active receiver; pause consumption and requeue."""
