from collections.abc import Mapping
from dataclasses import dataclass
from enum import StrEnum

__all__ = ['GroupCommandType', 'GroupConflictError', 'GroupOperation', 'GroupOperationResult', 'GroupOutboxMessage', 'GroupRecord', 'GroupState']

class GroupState(StrEnum):
    ACTIVE = 'active'
    DISSOLVED = 'dissolved'

class GroupCommandType(StrEnum):
    CREATE = 'create'
    INVITE = 'invite'
    JOIN = 'join'
    LEAVE = 'leave'
    DISSOLVE = 'dissolve'

@dataclass(frozen=True, slots=True)
class GroupRecord:
    group_id: str
    name: str
    creator_aic: str
    members: tuple[str, ...]
    state: GroupState = ...
    local_aic: str | None = ...
    version: int = ...

class GroupConflictError(ValueError):
    """The persisted Group version or command key changed concurrently."""

@dataclass(frozen=True, slots=True)
class GroupOperation:
    command_id: str
    type: GroupCommandType
    group_id: str | None = ...
    name: str | None = ...
    member_aic: str | None = ...
    members: tuple[str, ...] = ...
    def __post_init__(self) -> None: ...

@dataclass(frozen=True, slots=True)
class GroupOperationResult:
    command_id: str
    group: GroupRecord
    command: GroupOperation | None = ...

@dataclass(frozen=True, slots=True)
class GroupOutboxMessage:
    message_id: str
    group_id: str
    payload: Mapping[str, object]
    local_aic: str | None = ...
    def __post_init__(self) -> None: ...
