from collections.abc import Awaitable, Callable, Mapping
from typing import Literal, Protocol
from wit.acps.aip.base import AipContext

__all__ = ['GroupTransport']

Receiver = Callable[..., Awaitable[None]]
Membership = Callable[[str, str], Awaitable[Mapping[str, object] | None]]
Authorization = Callable[..., Awaitable[bool]]

class GroupTransport(Protocol):
    """Authenticated adapter. Each attach returns an idempotent async release.

    Implementations own partial-start rollback and shared resource lifetime.
    Receivers get complete wire messages and an independently admitted context.
    Publication confirms only transport submission, never remote completion.
    """
    async def attach(self, receiver: Receiver, *, role: Literal['leader', 'partner']) -> Callable[[], Awaitable[None]]: ...
    async def publish(self, payload: Mapping[str, object], *, context: AipContext) -> None: ...
    async def bind_group(self, local_aic: str, group_id: str) -> None: ...
