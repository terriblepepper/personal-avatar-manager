from _typeshed import Incomplete
from collections.abc import Mapping
from dataclasses import dataclass, field
from wit.acps.aip._operations import AipOperations as AipOperations
from wit.components import Context as Context, WitComponent as WitComponent

@dataclass(frozen=True, slots=True)
class AipContext:
    """Authority supplied by a trusted transport or explicitly authorizing application.

    Never construct this from an untrusted message's senderId. Transport adapters
    bind peer_aic to the TLS certificate or broker user_id, and local_aic to an
    admitted local entity. Group adapters additionally authorize group membership.
    This is calling context, not a protocol message or persisted task scope.
    """
    local_aic: str
    peer_aic: str
    group_id: str | None = ...
    leader_aic: str | None = ...
    headers: Mapping[str, str] = field(default_factory=dict)
    def __post_init__(self) -> None: ...

class _AipComponent(WitComponent[object]):
    """Own dispatch admission, calls, streams and resource hooks per activation."""
    _public_methods: tuple[str, ...]
    def __init_subclass__(cls, **kwargs) -> None: ...
    _context: Incomplete
    _operations: Incomplete
    async def setup(self, ctx: Context) -> None: ...
    async def teardown(self, ctx: Context) -> None: ...
    async def _setup(self, ctx: Context) -> None:
        """Acquire resources with ctx.effect() for rollback on partial setup."""
    async def _mount(self, ctx: Context) -> None:
        """Internal transport composition hook, after service publication."""
    async def _teardown(self, ctx: Context) -> None:
        """Called after active calls and streams have settled."""
    def _require_active(self) -> Context: ...
