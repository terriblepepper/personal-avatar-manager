"""ACPS identity models, entity selection, ACS, and certificate validation."""

from typing import TYPE_CHECKING

from wit.acps.identity.acs import (
    validate_registration_candidate_acs,
    validate_registry_acs,
)
from wit.acps.identity.models import (
    ACTIVE_IDENTITY,
    IDENTITY,
    AcpsContractError,
    AcsDriftError,
    AcsSnapshot,
    ActiveIdentity,
    IdentityControl,
    IdentityMaterial,
    IdentityMaterialVerifier,
    IdentityState,
    IdentityStatus,
)

if TYPE_CHECKING:
    from wit.acps.identity.entity import (
        CertificateIdentityError,
        EntityDirectory,
        LocalEntity,
        VerifiedPeer,
        current_admitted_entity,
        current_local_entity,
        peer_aic_from_certificate,
        select_admitted_entity,
        use_admitted_local_entity,
        use_local_entity,
    )

__all__ = (
    "ACTIVE_IDENTITY",
    "IDENTITY",
    "AcpsContractError",
    "AcsDriftError",
    "AcsSnapshot",
    "ActiveIdentity",
    "CertificateIdentityError",
    "EntityDirectory",
    "IdentityControl",
    "IdentityMaterial",
    "IdentityMaterialVerifier",
    "IdentityState",
    "IdentityStatus",
    "LocalEntity",
    "VerifiedPeer",
    "current_admitted_entity",
    "current_local_entity",
    "peer_aic_from_certificate",
    "select_admitted_entity",
    "use_admitted_local_entity",
    "use_local_entity",
    "validate_registration_candidate_acs",
    "validate_registry_acs",
)


def __getattr__(name: str) -> object:
    entity_names = {
        "CertificateIdentityError",
        "EntityDirectory",
        "LocalEntity",
        "VerifiedPeer",
        "current_admitted_entity",
        "current_local_entity",
        "peer_aic_from_certificate",
        "select_admitted_entity",
        "use_admitted_local_entity",
        "use_local_entity",
    }
    if name in entity_names:
        from wit.acps.identity import entity

        return getattr(entity, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
