from _typeshed import Incomplete
from datetime import datetime

__all__ = ['CertificateValidationError', 'validate_certificate_material', 'validate_single_certificate']

class CertificateValidationError(RuntimeError):
    """A certificate material validation check failed."""
    reason: Incomplete
    def __init__(self, reason: str) -> None: ...

def validate_certificate_material(*, aic: str, client_certificate_pem: bytes, client_private_key_pem: bytes, server_certificate_pem: bytes, server_private_key_pem: bytes, trust_bundle_pem: bytes, public_endpoint: str | None = None, now: datetime | None = None) -> None:
    """Full dual-certificate validation: CN, SAN, EKU, chain, key binding.

    Raises ``CertificateValidationError`` on the first failed check.
    """
def validate_single_certificate(*, side: CertificateSide, aic: str, certificate_pem: bytes, private_key_pem: bytes, trust_bundle_pem: bytes, now: datetime | None = None) -> None:
    """Validate a single certificate (client OR server) against the trust bundle.

    This is useful when validating certificates independently — e.g. when the
    pipeline issues them one at a time via CLI.
    """
