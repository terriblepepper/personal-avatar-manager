from _typeshed import Incomplete
from collections.abc import Mapping
from typing import Any

__all__ = ['REGISTRATION_CANDIDATE_LAST_MODIFIED_TIME', 'REGISTRY_ACS_PROTOCOL_VERSION', 'AcsContractError', 'validate_registration_candidate_acs', 'validate_registry_acs']

REGISTRY_ACS_PROTOCOL_VERSION: str
REGISTRATION_CANDIDATE_LAST_MODIFIED_TIME: str

class AcsContractError(ValueError):
    """A path-addressed ACS v02.02 contract violation."""
    path: Incomplete
    message: Incomplete
    def __init__(self, path: str, message: str) -> None: ...

def validate_registry_acs(acs: Mapping[str, Any], *, path: str = '$') -> None:
    """Validate the projected ACS v02.02 contract without applying defaults."""
def validate_registration_candidate_acs(acs: Mapping[str, Any]) -> None:
    """Validate an unchanged developer candidate against the Registry contract."""
