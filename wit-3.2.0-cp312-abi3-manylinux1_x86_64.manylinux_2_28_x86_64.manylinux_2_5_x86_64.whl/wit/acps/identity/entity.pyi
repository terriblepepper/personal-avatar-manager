import ssl
from collections.abc import Iterator
from contextlib import AbstractContextManager, contextmanager
from dataclasses import dataclass, field
from typing import Protocol
from wit.acps.identity.models import ActiveIdentity, IdentityMaterial

__all__ = ['CertificateIdentityError', 'EntityDirectory', 'LocalEntity', 'VerifiedPeer', 'current_local_entity', 'peer_aic_from_certificate', 'use_local_entity']

class CertificateIdentityError(ValueError):
    """A TLS certificate has no usable AIP AIC or contradictory identity."""

def peer_aic_from_certificate(der: bytes | None) -> str:
    """Read AIP identity from a TLS verified certificate (DER)."""

@dataclass(frozen=True, slots=True)
class VerifiedPeer:
    """Peer identity obtained only from a TLS stack that required client auth."""
    aic: str
    _certificate_der: bytes = field(repr=False)
    @classmethod
    def from_tls(cls, ssl_object: ssl.SSLObject | ssl.SSLSocket) -> VerifiedPeer: ...

@dataclass(frozen=True, slots=True)
class LocalEntity:
    """Selection made by trusted product authorization or TLS SNI admission."""
    aic: str
    material: IdentityMaterial = field(repr=False)
    generation: int = ...
    hostname: str = ...
    def __post_init__(self) -> None: ...
    def active_identity(self) -> ActiveIdentity: ...
    @property
    def checkpoint_namespace(self) -> str: ...
    def bind(self) -> AbstractContextManager[None]: ...

def current_local_entity() -> LocalEntity | None: ...
@contextmanager
def use_local_entity(entity: LocalEntity) -> Iterator[None]:
    """Bind an already authorized selection to this asynchronous call tree."""

class EntityDirectory(Protocol):
    async def select(self, aic: str) -> LocalEntity: ...
