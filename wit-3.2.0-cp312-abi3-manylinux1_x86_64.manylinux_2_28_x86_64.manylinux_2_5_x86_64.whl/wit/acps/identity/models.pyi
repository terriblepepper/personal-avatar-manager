from _typeshed import Incomplete
from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Protocol

__all__ = ['ACTIVE_IDENTITY', 'IDENTITY', 'AcpsContractError', 'AcsDriftError', 'AcsSnapshot', 'ActiveIdentity', 'IdentityControl', 'IdentityMaterial', 'IdentityMaterialVerifier', 'IdentityState', 'IdentityStatus']

class AcpsContractError(ValueError):
    """An ACPS document or transition violates its public contract."""
class AcsDriftError(AcpsContractError):
    """The current ACS declarations differ from the committed snapshot."""

@dataclass(frozen=True, slots=True)
class AcsSnapshot:
    document: Mapping[str, object]
    fingerprint: str
    created_at: datetime

class IdentityState(StrEnum):
    UNAVAILABLE = 'unavailable'
    VALIDATING = 'validating'
    ACTIVE = 'active'
    FAILED = 'failed'

@dataclass(frozen=True, slots=True)
class IdentityStatus:
    phase: IdentityState
    aic: str | None = ...
    reason: str | None = ...
    updated_at: datetime = field(default_factory=Incomplete)

@dataclass(frozen=True, slots=True)
class IdentityMaterial:
    aic: str
    certificate: str
    private_key: str
    trust_bundle: str
    acs_fingerprint: str
    server_certificate: str = ...
    server_private_key: str = ...

@dataclass(slots=True)
class ActiveIdentity:
    """Stable Service object made visible only while verified and active."""
    aic: str = ...
    certificate: str = ...
    private_key: str = ...
    trust_bundle: str = ...
    acs_fingerprint: str = ...
    server_certificate: str = ...
    server_private_key: str = ...

class IdentityControl(Protocol):
    @property
    def state(self) -> IdentityStatus: ...
    async def invalidate(self, reason: str) -> None: ...

IDENTITY: Incomplete
ACTIVE_IDENTITY: Incomplete

class IdentityMaterialVerifier(Protocol):
    """Validate certificate/key/trust/AIC binding outside the framework core."""
    async def verify(self, material: IdentityMaterial, candidate: AcsSnapshot) -> None: ...
