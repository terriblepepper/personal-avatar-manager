from _typeshed import Incomplete
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import datetime
from typing import Protocol
from wit.acps.identity.models import ActiveIdentity

__all__ = ['DISCOVERY', 'DiscoveredAgent', 'Discovery', 'DiscoveryProvider', 'DiscoveryRequest', 'DiscoveryResult']

@dataclass(frozen=True, slots=True)
class DiscoveryRequest:
    query: str = ...
    limit: int = ...
    filters: Mapping[str, object] | None = ...
    mode: str = ...
    context: Mapping[str, object] | None = ...
    forward_depth_limit: int | None = ...
    forward_fanout_limit: int | None = ...
    def __post_init__(self) -> None: ...

@dataclass(frozen=True, slots=True)
class DiscoveredAgent:
    aic: str
    skill_id: str
    ranking: int
    acs: Mapping[str, object]

@dataclass(frozen=True, slots=True)
class DiscoveryResult:
    agents: tuple[DiscoveredAgent, ...]
    acs_map: Mapping[str, Mapping[str, object]]
    fetched_at: datetime
    fresh_until: datetime | None
    groups: tuple[Mapping[str, object], ...] = ...
    route: Mapping[str, object] | None = ...

class DiscoveryProvider(Protocol):
    async def discover(self, request: DiscoveryRequest, identity: ActiveIdentity) -> Mapping[str, object]: ...

class Discovery(Protocol):
    async def discover(self, request: DiscoveryRequest) -> DiscoveryResult: ...

DISCOVERY: Incomplete
