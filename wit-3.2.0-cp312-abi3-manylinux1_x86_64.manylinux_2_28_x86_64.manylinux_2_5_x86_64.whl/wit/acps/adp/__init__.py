"""Agent Discovery Protocol service contracts."""

from wit.acps.adp.contracts import (
    DISCOVERY,
    DiscoveredAgent,
    Discovery,
    DiscoveryProvider,
    DiscoveryRequest,
    DiscoveryResult,
)

__all__ = (
    "DISCOVERY",
    "DiscoveredAgent",
    "Discovery",
    "DiscoveryProvider",
    "DiscoveryRequest",
    "DiscoveryResult",
)
