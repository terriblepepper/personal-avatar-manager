"""Agent Communication Protocol Stack domains."""

__all__: tuple[str, ...] = ()
