from _typeshed import Incomplete
from dataclasses import dataclass
from typing import Literal, Protocol

__all__ = ['TRUSTED_CERTIFICATES', 'CertificateInstance', 'CertificateIssueRequest', 'CertificateOperationResult', 'CertificateRenewRequest', 'CertificateRevokeRequest', 'CertificateUsage', 'TrustedCertificates']

type CertificateUsage = Literal['client', 'server']
@dataclass(frozen=True, slots=True)
class CertificateIssueRequest:
    aic: str
    usage: CertificateUsage
    key_compromised: bool = ...

@dataclass(frozen=True, slots=True)
class CertificateRenewRequest:
    aic: str
    usages: tuple[CertificateUsage, ...] = ...
    key_compromised: bool = ...

@dataclass(frozen=True, slots=True)
class CertificateRevokeRequest:
    aic: str
    usage: CertificateUsage
    generation: int
    fingerprint: str
    reason: int = ...

@dataclass(frozen=True, slots=True)
class CertificateInstance:
    aic: str
    usage: CertificateUsage
    generation: int
    fingerprint: str
    serial: str
    status: str

@dataclass(frozen=True, slots=True)
class CertificateOperationResult:
    operation: Literal['issue', 'renew', 'revoke']
    status: str
    aic: str
    usage: CertificateUsage | None = ...
    generation: int | None = ...
    fingerprint: str | None = ...
    serial: str | None = ...
    reason: int | None = ...
    instances: tuple[CertificateInstance, ...] = ...

class TrustedCertificates(Protocol):
    @property
    def certificates(self) -> tuple[CertificateInstance, ...]: ...
    async def issue(self, request: CertificateIssueRequest) -> CertificateOperationResult: ...
    async def renew(self, request: CertificateRenewRequest) -> CertificateOperationResult: ...
    async def revoke(self, request: CertificateRevokeRequest) -> CertificateOperationResult: ...

TRUSTED_CERTIFICATES: Incomplete
