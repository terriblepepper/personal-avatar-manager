from _typeshed import Incomplete
from collections.abc import Mapping
from wit.acps.identity.acs import REGISTRATION_CANDIDATE_LAST_MODIFIED_TIME as REGISTRATION_CANDIDATE_LAST_MODIFIED_TIME

_ENTITY_RECORD_FIELDS: Incomplete

def inherit_entity_acs(document: Mapping[str, object], ontology: Mapping[str, object], *, candidate: bool = False) -> dict[str, object]:
    """Copy missing object keys; preserve explicit values and whole arrays.

    Registry identity/status/timestamps and entity-specific metadata are never
    borrowed from the ontology. A final entity name is Registry-derived too.
    """
def _fill_missing(document: Mapping[str, object], defaults: Mapping[str, object]) -> dict[str, object]: ...
def _copy_value(value: object) -> object: ...
