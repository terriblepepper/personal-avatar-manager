from _typeshed import Incomplete
from collections.abc import Mapping
from wit.acps.atr.client import AtrConfig
from wit.acps.atr.component import TrustedRegistrationComponent
from wit.acps.identity import LocalEntity

__all__ = ['AtrEntityDirectory']

class AtrEntityDirectory:
    """Load explicitly registered ATR directories on demand; CA status is checked afresh."""
    _registrations: Incomplete
    def __init__(self, registrations: Mapping[str, AtrConfig | TrustedRegistrationComponent]) -> None: ...
    async def select(self, aic: str) -> LocalEntity: ...
