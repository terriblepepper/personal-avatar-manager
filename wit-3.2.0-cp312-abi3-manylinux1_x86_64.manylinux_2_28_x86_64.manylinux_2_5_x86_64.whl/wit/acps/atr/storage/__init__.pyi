from ._posix import PrivateDirectory as PrivateDirectory, _try_lock as _try_lock
from contextlib import contextmanager
from pathlib import Path

class CommitUncertainError(OSError):
    """Publication succeeded, but its final durability check failed; reload required."""

def lock_file(fd: int, *, blocking: bool = True, timeout: float | None = None) -> None:
    """Exclusive process lock, released by unlock or closing the descriptor.

    Nonblocking contention raises BlockingIOError. A finite timeout raises
    TimeoutError. Unbounded waits retry until acquired; OS errors propagate.
    Polling keeps these semantics identical for flock and LockFileEx.
    """
def atomic_write(directory: PrivateDirectory, name: str, data: bytes) -> None:
    """Flush a private temporary inode, publish, then sync the storage boundary."""
@contextmanager
def temporary_secrets(values: list[bytes], *, parent: Path | None = None):
    """Keep private files and their directory pinned through the consumer's load.

    Cleanup covers partial writes and consumer exceptions. A hard process kill
    can leave private files behind; their creation permissions still apply.
    """
def read_at(fd: int, length: int, offset: int) -> bytes:
    """Positioned read; callers own the exclusive lock and descriptor."""
