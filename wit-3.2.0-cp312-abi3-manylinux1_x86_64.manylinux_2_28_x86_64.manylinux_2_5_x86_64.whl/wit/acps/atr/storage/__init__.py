"""Private local storage for Framework identities, audit logs and TLS material.

Locks cover cooperating processes (not hostile code running as the same user).
Never use these primitives to implement a Harness sandbox.
"""

from __future__ import annotations

import errno
import math
import os
import tempfile
import time
import uuid
from contextlib import contextmanager
from pathlib import Path

if os.name == "nt":
    from ._windows import PrivateDirectory, _try_lock
    from ._windows import unlock_file as unlock_file
else:
    from ._posix import PrivateDirectory, _try_lock
    from ._posix import unlock_file as unlock_file

from ._errors import PathChangedError as PathChangedError


class CommitUncertainError(OSError):
    """Publication succeeded, but its final durability check failed; reload required."""


def lock_file(fd: int, *, blocking: bool = True, timeout: float | None = None) -> None:
    """Exclusive process lock, released by unlock or closing the descriptor.

    Nonblocking contention raises BlockingIOError. A finite timeout raises
    TimeoutError. Unbounded waits retry until acquired; OS errors propagate.
    Polling keeps these semantics identical for flock and LockFileEx.
    """
    if timeout is not None and (not math.isfinite(timeout) or timeout < 0):
        raise ValueError("lock timeout must be finite and nonnegative")
    if not blocking and timeout is not None:
        raise ValueError("nonblocking locks do not accept a timeout")
    deadline = None if timeout is None else time.monotonic() + timeout
    while True:
        try:
            _try_lock(fd)
            return
        except BlockingIOError:
            if not blocking:
                raise
            if deadline is not None and time.monotonic() >= deadline:
                raise TimeoutError("private file lock is busy") from None
            time.sleep(0.02)


def atomic_write(directory: PrivateDirectory, name: str, data: bytes) -> None:
    """Flush a private temporary inode, publish, then sync the storage boundary."""
    temporary = f".pending-{uuid.uuid4().hex}"
    fd = directory.open(temporary, create=True, exclusive=True)
    published = False
    try:
        try:
            try:
                view = memoryview(data)
                while view:
                    count = os.write(fd, view)
                    if count <= 0:
                        raise OSError(errno.EIO, "short private file write")
                    view = view[count:]
                os.fsync(fd)
                directory.validate(fd, temporary)
            finally:
                os.close(fd)
            directory.replace(temporary, name)
            published = True
            directory.sync()
        finally:
            directory.unlink(temporary, missing_ok=True)
    except BaseException as error:
        if published:
            raise CommitUncertainError("state published but durability is uncertain") from error
        raise


@contextmanager
def temporary_secrets(values: list[bytes], *, parent: Path | None = None):
    """Keep private files and their directory pinned through the consumer's load.

    Cleanup covers partial writes and consumer exceptions. A hard process kill
    can leave private files behind; their creation permissions still apply.
    """
    root = Path(tempfile.gettempdir()) if parent is None else Path(parent)
    path = root / f"wit-tls-{uuid.uuid4().hex}"
    directory = PrivateDirectory(path, create=True, exclusive=True)
    descriptors: list[int] = []
    names: list[str] = []
    try:
        paths = []
        for index, value in enumerate(values):
            name = f"secret-{index}.pem"
            names.append(name)
            fd = directory.open(name, create=True, exclusive=True, shared_write=False)
            descriptors.append(fd)
            view = memoryview(value)
            while view:
                count = os.write(fd, view)
                if count <= 0:
                    raise OSError(errno.EIO, "short temporary secret write")
                view = view[count:]
            os.fsync(fd)
            paths.append(directory.path / name)
        yield paths
    finally:
        errors: list[BaseException] = []
        for fd in descriptors:
            try:
                os.close(fd)
            except BaseException as error:  # noqa: BLE001 - finish cleanup, then re-raise all
                errors.append(error)
        for name in names:
            try:
                directory.unlink(name, missing_ok=True)
            except BaseException as error:  # noqa: BLE001 - finish cleanup, then re-raise all
                errors.append(error)
        try:
            directory.close()
        except BaseException as error:  # noqa: BLE001 - finish cleanup, then re-raise all
            errors.append(error)
        try:
            path.rmdir()
        except BaseException as error:  # noqa: BLE001 - finish cleanup, then re-raise all
            errors.append(error)
        if errors:
            raise BaseExceptionGroup("temporary secret cleanup failed", errors)


def read_at(fd: int, length: int, offset: int) -> bytes:
    """Positioned read; callers own the exclusive lock and descriptor."""
    if hasattr(os, "pread"):
        return os.pread(fd, length, offset)
    os.lseek(fd, offset, os.SEEK_SET)
    return os.read(fd, length)
