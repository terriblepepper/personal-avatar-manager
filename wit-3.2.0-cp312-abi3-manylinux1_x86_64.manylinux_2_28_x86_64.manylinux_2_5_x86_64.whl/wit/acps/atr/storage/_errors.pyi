class PathChangedError(PermissionError):
    """The opened inode no longer occupies the requested path; reopen required."""
