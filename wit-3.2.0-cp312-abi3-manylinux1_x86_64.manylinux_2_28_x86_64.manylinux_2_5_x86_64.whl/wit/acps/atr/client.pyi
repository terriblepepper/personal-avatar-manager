import httpx
from _typeshed import Incomplete
from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal
from wit.acps.atr.contracts import RegistrationReview
from wit.acps.identity.models import AcsSnapshot, IdentityMaterial

__all__ = ['AtrConfig', 'AtrEndpoints', 'AtrLocalPaths', 'CertificateAuthority', 'CertificateStatusPolicy', 'IdentityVerifier', 'RegistryClient', 'RegistryRequestRejected', 'RegistryServerCredentials']

@dataclass(frozen=True, slots=True)
class RegistryServerCredentials:
    """User credentials for the Registry HTTP authentication API."""
    username: str
    password: str = field(repr=False)

@dataclass(frozen=True, slots=True)
class AtrEndpoints:
    """Remote ATR infrastructure and its optional local TLS CA certificate."""
    registry_url: str
    certificate_authority_url: str
    registry_entity_mtls_url: str | None = ...
    ca_cert_path: Path | None = ...
    def __post_init__(self) -> None: ...

@dataclass(frozen=True, slots=True)
class AtrLocalPaths:
    """Read-only registration inputs and state owned by this registration."""
    acs_path: Path
    state_dir: Path
    parent_state_dir: Path | None = ...
    def __post_init__(self) -> None: ...

@dataclass(frozen=True, slots=True)
class CertificateStatusPolicy:
    """Advanced freshness controls for CA certificate status checks."""
    max_age: float = ...
    poll_interval: float = ...
    def __post_init__(self) -> None: ...

@dataclass(frozen=True, slots=True)
class AtrConfig:
    """Complete explicit configuration for one trusted registration."""
    endpoints: AtrEndpoints
    registry_credentials: RegistryServerCredentials
    paths: AtrLocalPaths
    mode: Literal['integrated', 'ontology', 'entity'] = ...
    certificate_status: CertificateStatusPolicy = field(default_factory=CertificateStatusPolicy)
    def __post_init__(self) -> None: ...

class RegistryRequestRejected(RuntimeError):
    """Registry definitively rejected an HTTP request without accepting its write."""
    status_code: Incomplete
    def __init__(self, status_code: int, message: str) -> None: ...

class RegistryClient:
    """Registry HTTP adapter for public registration and external review."""
    _config: Incomplete
    _transport: Incomplete
    _tokens: tuple[str, str | None] | None
    _root: Incomplete
    def __init__(self, config: AtrConfig, *, transport: httpx.AsyncBaseTransport | None = None) -> None: ...
    def _client(self) -> httpx.AsyncClient: ...
    async def prepare(self) -> None:
        """Authenticate before the component marks a Registry write uncertain."""
    async def _login(self) -> None: ...
    async def _refresh(self) -> bool: ...
    @staticmethod
    def _json_object(response: httpx.Response) -> dict[str, object]: ...
    @staticmethod
    def _raise_for_status(response: httpx.Response) -> None: ...
    async def _request(self, method: str, path: str, *, params: dict[str, object] | None = None, json_body: dict[str, object] | None = None) -> dict[str, object]: ...
    async def create_draft(self, candidate: Mapping[str, object], *, mode: str = 'integrated') -> str:
        """Create one exact candidate draft and return its Registry ID."""
    async def submit_draft(self, registration_id: str) -> RegistrationReview: ...
    async def review(self, registration_id: str, *, candidate: Mapping[str, object] | None = None, strict_approved: bool = False) -> RegistrationReview:
        """Poll the Registry for the review status of a registration.

        Implements the ``RegistrationRegistry.review`` protocol.
        """
    async def fetch_eab(self, aic: str) -> dict[str, object]:
        """Request External Account Binding for the approved identity."""
    async def final_acs(self, aic: str) -> dict[str, object]: ...
    async def final_entity_acs(self, aic: str, ontology_acs: Mapping[str, object]) -> dict[str, object]:
        """Inherit absent contract fields before validating an entity response."""
    async def _final_acs(self, aic: str, ontology_acs: Mapping[str, object] | None = None) -> dict[str, object]: ...
    async def register_entity(self, candidate: Mapping[str, object], ontology: IdentityMaterial) -> RegistrationReview: ...

class CertificateAuthority:
    """ACME adapter; the component owns account and certificate persistence."""
    _config: Incomplete
    _transport: Incomplete
    def __init__(self, config: AtrConfig, *, transport: httpx.AsyncBaseTransport | None = None) -> None: ...
    async def certificate_status(self, serial: str) -> str:
        """Read CA's TLS-authenticated simple certificate-status endpoint."""
    async def issue_one(self, aic: str, usage: str, account_key_pem: str, *, eab: dict[str, object] | None, existing: bool) -> tuple[str, str, str]: ...
    async def revoke(self, certificate_pem: str, reason: int, account_key_pem: str) -> None: ...

class IdentityVerifier:
    """``IdentityMaterialVerifier`` implementation for ACPS CAI certificates.

    Validates:
    - ACS fingerprint binding
    - CN equals AIC
    - ``URI:acps://{AIC}`` SAN present and consistent
    - EKU contains the correct usage (clientAuth / serverAuth)
    - Certificate validity period covers current time
    - Private key matches the certificate public key
    - Certificate chain reaches the trust bundle

    Missing validation dependencies or certificate material fail closed.
    """
    async def verify(self, material: IdentityMaterial, candidate: AcsSnapshot) -> None:
        """Verify that the material is well-formed and bound to the ACS."""
