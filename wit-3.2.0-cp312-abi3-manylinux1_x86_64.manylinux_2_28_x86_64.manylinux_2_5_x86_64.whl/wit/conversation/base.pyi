from collections.abc import Mapping
from dataclasses import dataclass, field
from wit.conversation.content import ContentPart

__all__ = ['AssistantMessage', 'Message', 'SystemMessage', 'ToolCall', 'ToolMessage', 'UserMessage']

@dataclass(frozen=True, slots=True)
class ToolCall:
    """One provider-neutral request from an Assistant to a named Tool."""
    call_id: str
    name: str
    arguments: Mapping[str, object]
    def __post_init__(self) -> None: ...

class _ContentMessage:
    content: tuple[ContentPart, ...]
    def text(self) -> str: ...
    def reasoning(self) -> str: ...
    @property
    def has_simple_text(self) -> bool: ...

@dataclass(frozen=True, slots=True)
class SystemMessage(_ContentMessage):
    """Provider-neutral instructions that govern a model conversation."""
    content: object
    metadata: Mapping[str, object] = field(default_factory=dict)
    def __post_init__(self) -> None: ...

@dataclass(frozen=True, slots=True)
class UserMessage(_ContentMessage):
    """Provider-neutral input from the caller side of a model conversation."""
    content: object
    metadata: Mapping[str, object] = field(default_factory=dict)
    def __post_init__(self) -> None: ...

@dataclass(frozen=True, slots=True)
class AssistantMessage(_ContentMessage):
    """Provider-neutral model response containing content, Tool Calls, or both."""
    content: object | None = ...
    tool_calls: tuple[ToolCall, ...] = ...
    metadata: Mapping[str, object] = field(default_factory=dict)
    def __post_init__(self) -> None: ...

@dataclass(frozen=True, slots=True)
class ToolMessage(_ContentMessage):
    """Provider-neutral observation produced for one Assistant Tool Call."""
    tool_call_id: str
    name: str
    content: object
    metadata: Mapping[str, object] = field(default_factory=dict)
    def __post_init__(self) -> None: ...
type Message = SystemMessage | UserMessage | AssistantMessage | ToolMessage
