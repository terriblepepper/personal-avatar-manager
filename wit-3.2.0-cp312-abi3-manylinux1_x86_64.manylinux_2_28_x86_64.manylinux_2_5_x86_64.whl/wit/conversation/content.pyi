from _typeshed import Incomplete
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import Literal

__all__ = ['ATTACHMENT_PART_TYPES', 'CONTENT_PART_TYPES', 'AttachmentPart', 'AudioPart', 'ContentInput', 'ContentKind', 'ContentPart', 'DataPart', 'FileDetail', 'FilePart', 'ImageDetail', 'ImagePart', 'ReasoningPart', 'RefusalPart', 'TextPart', 'VideoPart', 'attachment_summary', 'content_text', 'normalize_content', 'reasoning_text']

type ContentKind = Literal['text', 'reasoning', 'refusal', 'data', 'image', 'video', 'audio', 'file']
type ImageDetail = Literal['auto', 'low', 'high', 'original']
type FileDetail = Literal['auto', 'low', 'high']
@dataclass(frozen=True, slots=True)
class TextPart:
    text: str
    metadata: Mapping[str, object] = field(default_factory=dict)
    type: Literal['text'] = field(default='text', init=False)
    def __post_init__(self) -> None: ...

@dataclass(frozen=True, slots=True)
class ReasoningPart:
    """Provider reasoning or a reasoning summary, separate from final text."""
    text: str
    metadata: Mapping[str, object] = field(default_factory=dict)
    type: Literal['reasoning'] = field(default='reasoning', init=False)
    def __post_init__(self) -> None: ...

@dataclass(frozen=True, slots=True)
class RefusalPart:
    text: str
    metadata: Mapping[str, object] = field(default_factory=dict)
    type: Literal['refusal'] = field(default='refusal', init=False)
    def __post_init__(self) -> None: ...

@dataclass(frozen=True, slots=True)
class DataPart:
    data: object
    metadata: Mapping[str, object] = field(default_factory=dict)
    type: Literal['data'] = field(default='data', init=False)
    def __post_init__(self) -> None: ...

@dataclass(frozen=True, slots=True)
class ImagePart:
    mime_type: str
    uri: str | None = ...
    data: bytes | None = ...
    name: str | None = ...
    detail: ImageDetail = ...
    metadata: Mapping[str, object] = field(default_factory=dict)
    type: Literal['image'] = field(default='image', init=False)
    def __post_init__(self) -> None: ...

@dataclass(frozen=True, slots=True)
class VideoPart:
    mime_type: str
    uri: str | None = ...
    data: bytes | None = ...
    name: str | None = ...
    metadata: Mapping[str, object] = field(default_factory=dict)
    type: Literal['video'] = field(default='video', init=False)
    def __post_init__(self) -> None: ...

@dataclass(frozen=True, slots=True)
class AudioPart:
    mime_type: str
    uri: str | None = ...
    data: bytes | None = ...
    name: str | None = ...
    metadata: Mapping[str, object] = field(default_factory=dict)
    type: Literal['audio'] = field(default='audio', init=False)
    def __post_init__(self) -> None: ...

@dataclass(frozen=True, slots=True)
class FilePart:
    uri: str | None = ...
    data: bytes | None = ...
    mime_type: str | None = ...
    name: str | None = ...
    detail: FileDetail = ...
    metadata: Mapping[str, object] = field(default_factory=dict)
    type: Literal['file'] = field(default='file', init=False)
    def __post_init__(self) -> None: ...
type ContentPart = TextPart | ReasoningPart | RefusalPart | DataPart | ImagePart | VideoPart | AudioPart | FilePart
type AttachmentPart = ImagePart | VideoPart | AudioPart | FilePart
type ContentInput = str | ContentPart | Sequence[ContentPart]

CONTENT_PART_TYPES: Incomplete
ATTACHMENT_PART_TYPES: Incomplete

def normalize_content(value: object | None) -> tuple[ContentPart, ...]:
    """Normalize friendly message input to one immutable internal shape."""
def content_text(value: object | None) -> str:
    """Return visible text and refusals without flattening reasoning or media."""
def reasoning_text(value: object | None) -> str:
    """Return reasoning text without mixing it into the visible answer."""
def attachment_summary(part: AttachmentPart) -> Mapping[str, object]:
    """Return telemetry-safe attachment facts without inline bytes."""
