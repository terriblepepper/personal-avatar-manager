from _typeshed import Incomplete
from collections.abc import Awaitable, Callable
from contextlib import AbstractAsyncContextManager
from dataclasses import dataclass, field
from typing import Protocol
from wit.agents import InvocationContext
from wit.tools.definitions import Tool, ToolDescriptor, ToolResult

__all__ = ['TOOL_CALL_AFTER_HOOK', 'TOOL_CALL_BEFORE_HOOK', 'TOOL_CALL_HOOK', 'TOOL_RUNTIME', 'ScopedToolRuntime', 'ToolCallAfter', 'ToolCallBefore', 'ToolCallEvent', 'ToolRuntime']

class ScopedToolRuntime(Protocol):
    """Lookup and execution surface of an invocation-bound Tool view."""
    def get(self, name: str) -> Tool: ...
    def list_tools(self) -> tuple[ToolDescriptor, ...]: ...
    async def invoke(self, name: str, input: object, *, invocation: InvocationContext, operation_id: str | None = None) -> ToolResult: ...

class ToolRuntime(ScopedToolRuntime, Protocol):
    """Full Tool service, including registration and scoped visibility."""
    def register(self, tool: Tool) -> Callable[[], Awaitable[None]]: ...
    def overlay(self, tools: tuple[Tool, ...]) -> AbstractAsyncContextManager[object]: ...
    def scoped(self, invocation: InvocationContext) -> ScopedToolRuntime: ...

@dataclass(frozen=True, slots=True)
class ToolCallEvent:
    """Effective Tool call information passed to an intercept handler.

    Inspect ``event.tool`` and ``event.input``, then return a ToolResult or call
    ``await proceed()``. Replace input in TOOL_CALL_BEFORE_HOOK instead.
    """
    invocation: InvocationContext
    tool: Tool
    input: object
    operation_id: str | None = field(init=False)
    def __post_init__(self) -> None: ...

class ToolCallBefore:
    """Mutable input slot shared by Tool call-before Hooks."""
    __slots__: Incomplete
    _invocation: Incomplete
    _operation_id: Incomplete
    _tool: Incomplete
    def __init__(self, invocation: InvocationContext, tool: Tool, input: object) -> None: ...
    @property
    def invocation(self) -> InvocationContext: ...
    @property
    def tool(self) -> Tool: ...
    @property
    def operation_id(self) -> str | None: ...
    @property
    def input(self) -> object: ...
    _input: Incomplete
    @input.setter
    def input(self, value: object) -> None: ...

class ToolCallAfter:
    """Mutable result slot shared by Tool call-after Hooks."""
    __slots__: Incomplete
    _invocation: Incomplete
    _operation_id: Incomplete
    _tool: Incomplete
    _input: Incomplete
    def __init__(self, invocation: InvocationContext, tool: Tool, input: object, result: ToolResult) -> None: ...
    @property
    def invocation(self) -> InvocationContext: ...
    @property
    def tool(self) -> Tool: ...
    @property
    def operation_id(self) -> str | None: ...
    @property
    def input(self) -> object: ...
    @property
    def result(self) -> ToolResult: ...
    _result: Incomplete
    @result.setter
    def result(self, value: ToolResult) -> None: ...

TOOL_RUNTIME: Incomplete
TOOL_CALL_BEFORE_HOOK: Incomplete
TOOL_CALL_HOOK: Incomplete
TOOL_CALL_AFTER_HOOK: Incomplete
