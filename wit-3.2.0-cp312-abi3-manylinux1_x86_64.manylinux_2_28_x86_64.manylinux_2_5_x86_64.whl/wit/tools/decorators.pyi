from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass
from typing import overload
from wit.agents import InvocationContext
from wit.tools.definitions import Tool, ToolResult

__all__ = ['define_tool', 'tool']

type AsyncToolHandler = Callable[..., Awaitable[object]]
type ToolDecorator = Callable[[AsyncToolHandler], Tool]
type RuntimeType = type[object] | tuple[type[object], ...]
@dataclass(frozen=True, slots=True)
class _BusinessParameter:
    name: str
    annotation: object | None
    required: bool

@dataclass(frozen=True, slots=True)
class _AnalyzedSignature:
    input_schema: Mapping[str, object]
    output_type: RuntimeType
    parameters: tuple[_BusinessParameter, ...]
    invocation_parameter: str | None
    return_annotation: object
    returns_tool_result: bool

@dataclass(frozen=True, slots=True)
class _FunctionTool:
    """Tool adapter for one ordinary async function."""
    name: str
    description: str
    input_schema: Mapping[str, object]
    input_type: RuntimeType
    output_type: RuntimeType
    _handler: AsyncToolHandler
    _parameters: tuple[_BusinessParameter, ...]
    _invocation_parameter: str | None
    _return_annotation: object
    _returns_tool_result: bool
    def __post_init__(self) -> None: ...
    async def execute(self, invocation: InvocationContext, input: object) -> ToolResult: ...
    def _prepare_execution(self, invocation: InvocationContext, input: object) -> dict[str, object]: ...
    async def _execute_prepared(self, arguments: dict[str, object]) -> object: ...
    def _finish_execution(self, result: object) -> ToolResult: ...
    def _validate_output(self, output: object) -> None: ...
    def _bind_arguments(self, invocation: InvocationContext, input: object) -> dict[str, object]: ...

def define_tool(function: AsyncToolHandler, /, *, name: str | None = None, description: str | None = None, input_schema: Mapping[str, object] | None = None) -> Tool:
    """Adapt an ordinary async function to the stable Tool execution contract."""
@overload
def tool(function: AsyncToolHandler, /, *, name: str | None = None, description: str | None = None, input_schema: Mapping[str, object] | None = None) -> Tool: ...
@overload
def tool(function: None = None, /, *, name: str | None = None, description: str | None = None, input_schema: Mapping[str, object] | None = None) -> ToolDecorator: ...
