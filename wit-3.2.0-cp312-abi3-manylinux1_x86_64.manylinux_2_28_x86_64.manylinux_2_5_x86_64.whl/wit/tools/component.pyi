from _typeshed import Incomplete
from collections.abc import Mapping
from wit._kernel.effects import EffectHandle
from wit.agents import InvocationContext
from wit.components import Context
from wit.components.component import WitComponent
from wit.tools.definitions import ToolResult

__all__ = ['BaseToolComponent']

class BaseToolComponent(WitComponent[object]):
    """Component that registers exactly one developer-defined Tool handler."""
    name: str
    requires: Incomplete
    description: str
    input_schema: Mapping[str, object]
    input_type: type[object] | tuple[type[object], ...]
    output_type: type[object] | tuple[type[object], ...]
    _registration_effect: EffectHandle | None
    def __init__(self) -> None: ...
    async def setup(self, ctx: Context) -> None: ...
    async def teardown(self, ctx: Context) -> None: ...
    async def setup_tool(self, ctx: Context) -> None:
        """Optionally acquire business resources during component setup."""
    async def teardown_tool(self, ctx: Context) -> None:
        """Optionally release business resources during component teardown."""
    async def execute(self, invocation: InvocationContext, input: object) -> ToolResult: ...
