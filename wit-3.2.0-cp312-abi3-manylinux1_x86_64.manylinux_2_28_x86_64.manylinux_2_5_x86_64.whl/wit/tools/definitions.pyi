from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Protocol
from wit.agents import InvocationContext

__all__ = ['Tool', 'ToolDescriptor', 'ToolResult']

@dataclass(frozen=True, slots=True)
class ToolDescriptor:
    """Model-visible description of one registered Tool."""
    name: str
    description: str
    input_schema: Mapping[str, object]
    def __post_init__(self) -> None: ...

@dataclass(frozen=True, slots=True)
class ToolResult:
    """Result returned by one named Tool handler."""
    output: object = ...
    metadata: Mapping[str, object] = field(default_factory=dict)
    def __post_init__(self) -> None: ...

class Tool(Protocol):
    """One registered operation exposed to an Agent Loop and its model."""
    @property
    def name(self) -> str: ...
    @property
    def description(self) -> str: ...
    @property
    def input_schema(self) -> Mapping[str, object]: ...
    @property
    def input_type(self) -> type[object] | tuple[type[object], ...]: ...
    @property
    def output_type(self) -> type[object] | tuple[type[object], ...]: ...
    async def execute(self, invocation: InvocationContext, input: object) -> ToolResult: ...
