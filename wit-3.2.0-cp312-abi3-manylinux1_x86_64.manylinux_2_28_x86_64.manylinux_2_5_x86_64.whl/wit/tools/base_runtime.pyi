import abc
from _typeshed import Incomplete
from abc import ABC, abstractmethod
from collections.abc import Awaitable, Callable
from contextlib import AbstractAsyncContextManager
from typing import final
from wit.agents import InvocationContext
from wit.components import Context, WitComponent
from wit.tools.definitions import Tool, ToolDescriptor, ToolResult
from wit.tools.events import ScopedToolRuntime

__all__ = ['BaseToolRuntimeComponent']

class BaseToolRuntimeComponent(WitComponent[object], ABC, metaclass=abc.ABCMeta):
    """Publish a custom Tool Runtime after its implementation finishes setup.

    Implement the six service methods and optionally the lifecycle hooks.
    Implementations own registration, execution, validation, Hooks, scoped
    visibility and call draining; use WitToolRuntimeComponent to reuse those
    default behaviors.
    """
    provides: Incomplete
    def __init_subclass__(cls, **kwargs: object) -> None: ...
    _runtime_context: Context | None
    def __init__(self) -> None: ...
    @final
    async def setup(self, ctx: Context) -> None: ...
    @final
    async def teardown(self, ctx: Context) -> None: ...
    async def setup_tool_runtime(self, ctx: Context) -> None:
        """Acquire resources using ctx.effect() so partial setup can be rolled back."""
    async def teardown_tool_runtime(self, ctx: Context) -> None:
        """Drain active calls before releasing implementation-owned resources."""
    def _require_active(self) -> Context: ...
    @abstractmethod
    def register(self, tool: Tool) -> Callable[[], Awaitable[None]]:
        """Register one Tool and return a disposer that drains its active calls."""
    @abstractmethod
    def get(self, name: str) -> Tool:
        """Return a Tool view whose execute() uses this Runtime's execution path."""
    @abstractmethod
    def list_tools(self) -> tuple[ToolDescriptor, ...]:
        """Return descriptors for currently visible Tools accepting new calls."""
    @abstractmethod
    def overlay(self, tools: tuple[Tool, ...]) -> AbstractAsyncContextManager[object]:
        """Own temporary Tools visible only within the entered async scope."""
    @abstractmethod
    def scoped(self, invocation: InvocationContext) -> ScopedToolRuntime:
        """Bind the current Tool visibility to exactly one InvocationContext."""
    @abstractmethod
    async def invoke(self, name: str, input: object, *, invocation: InvocationContext, operation_id: str | None = None) -> ToolResult:
        """Execute through validation, Hooks, cancellation and active-call ownership."""
