import asyncio
from _typeshed import Incomplete
from collections.abc import Mapping, Sequence
from wit._kernel.registry import ComponentHandle
from wit.checkpoints.contracts import CheckpointStatus, CheckpointVersion
from wit.components import ComponentState, ServiceKey

__all__ = ['AgentNotStartedError', 'AgentStoppedError', 'CheckpointBlockedError', 'CheckpointBusyError', 'CheckpointConflictError', 'CheckpointCorruptionError', 'CheckpointError', 'CheckpointInterruptedError', 'CheckpointInvocationFailedError', 'CheckpointRecoveryRequiredError', 'CheckpointSchemaMismatchError', 'CheckpointSerializationError', 'CircularDependencyError', 'CleanupError', 'ComponentConfigError', 'ContextDisposedError', 'DuplicateServiceError', 'DuplicateToolError', 'HookContractError', 'InvalidComponentError', 'InvocationCancelledError', 'InvocationContextClosedError', 'InvocationDeadlineExceededError', 'InvocationProtocolError', 'LoopLimitExceededError', 'MissingAgentEntryError', 'MissingCheckpointRuntimeError', 'MissingProvidedServiceError', 'MissingToolError', 'RequiredComponentError', 'ToolOutcomeUnknownError', 'UndeclaredServiceError', 'WitError']

class WitError(Exception):
    """Base class for framework-core errors."""
class HookContractError(TypeError):
    """A Hook Key, handler, or dispatch violates its declared contract."""
class AgentStoppedError(WitError):
    """Raised when a terminally stopped agent receives new work."""
class AgentNotStartedError(WitError):
    """Raised when business work is attempted before component startup."""
class MissingAgentEntryError(WitError):
    """Raised when an Agent execution has no active entry service."""
class MissingToolError(WitError):
    """Raised when a named Tool is not registered."""
class DuplicateToolError(WitError):
    """Raised when one Tool Runtime receives a duplicate name."""
class InvocationProtocolError(WitError):
    """Raised when a stream violates the unique-terminal-result contract."""
class InvocationCancelledError(asyncio.CancelledError):
    """Typed cancellation propagated by invocation execution paths."""
class InvocationDeadlineExceededError(InvocationCancelledError):
    """Raised when an InvocationContext reaches its declared deadline."""
class InvocationContextClosedError(WitError):
    """Raised when an execution path receives an already closed InvocationContext."""

class LoopLimitExceededError(WitError):
    """Raised when an Agent Loop needs another model step beyond its limit."""
    max_steps: Incomplete
    def __init__(self, max_steps: int) -> None: ...

class CheckpointError(WitError):
    """Base class for Agent Loop checkpoint failures."""
class MissingCheckpointRuntimeError(CheckpointError):
    """Raised when a threaded Loop runs without a Checkpoint Runtime."""

class CheckpointBlockedError(CheckpointError):
    """An unfinished invocation blocks a requested checkpoint operation."""
    thread_id: Incomplete
    invocation_id: Incomplete
    status: Incomplete
    version: Incomplete
    def __init__(self, message: str, *, thread_id: str | None = None, invocation_id: str | None = None, status: CheckpointStatus | None = None, version: CheckpointVersion | None = None) -> None: ...

class CheckpointBusyError(CheckpointBlockedError):
    """Raised when a thread is still owned by an executing call."""
class CheckpointInterruptedError(CheckpointBlockedError):
    """Raised when a new invocation is blocked by resumable unfinished work."""
class CheckpointConflictError(CheckpointError):
    """Raised when checkpoint identity or compare-and-set version conflicts."""
class CheckpointCorruptionError(CheckpointError):
    """Raised when a backend returns a malformed checkpoint record."""
class CheckpointRecoveryRequiredError(CheckpointBlockedError):
    """Raised when automatic recovery could repeat an ambiguous side effect."""
class CheckpointInvocationFailedError(CheckpointBlockedError):
    """Raised when a failed invocation must be explicitly terminated."""
class CheckpointSchemaMismatchError(CheckpointError):
    """Raised when stored Loop state is incompatible with the declared schema."""
class CheckpointSerializationError(CheckpointError):
    """Raised when a backend cannot detach a State or Cursor snapshot."""

class ToolOutcomeUnknownError(WitError):
    """Raised after a Tool handler starts and its external outcome is uncertain."""
    tool_name: Incomplete
    details: Incomplete
    def __init__(self, tool_name: str, *, details: Mapping[str, object] | None = None) -> None: ...

class ComponentConfigError(WitError):
    """Raised when a component rejects its configuration."""
class InvalidComponentError(WitError):
    """Raised when a component declaration is malformed."""
class DuplicateServiceError(WitError):
    """Raised when one service scope receives two providers."""
class MissingProvidedServiceError(WitError):
    """Raised when setup does not publish every declared service."""
class UndeclaredServiceError(WitError):
    """Raised when component code accesses an undeclared service."""
class CircularDependencyError(WitError):
    """Raised when declared providers close a dependency cycle."""
class ContextDisposedError(WitError):
    """Raised when an inactive component context creates owned work."""

class RequiredComponentError(WitError):
    """Raised when a startup-required component cannot become active."""
    handle: Incomplete
    state: Incomplete
    unmet_services: Incomplete
    def __init__(self, handle: ComponentHandle, state: ComponentState, unmet_services: tuple[ServiceKey[object], ...] = ()) -> None: ...

class CleanupError(WitError):
    """Aggregates cleanup failures after every disposer was attempted."""
    failures: Incomplete
    def __init__(self, message: str, failures: Sequence[BaseException]) -> None: ...
