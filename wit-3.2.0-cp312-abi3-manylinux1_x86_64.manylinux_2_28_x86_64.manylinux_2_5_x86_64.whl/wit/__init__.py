"""wit agent framework."""

from wit.agents import WitAgent

__version__ = "3.2.0"

__all__ = ("WitAgent", "__version__")
