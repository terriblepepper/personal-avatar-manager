from _typeshed import Incomplete
from collections.abc import Mapping
from wit.conversation import ToolCall as ToolCall
from wit.providers.openai._wire import json_value as json_value

_LEGAL: Incomplete

def _function_slots(value: object, *, chat: bool) -> list[dict[str, object]]:
    """Only function definitions/choices/calls; never touch business arguments or schemas."""
def _items(value: object) -> list[object] | tuple[object, ...]: ...

class ToolNameMap:
    """Preserve legal names and allocate invalid names in deterministic sorted order.

    Legal names (including ones that look like generated names) are reserved first.
    Every candidate is checked against the complete request set, including history
    and tool_choice. Rehashing resolves collisions instead of conflating tools.
    No request or overlay state is stored on the model component.
    """
    forward: Incomplete
    reverse: Incomplete
    changed: Incomplete
    def __init__(self, names: set[str]) -> None: ...
    @classmethod
    def encode(cls, params: Mapping[str, object], *, chat: bool) -> tuple[ToolNameMap, dict[str, object]]: ...
    def call(self, call: ToolCall) -> ToolCall: ...
    def response_item(self, item: Mapping[str, object]) -> dict[str, object]: ...
    def response(self, payload: Mapping[str, object]) -> dict[str, object]: ...
    def completion(self, payload: Mapping[str, object]) -> dict[str, object]: ...
