import httpx
from _typeshed import Incomplete
from collections.abc import AsyncIterator, Awaitable, Callable, Mapping, Sequence
from openai import AsyncOpenAI
from typing import Literal
from wit.agents.invocation import InvocationContext
from wit.components import Context
from wit.models import BaseModelComponent, ModelEvent, ModelRequest
from wit.providers.openai.adapters import ContentTransform, GatewayAdapter
from wit.providers.openai.capabilities import ProviderCapabilities

__all__ = ['OpenAIModelComponent']

type OpenAIAPI = Literal['responses', 'chat.completions']
type APIKey = str | Callable[[], Awaitable[str]] | None
class OpenAIModelComponent(BaseModelComponent):
    """One official OpenAI component with an instance-fixed endpoint mode."""
    api_default: str
    _api: OpenAIAPI
    model: Incomplete
    api_key: Incomplete
    base_url: Incomplete
    timeout: Incomplete
    headers: Incomplete
    transport: Incomplete
    max_retries: Incomplete
    strict_response_validation: Incomplete
    settings: Incomplete
    content_transforms: Incomplete
    gateway_adapters: Incomplete
    _scope_id: Incomplete
    _driver: Incomplete
    _client: AsyncOpenAI | None
    def __init__(self, *, model: str, api_key: APIKey = None, api: OpenAIAPI = 'responses', base_url: str = 'https://api.openai.com/v1', timeout: float = 60.0, headers: Mapping[str, str] | None = None, transport: httpx.AsyncBaseTransport | None = None, max_retries: int = 2, strict_response_validation: bool = False, settings: Mapping[str, object] | None = None, content_transforms: Sequence[ContentTransform] = (), gateway_adapters: Sequence[GatewayAdapter] = ()) -> None: ...
    @property
    def api(self) -> OpenAIAPI: ...
    @property
    def capabilities(self) -> ProviderCapabilities: ...
    async def setup_model(self, ctx: Context) -> None: ...
    async def teardown_model(self, ctx: Context) -> None: ...
    async def _stream(self, request: ModelRequest, invocation: InvocationContext) -> AsyncIterator[ModelEvent]: ...
