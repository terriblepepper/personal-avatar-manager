from dataclasses import dataclass
from wit.conversation import ContentKind

__all__ = ['ProviderCapabilities']

@dataclass(frozen=True, slots=True)
class ProviderCapabilities:
    provider: str
    api: str
    input_modalities: frozenset[ContentKind]
    output_modalities: frozenset[ContentKind]
    streaming: bool = ...
    tools: bool = ...
