from collections.abc import Awaitable, Callable, Mapping, Sequence
from dataclasses import dataclass
from typing import Literal, Protocol
from wit.conversation import ContentKind, ContentPart
from wit.models import ModelEvent, ModelRequest, ModelResult
from wit.providers.openai.capabilities import ProviderCapabilities

__all__ = ['ContentTransform', 'ContentTransformContext', 'GatewayAdapter', 'GatewayAdapterContext']

type ModelOperation = Literal['complete', 'stream']
type TransformResult = object | ContentPart | Sequence[ContentPart] | None
type TransformHandler = Callable[[ContentPart, 'ContentTransformContext'], Awaitable[TransformResult]]
class EndpointDriver(Protocol):
    capabilities: ProviderCapabilities
    def supports_content(self, part: ContentPart, *, role: str) -> tuple[bool, str | None]: ...

@dataclass(frozen=True, slots=True)
class ContentTransformContext:
    provider: str
    api: str
    role: str
    capabilities: ProviderCapabilities
    reason: str

@dataclass(frozen=True, slots=True)
class ContentTransform:
    """One explicit asynchronous conversion for unsupported business content."""
    source_type: ContentKind
    handler: TransformHandler
    name: str | None = ...
    def __post_init__(self) -> None: ...
    async def apply(self, part: ContentPart, context: ContentTransformContext) -> tuple[ContentPart, ...] | None: ...

@dataclass(frozen=True, slots=True)
class GatewayAdapterContext:
    operation: ModelOperation
    capabilities: ProviderCapabilities
    model: str

class GatewayAdapter:
    """Explicit identity strategy for one compatibility gateway concern."""
    name: str
    added_input_modalities: frozenset[ContentKind]
    async def adapt_request(self, request: ModelRequest, context: GatewayAdapterContext) -> ModelRequest: ...
    async def adapt_response(self, request: ModelRequest, response: ModelResult, context: GatewayAdapterContext) -> ModelResult: ...
    async def adapt_stream_event(self, request: ModelRequest, event: ModelEvent, context: GatewayAdapterContext) -> ModelEvent: ...
    async def adapt_wire_request(self, request: ModelRequest, payload: Mapping[str, object], context: GatewayAdapterContext) -> Mapping[str, object]: ...
    async def adapt_wire_response(self, request: ModelRequest, payload: Mapping[str, object], context: GatewayAdapterContext) -> Mapping[str, object]: ...
    async def adapt_wire_stream_event(self, request: ModelRequest, event: Mapping[str, object], context: GatewayAdapterContext) -> Mapping[str, object]: ...
    async def aclose(self) -> None: ...
