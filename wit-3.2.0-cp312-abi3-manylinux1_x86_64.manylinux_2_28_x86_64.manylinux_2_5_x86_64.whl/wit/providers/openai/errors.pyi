from _typeshed import Incomplete
from wit.conversation import ContentKind, ContentPart
from wit.models.errors import ModelError, ModelInputError

__all__ = ['ContentTransformError', 'GatewayAdaptationError', 'OpenAIModelError', 'UnsupportedContentError']

class UnsupportedContentError(ModelInputError):
    """Raised before I/O when no configured path can handle one content part."""
    provider: Incomplete
    role: Incomplete
    part: Incomplete
    reason: Incomplete
    args: Incomplete
    def __init__(self, *, provider: str, role: str, part: ContentPart, reason: str) -> None: ...

class ContentTransformError(RuntimeError):
    """Sanitized failure raised by an explicit content conversion strategy."""
    transform: Incomplete
    source_type: Incomplete
    stage: Incomplete
    reason: str
    cause_type: Incomplete
    def __init__(self, *, transform: str, source_type: ContentKind, stage: str, cause_type: str) -> None: ...

class GatewayAdaptationError(RuntimeError):
    """Sanitized fail-closed error for explicit GatewayAdapter failures."""
    adapter: Incomplete
    stage: Incomplete
    operation: Incomplete
    reason: Incomplete
    cause_type: Incomplete
    def __init__(self, *, adapter: str, stage: str, operation: str, reason: str, cause_type: str | None = None) -> None: ...

class OpenAIModelError(ModelError):
    """Normalized official SDK or endpoint protocol failure."""
    api: Incomplete
    operation: Incomplete
    reason: Incomplete
    status_code: Incomplete
    details: Incomplete
    def __init__(self, *, api: str, operation: str, reason: str, status_code: int | None = None, details: object = None, retryable: bool = False) -> None: ...
