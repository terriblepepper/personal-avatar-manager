from wit.delivery.stores.memory import MemoryMessageStore as MemoryMessageStore

__all__ = ['MemoryMessageStore']
