"""Reliable Messaging store implementations."""

from wit.delivery.stores.memory import MemoryMessageStore

__all__ = ("MemoryMessageStore",)
