import asyncio
from _typeshed import Incomplete
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import datetime
from wit.components import Context, ContextualService, WitComponent
from wit.delivery.contracts import Delivery, MessageDeliveryEvent, MessageEnvelope, MessageKey, MessageStore, RecoveredDelivery

__all__ = ['MemoryMessageTransport', 'MessageRuntimeComponent', 'MessageRuntimeSnapshot']

class MemoryMessageTransport:
    """Process-local reference Transport for adapter and conformance testing."""
    name: str
    sent: list[tuple[str, MessageEnvelope[object]]]
    _receivers: list[Callable[[str, MessageEnvelope[object]], object]]
    _closed: bool
    def __init__(self) -> None: ...
    def subscribe(self, receiver: Callable[[str, MessageEnvelope[object]], object]) -> Callable[[], None]: ...
    async def send(self, channel: str, envelope: MessageEnvelope[object]) -> None: ...
    async def close(self) -> None: ...

@dataclass(frozen=True, slots=True)
class MessageRuntimeSnapshot:
    """Channel diagnostics joined with Runtime ownership and admission state."""
    channel: str
    owner: str | None
    consumer_count: int
    store_type: str
    capacity: int
    pending: int
    inflight: int
    retry: int
    dead: int
    rejected: int
    earliest_backlog_at: datetime | None
    last_failure: str | None
    accepting: bool

class _MessageRuntimeService(ContextualService):
    _runtime: Incomplete
    def __init__(self, runtime: MessageRuntimeComponent) -> None: ...
    async def send[PayloadT](self, key: MessageKey[PayloadT], payload: PayloadT, **envelope_fields: object) -> MessageEnvelope[PayloadT]: ...
    async def consume[PayloadT](self, key: MessageKey[PayloadT], handler: Callable[[Delivery[PayloadT]], object], *, concurrency: int = 1) -> Callable[[], Awaitable[None]]: ...
    async def wait_idle(self, key: MessageKey[object]) -> None: ...
    async def inspect(self, key: MessageKey[object]) -> MessageRuntimeSnapshot: ...

@dataclass(slots=True)
class _Consumer:
    key: MessageKey[object]
    owner: str | None
    handler: Callable[[Delivery[object]], object]
    tasks: list[asyncio.Task[None]]
    closing: bool = ...
    failures: list[BaseException] = field(default_factory=list)

class MessageRuntimeComponent(WitComponent[object]):
    """Own bounded at-least-once delivery, workers, recovery, and diagnostics."""
    name: str
    provides: Incomplete
    store: Incomplete
    capacity: Incomplete
    max_attempts: Incomplete
    lease_for: Incomplete
    poll_interval: Incomplete
    retry_initial_delay: Incomplete
    retry_max_delay: Incomplete
    shutdown_timeout: Incomplete
    backpressure: Incomplete
    _accepting: bool
    _context: Context | None
    _consumers: list[_Consumer]
    _known_keys: dict[str, MessageKey[object]]
    _wake: Incomplete
    _service: Incomplete
    def __init__(self, *, store: MessageStore | None = None, capacity: int = 1024, max_attempts: int = 5, lease_for: float = 30.0, poll_interval: float = 0.05, retry_initial_delay: float = 0.25, retry_max_delay: float = 30.0, shutdown_timeout: float = 5.0, backpressure: str = 'fail') -> None: ...
    async def setup(self, ctx: Context) -> None: ...
    async def teardown(self, ctx: Context) -> None: ...
    async def send[PayloadT](self, key: MessageKey[PayloadT], payload: PayloadT, **envelope_fields: object) -> MessageEnvelope[PayloadT]: ...
    async def _consume[PayloadT](self, key: MessageKey[PayloadT], handler: Callable[[Delivery[PayloadT]], object], *, concurrency: int, caller: Context | None) -> Callable[[], Awaitable[None]]: ...
    async def _worker(self, consumer: _Consumer) -> None: ...
    async def _renew_lease(self, lease_id: str, stop: asyncio.Event) -> None: ...
    @staticmethod
    async def _requeue_if_current(delivery: Delivery[object], *, delay: float = 0.0, reason: str) -> None: ...
    def _start_worker(self, consumer: _Consumer, index: int) -> None: ...
    async def _dispose_consumer(self, consumer: _Consumer) -> None: ...
    async def wait_idle(self, key: MessageKey[object]) -> None: ...
    async def inspect(self, key: MessageKey[object]) -> MessageRuntimeSnapshot: ...
    def _retry_delay(self, attempt: int) -> float: ...
    async def _publish_event(self, event: MessageDeliveryEvent) -> None: ...
    async def _recover_expired(self) -> None: ...
    async def _publish_recovered(self, recovered: tuple[RecoveredDelivery, ...]) -> None: ...
    def _require_accepting(self) -> None: ...
    @staticmethod
    def _validate_key(key: object) -> None: ...
