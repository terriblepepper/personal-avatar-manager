from _typeshed import Incomplete
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Protocol
from wit.tracing import TraceContext

__all__ = ['MESSAGE_DELIVERY_EVENT_HOOK', 'MESSAGE_RUNTIME', 'ClaimedMessage', 'Delivery', 'DeliveryDisposition', 'DeliveryState', 'MessageCapacityError', 'MessageChannelSnapshot', 'MessageDeliveryEvent', 'MessageDuplicateError', 'MessageEnvelope', 'MessageKey', 'MessageLeaseError', 'MessageObservationContext', 'MessageRuntime', 'MessageRuntimeClosedError', 'MessageStore', 'MessageStoreError', 'MessageTransport', 'RecoveredDelivery', 'payload_matches']

class MessageKey[PayloadT]:
    """A stable name and payload type for one message channel."""
    __slots__: Incomplete
    _name: Incomplete
    def __init__(self, name: str) -> None: ...
    @property
    def name(self) -> str: ...
    @property
    def payload_type(self) -> object: ...
    def _identity(self) -> tuple[str, object]: ...
    def __eq__(self, other: object) -> bool: ...
    def __hash__(self) -> int: ...
    def __repr__(self) -> str: ...

@dataclass(frozen=True, slots=True)
class MessageObservationContext:
    """Persisted, framework-neutral facts for delayed delivery observers."""
    owner_id: str | None = ...
    trace: TraceContext = field(default_factory=TraceContext)
    def __post_init__(self) -> None: ...
    def to_document(self) -> dict[str, object]: ...
    @classmethod
    def from_document(cls, document: Mapping[str, object]) -> MessageObservationContext: ...

@dataclass(frozen=True, slots=True)
class MessageEnvelope[PayloadT]:
    """Immutable message facts shared by every delivery attempt."""
    payload: PayloadT
    message_id: str = field(default_factory=Incomplete, kw_only=True)
    created_at: datetime = field(default_factory=_utc_now, kw_only=True)
    correlation_id: str | None = field(default=None, kw_only=True)
    causation_id: str | None = field(default=None, kw_only=True)
    ordering_key: str | None = field(default=None, kw_only=True)
    observation: MessageObservationContext = field(default_factory=MessageObservationContext, kw_only=True)
    def __post_init__(self) -> None: ...

class DeliveryDisposition(StrEnum):
    """Outcomes a consumer may request for its current attempt."""
    ACK = 'ack'
    REQUEUE = 'requeue'
    REJECT = 'reject'

class DeliveryState(StrEnum):
    """Runtime-owned delivery states, including the terminal DEAD state."""
    PENDING = 'pending'
    INFLIGHT = 'inflight'
    RETRY = 'retry'
    ACK = 'ack'
    REQUEUE = 'requeue'
    REJECT = 'reject'
    DEAD = 'dead'

@dataclass(frozen=True, slots=True)
class MessageDeliveryEvent:
    """A delivery fact known by the Runtime, suitable for typed observers."""
    channel: str
    message_id: str
    attempt: int
    state: DeliveryState
    reason: str | None = ...
    observation: MessageObservationContext = field(default_factory=MessageObservationContext)

MESSAGE_DELIVERY_EVENT_HOOK: Incomplete

class MessageStoreError(RuntimeError):
    """Base failure raised by a message Store."""
class MessageCapacityError(MessageStoreError):
    """A bounded channel cannot accept another active message."""
class MessageDuplicateError(MessageStoreError):
    """The Store already contains the stable message id."""
class MessageLeaseError(MessageStoreError):
    """A settlement does not name a current inflight lease."""
class MessageRuntimeClosedError(MessageStoreError):
    """The Runtime no longer admits producers or consumers."""

@dataclass(frozen=True, slots=True)
class ClaimedMessage:
    """Store-level state used to construct a consumer Delivery."""
    channel: str
    envelope: MessageEnvelope[object]
    attempt: int
    lease_id: str
    leased_until: datetime

@dataclass(frozen=True, slots=True)
class RecoveredDelivery:
    """A RETRY or DEAD transition produced while recovering an expired lease."""
    channel: str
    message_id: str
    attempt: int
    state: DeliveryState
    reason: str
    observation: MessageObservationContext = field(default_factory=MessageObservationContext)

@dataclass(frozen=True, slots=True)
class MessageChannelSnapshot:
    """Read-only counts and recent failure facts for one channel."""
    channel: str
    store_type: str
    capacity: int | None
    pending: int
    inflight: int
    retry: int
    dead: int
    rejected: int
    earliest_backlog_at: datetime | None
    last_failure: str | None
    @property
    def total_active(self) -> int: ...

class MessageStore(Protocol):
    """Replaceable persistence contract for message delivery state."""
    async def open(self) -> None: ...
    async def close(self) -> None: ...
    async def enqueue(self, channel: str, envelope: MessageEnvelope[object], *, capacity: int) -> None: ...
    async def claim(self, channel: str, *, now: datetime, lease_for: float) -> ClaimedMessage | None: ...
    async def settle(self, lease_id: str, disposition: DeliveryDisposition, *, now: datetime, max_attempts: int, delay: float | None = None, reason: str | None = None) -> DeliveryState: ...
    async def renew(self, lease_id: str, *, now: datetime, lease_for: float) -> datetime: ...
    async def recover_expired(self, *, now: datetime, max_attempts: int) -> tuple[RecoveredDelivery, ...]: ...
    async def snapshot(self, channel: str) -> MessageChannelSnapshot: ...

class MessageTransport(Protocol):
    """Cross-boundary I/O contract kept separate from delivery state."""
    @property
    def name(self) -> str: ...
    async def send(self, channel: str, envelope: MessageEnvelope[object]) -> None: ...
    async def close(self) -> None: ...

class MessageRuntime(Protocol):
    """Producer, consumer, and diagnostics surface provided by the Runtime."""
    async def send[PayloadT](self, key: MessageKey[PayloadT], payload: PayloadT, **envelope_fields: object) -> MessageEnvelope[PayloadT]: ...
    async def consume[PayloadT](self, key: MessageKey[PayloadT], handler: Callable[[Delivery[PayloadT]], object], *, concurrency: int = 1) -> Callable[[], object]: ...
    async def wait_idle(self, key: MessageKey[object]) -> None: ...
    async def inspect(self, key: MessageKey[object]): ...

MESSAGE_RUNTIME: Incomplete
type Settlement = Callable[[DeliveryDisposition, float | None, str | None], object]

class Delivery[PayloadT]:
    """One leased attempt with single-use settlement capabilities."""
    __slots__: Incomplete
    envelope: Incomplete
    attempt: Incomplete
    lease_id: Incomplete
    leased_until: Incomplete
    _settle_callback: Incomplete
    _state: Incomplete
    def __init__(self, envelope: MessageEnvelope[PayloadT], *, attempt: int, lease_id: str, leased_until: datetime, settle: Settlement) -> None: ...
    @property
    def state(self) -> DeliveryState: ...
    @property
    def settled(self) -> bool: ...
    async def ack(self) -> None: ...
    async def requeue(self, *, delay: float = 0.0, reason: str | None = None) -> None: ...
    async def reject(self, *, reason: str | None = None) -> None: ...
    async def _settle(self, disposition: DeliveryDisposition, *, delay: float | None, reason: str | None) -> None: ...

def payload_matches(value: object, expected: object) -> bool:
    """Validate the runtime origin without pretending to deep-check generics."""
