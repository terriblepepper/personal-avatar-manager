from .errors import BusyError as BusyError, ManagementError as ManagementError
from .flux import FluxClient as FluxClient
from .installer import Installer as Installer
from .runtime import ComponentManager as ComponentManager
from .web_approvals import WebApprovals as WebApprovals
from .web_chat import Conversation as Conversation, WebChat as WebChat
from .web_settings import WebSettings as WebSettings
from _typeshed import Incomplete
from dataclasses import dataclass, field
from fastapi import Request as Request, UploadFile as UploadFile
from pydantic import BaseModel
from wit.attachments import AttachmentError as AttachmentError
from wit.management.auth import device_login as device_login, ensure_fresh as ensure_fresh
from wit.management.credentials import CredentialStore as CredentialStore
from wit.management.settings import oidc_settings as oidc_settings

@dataclass
class Session:
    csrf: str
    store: CredentialStore
    expires: float
    account: dict | None = ...
    login: dict = field(default_factory=dict)
    task: object = ...
    plans: dict = field(default_factory=dict)
    chat: Conversation = field(default_factory=Conversation)
    owner: str = field(default_factory=Incomplete)

class Input(BaseModel):
    model_config: Incomplete

class PlanInput(Input):
    requirements: list[str]

class ConfigurationInput(Input):
    values: dict
    revision: str
    profile: str | None
    clear_secrets: list[str]
    save_profile: str | None

class InstallInput(Input):
    plan: str
    configurations: dict[str, ConfigurationInput]

class LoadInput(Input):
    agent: str
    options: dict

class UnloadInput(Input):
    agent: str
    timeout: float

class SettingsInput(Input):
    changes: dict
    revision: str
    clear_api_key: bool

class ChatInput(Input):
    message: str
    attachments: list[str]

def create_app(manager=None, *, oidc_http=None, flux_factory=None, chat_model_factory=None, approvals_factory=..., allow_network: bool = False, allowed_hosts=()): ...
def serve(*, host: str = '127.0.0.1', port: int = 8765, allowed_hosts=(), approvals_factory=...) -> None: ...
