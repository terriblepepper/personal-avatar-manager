import asyncio
import httpx
from dataclasses import dataclass, field

DEFAULT_ISSUER: str
DEFAULT_CLIENT_ID: str
DEFAULT_SCOPE: str
DEVICE_CODE_GRANT: str

class OidcError(Exception):
    """Protocol or verification failure surfaced to the user."""
class AuthorizationDenied(OidcError):
    """The user denied the device grant in the browser."""
class DeviceGrantExpired(OidcError):
    """The device code expired before authorization completed."""
class LoginCancelled(OidcError):
    """The local user cancelled an in-progress login."""

def _b64url(data: bytes) -> str: ...
def _b64url_decode(data: str) -> bytes: ...
def generate_pkce() -> tuple[str, str]:
    """``(code_verifier, S256 code_challenge)`` for one login attempt."""

@dataclass(frozen=True, slots=True)
class Endpoints:
    authorization: str
    device_authorization: str
    token: str
    jwks: str
    revocation: str | None = ...
    end_session: str | None = ...
    userinfo: str | None = ...

async def discover(client: httpx.AsyncClient, issuer: str) -> Endpoints: ...

@dataclass(slots=True)
class DeviceGrant:
    device_code: str = field(repr=False)
    user_code: str
    verification_uri: str
    verification_uri_complete: str | None
    interval: float
    deadline: float

async def request_device_grant(client: httpx.AsyncClient, endpoints: Endpoints, *, client_id: str, scope: str, code_challenge: str) -> DeviceGrant: ...
async def poll_device_token(client: httpx.AsyncClient, endpoints: Endpoints, *, client_id: str, grant: DeviceGrant, code_verifier: str, cancel: asyncio.Event | None = None, sleep=...) -> dict:
    """Poll the token endpoint until authorization resolves; never outlives the grant."""
async def refresh_tokens(client: httpx.AsyncClient, token_endpoint: str, *, client_id: str, refresh_token: str) -> dict: ...
async def revoke_token(client: httpx.AsyncClient, revocation_endpoint: str | None, *, client_id: str, token: str) -> str | None:
    """Best-effort refresh-token revocation; returns an error description or None."""
def _rsa_public_key(jwk: dict): ...
def verify_id_token(id_token: str, *, issuer: str, client_id: str, jwks: dict, now: float | None = None) -> dict:
    """Validate an RS256 ID Token against the realm JWKS; returns its claims."""
async def fetch_jwks(client: httpx.AsyncClient, jwks_uri: str) -> dict: ...
def account_from(claims: dict, tokens: dict, *, issuer: str, client_id: str) -> dict:
    """Credential document stored in ~/.wth; tokens stay out of logs/history."""
