import asyncio
from . import settings as settings
from .errors import BusyError as BusyError, ManagementError as ManagementError
from .presentation import safe_value as safe_value, tool_outcome as tool_outcome
from .web_approvals import APPROVAL_OWNER as APPROVAL_OWNER
from _typeshed import Incomplete
from collections.abc import Generator
from dataclasses import dataclass, field
from wit.agents import InvocationRequest as InvocationRequest
from wit.attachments import ATTACHMENTS as ATTACHMENTS, AttachmentError as AttachmentError
from wit.components import ComponentState as ComponentState
from wit.conversation import AssistantMessage as AssistantMessage, ReasoningPart as ReasoningPart, TextPart as TextPart, content_text as content_text
from wit.errors import InvocationCancelledError as InvocationCancelledError, ToolOutcomeUnknownError as ToolOutcomeUnknownError
from wit.loops import ReActLoopComponent as ReActLoopComponent, ReActState as ReActState
from wit.providers.openai import GatewayAdapter as GatewayAdapter, OpenAIModelComponent as OpenAIModelComponent

class _WebChatHistoryAdapter(GatewayAdapter):
    """Keep Chat history portable without replaying provider reasoning fields.

    The framework retains reasoning in its structured result. This text chat
    host explicitly excludes it from subsequent Chat Completions requests,
    including requests following a tool call within the same turn.
    """
    name: str
    added_input_modalities: Incomplete
    async def adapt_request(self, request, context): ...

def _present_text(prompt, text, tools, *, has_attachments: bool = False):
    """Apply the same execution-evidence checks to live and final text."""

@dataclass
class Conversation:
    history: list = field(default_factory=list)
    messages: list = field(default_factory=list)
    cancellation: asyncio.Event = field(default_factory=asyncio.Event)
    task: object = ...
    attachment_owner: str = field(default_factory=Incomplete)
    attachment_service: object = ...
    pending_attachments: list = field(default_factory=list)
    @property
    def active(self): ...
    async def stop(self) -> None: ...
    async def clear(self) -> None: ...

class _WebLoop(ReActLoopComponent):
    """Seed a normal ephemeral ReAct turn with this browser's committed history."""
    host: Incomplete
    def __init__(self, host) -> None: ...
    def _start_invocation(self, invocation, committed_state): ...
    async def _stream_loop(self, execution) -> Generator[Incomplete]: ...

class WebChat:
    session_scope: Incomplete
    manager: Incomplete
    model_factory: Incomplete
    lock: Incomplete
    current: Incomplete
    pending_history: Incomplete
    model_handle: Incomplete
    loop_handle: Incomplete
    signature: Incomplete
    turn_key: Incomplete
    loop: Incomplete
    def __init__(self, manager, *, model_factory=..., session_scope=...) -> None: ...
    def attachment_service(self): ...
    def attachment_info(self, conversation, ids): ...
    def describe(self, conversation): ...
    async def _configure(self, config): ...
    async def open(self, conversation, prompt, *, owner=None, attachment_ids=()): ...
