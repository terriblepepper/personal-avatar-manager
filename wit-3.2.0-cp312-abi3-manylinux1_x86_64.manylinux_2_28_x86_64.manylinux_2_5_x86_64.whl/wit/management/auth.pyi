import argparse
import asyncio
import httpx
from contextlib import asynccontextmanager
from wit.management.credentials import CredentialLocked as CredentialLocked, CredentialStore as CredentialStore, PASSPHRASE_ENV as PASSPHRASE_ENV
from wit.management.oidc import LoginCancelled as LoginCancelled, OidcError as OidcError, account_from as account_from, discover as discover, fetch_jwks as fetch_jwks, generate_pkce as generate_pkce, poll_device_token as poll_device_token, refresh_tokens as refresh_tokens, request_device_grant as request_device_grant, revoke_token as revoke_token, verify_id_token as verify_id_token
from wit.management.settings import ConfigError as ConfigError, oidc_settings as oidc_settings

def auth_parser() -> argparse.ArgumentParser: ...
def _resolve_passphrase(encrypt: bool) -> str | None:
    """Hidden-input passphrase; never a CLI argument, never stored."""
def _passphrase_for(store: CredentialStore) -> str | None:
    """Passphrase needed to open an existing encrypted store."""
@asynccontextmanager
async def _http(client: httpx.AsyncClient | None):
    """Borrow a caller-owned client without closing it; own the one we create."""
async def device_login(store: CredentialStore, *, issuer: str, client_id: str, scope: str, display, client: httpx.AsyncClient | None = None, cancel: asyncio.Event | None = None, sleep=...) -> dict:
    """Run the device grant to completion; ``display(grant)`` shows the link/code."""
async def logout(store: CredentialStore, *, client: httpx.AsyncClient | None = None) -> tuple[dict | None, str | None]:
    """Revoke the refresh token remotely when possible; always clear locally.

    Returns ``(account, remote_error)``. Remote outages never prevent local
    clearing; unsafe linked storage is rejected explicitly by CredentialStore.
    """
async def ensure_fresh(store: CredentialStore, *, client: httpx.AsyncClient | None = None, issuer: str | None = None, client_id: str | None = None, cancel: asyncio.Event | None = None) -> dict | None:
    """Load the account, refreshing the access token when it has expired."""
async def flux_access_token(*, store: CredentialStore | None = None, client: httpx.AsyncClient | None = None) -> str | None:
    """Host-owned Flux token bridge; never passes credentials through model tools."""
def _expiry_line(account: dict) -> str: ...
async def run_auth_command(argv: list[str], *, store: CredentialStore | None = None, client: httpx.AsyncClient | None = None) -> int: ...
