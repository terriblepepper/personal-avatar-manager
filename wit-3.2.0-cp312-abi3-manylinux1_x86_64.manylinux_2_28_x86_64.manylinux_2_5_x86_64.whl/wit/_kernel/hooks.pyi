from _typeshed import Incomplete
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass
from typing import Any, ClassVar, Generic, TypeVar, TypeVarTuple
from wit._kernel.effects import EffectHandle
from wit._kernel.introspection import HookSnapshot
from wit.components.context import Context
from wit.errors import HookContractError as HookContractError

__all__ = ['BroadcastHookKey', 'EmitHookKey', 'HookContractError', 'HookDispatch', 'HookDisposer', 'HookKey', 'HookMode', 'HookRegistry', 'InterceptHookKey', 'SequentialHookKey']

HookMode: Incomplete
HookArgs = TypeVarTuple('HookArgs')
HookResult = TypeVar('HookResult')
CallT = TypeVar('CallT')

class HookKey(Generic[*HookArgs, HookResult]):
    """A typed name for one Hook dispatch contract."""
    _mode: ClassVar[HookMode | None]
    _name: Incomplete
    def __init__(self, name: str) -> None: ...
    @property
    def name(self) -> str:
        """The stable Hook registry name."""
    @property
    def mode(self) -> HookMode:
        """The dispatch mode fixed by the concrete Key type."""
    @property
    def argument_types(self) -> tuple[object, ...]:
        """The declared positional input types."""
    @property
    def result_type(self) -> object:
        """The declared result type."""
    def require_contract(self) -> tuple[tuple[object, ...], object]:
        """Return the runtime type contract or reject an unparameterized Key."""
    def _identity(self) -> tuple[str, HookMode, tuple[object, ...], object]: ...
    @property
    def contract_text(self) -> str: ...
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def __hash__(self) -> int: ...

class EmitHookKey(HookKey[*HookArgs, HookResult]):
    """A Key for a single-result emit Hook."""
    _mode: str

class BroadcastHookKey(HookKey[*HookArgs, HookResult]):
    """A Key for a broadcast Hook."""
    _mode: str

class InterceptHookKey(HookKey[*HookArgs, HookResult]):
    """A Key for a continuation-based intercept Hook."""
    _mode: str

class SequentialHookKey(HookKey[CallT, None]):
    """A Key for ordered handlers sharing one Call and discarding their results."""
    _mode: str
    def require_contract(self) -> tuple[tuple[object, ...], object]: ...
type _ErasedHookKey = HookKey[*tuple[Any, ...], Any]

@dataclass(slots=True)
class _HookHandler:
    context: Context
    callback: Callable[..., object]
    original_callback: Callable[..., object]
    once: bool
    prepend: bool
    scoped: bool
    filter: Callable[[HookDispatch], bool] | None
    disposer: HookDisposer
    _claimed: bool = ...
    def claim(self) -> bool:
        """Reserve a selected once handler synchronously, before dispatch can yield."""

@dataclass(frozen=True, slots=True)
class HookDispatch:
    """Read-only Hook dispatch data supplied to handler filters."""
    key: _ErasedHookKey
    context: Context
    carrier: object
    metadata: Mapping[str, object]
    @property
    def mode(self) -> HookMode: ...
    @property
    def name(self) -> str: ...

class HookDisposer:
    """Synchronous, idempotent handler disposer."""
    _effect: EffectHandle | None
    def __init__(self) -> None: ...
    def _bind(self, effect: EffectHandle) -> None: ...
    def __call__(self) -> bool: ...

class HookRegistry:
    """One permanent contract registry shared by every context in an agent."""
    _contracts: dict[str, _ErasedHookKey]
    _handlers: dict[str, list[_HookHandler]]
    _registration_waiters: dict[str, list[tuple[Callable[[], None], HookDisposer]]]
    def __init__(self) -> None: ...
    def _prepare_contract[*HookArgs, HookResult](self, key: HookKey[*HookArgs, HookResult]) -> HookKey[*HookArgs, HookResult]: ...
    def _commit_contract(self, key: _ErasedHookKey) -> None: ...
    def _require_mode[*HookArgs, HookResult](self, key: HookKey[*HookArgs, HookResult], method: HookMode) -> None: ...
    def _validate_arguments[*HookArgs, HookResult](self, key: HookKey[*HookArgs, HookResult], args: tuple[*HookArgs]) -> None: ...
    def _validate_result[*HookArgs, HookResult](self, key: HookKey[*HookArgs, HookResult], result: object) -> HookResult: ...
    def _validate_handler[*HookArgs, HookResult](self, key: HookKey[*HookArgs, HookResult], callback: Callable[..., object]) -> None: ...
    def register[*HookArgs, HookResult](self, context: Context, key: HookKey[*HookArgs, HookResult], callback: Callable[..., object], *, once: bool, prepend: bool, scoped: bool, filter: Callable[[HookDispatch], bool] | None) -> HookDisposer: ...
    def _when_registered(self, context: Context, key: HookKey[*tuple[Any, ...], Any], callback: Callable[[], None]) -> None: ...
    def _has_handlers(self, key: HookKey[*tuple[Any, ...], Any]) -> bool: ...
    def snapshot(self) -> tuple[HookSnapshot, ...]:
        """Capture metadata for every currently registered handler."""
    def _dispatch[*HookArgs, HookResult](self, mode: HookMode, context: Context, key: HookKey[*HookArgs, HookResult], args: tuple[*HookArgs], *, carrier: object = None, metadata: Mapping[str, object] | None = None) -> tuple[_HookHandler, ...]: ...
    def emit[*HookArgs, HookResult](self, context: Context, key: EmitHookKey[*HookArgs, HookResult], *args: *HookArgs, carrier: object = None, metadata: Mapping[str, object] | None = None) -> tuple[HookResult, ...]: ...
    async def broadcast[*HookArgs, HookResult](self, context: Context, key: BroadcastHookKey[*HookArgs, HookResult], *args: *HookArgs, carrier: object = None, metadata: Mapping[str, object] | None = None) -> tuple[HookResult, ...]: ...
    async def sequential[CallT](self, context: Context, key: SequentialHookKey[CallT], call: CallT) -> None:
        """Await handlers in order with one shared Call, ignoring their results."""
    async def intercept[*HookArgs, HookResult](self, context: Context, key: InterceptHookKey[*HookArgs, HookResult], *args: *tuple[*HookArgs, Callable[[*HookArgs], HookResult | Awaitable[HookResult]]], carrier: object = None, metadata: Mapping[str, object] | None = None) -> HookResult: ...
