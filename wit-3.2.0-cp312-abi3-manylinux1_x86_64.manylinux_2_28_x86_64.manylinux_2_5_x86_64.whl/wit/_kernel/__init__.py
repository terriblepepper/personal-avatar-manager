"""Private runtime machinery for Wit public domains."""

__all__: tuple[str, ...] = ()
