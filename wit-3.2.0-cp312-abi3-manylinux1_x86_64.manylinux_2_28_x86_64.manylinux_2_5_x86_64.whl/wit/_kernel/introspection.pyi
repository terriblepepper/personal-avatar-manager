from collections.abc import Callable
from dataclasses import dataclass
from wit._kernel.hooks import HookDispatch, HookMode, _ErasedHookKey
from wit._kernel.registry import ComponentHandle
from wit.components.component import ComponentState, EffectInfo, ServiceKey
from wit.components.context import Context

__all__ = ['ComponentSnapshot', 'DependencySnapshot', 'HookSnapshot', 'KernelSnapshot', 'ServiceSnapshot']

@dataclass(frozen=True, slots=True)
class DependencySnapshot:
    """One declared component dependency and its current provider binding."""
    service: ServiceKey[object]
    declared_provider: ComponentHandle | None
    provider: ComponentHandle | None
    value: object
    bound: bool
    required: bool = ...

@dataclass(frozen=True, slots=True)
class ComponentSnapshot:
    """Lifecycle and capability state captured for one component handle."""
    handle: ComponentHandle
    state: ComponentState
    required: bool
    parent: ComponentHandle | None
    children: tuple[ComponentHandle, ...]
    dependencies: tuple[DependencySnapshot, ...]
    unmet_dependencies: tuple[DependencySnapshot, ...]
    last_error: BaseException | None
    last_check_error: BaseException | None
    cleanup_errors: tuple[BaseException, ...]
    effects: tuple[EffectInfo, ...]

@dataclass(frozen=True, slots=True)
class ServiceSnapshot:
    """One declared service slot and its current live binding, if present."""
    service: ServiceKey[object]
    scope: object
    registrant: ComponentHandle
    provider: ComponentHandle | None
    value: object
    check: Callable[[], bool] | None
    bound: bool

@dataclass(frozen=True, slots=True)
class HookSnapshot:
    """One currently registered typed Hook handler."""
    key: _ErasedHookKey
    order: int
    owner: ComponentHandle | None
    context: Context
    callback: Callable[..., object]
    once: bool
    prepend: bool
    scoped: bool
    filter: Callable[[HookDispatch], bool] | None
    @property
    def name(self) -> str: ...
    @property
    def mode(self) -> HookMode: ...

@dataclass(frozen=True, slots=True)
class KernelSnapshot:
    """Read-only point-in-time view of the component kernel."""
    components: tuple[ComponentSnapshot, ...]
    services: tuple[ServiceSnapshot, ...]
    hooks: tuple[HookSnapshot, ...]
    root_effects: tuple[EffectInfo, ...]
