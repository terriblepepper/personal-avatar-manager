from _typeshed import Incomplete
from dataclasses import dataclass
from wit.components.component import ComponentState

__all__ = ['COMPONENT_LIFECYCLE_EVENT_HOOK', 'ComponentLifecycleEvent']

@dataclass(frozen=True, slots=True)
class ComponentLifecycleEvent:
    component_id: str
    component_name: str
    state: ComponentState
    error: BaseException | None = ...

COMPONENT_LIFECYCLE_EVENT_HOOK: Incomplete
