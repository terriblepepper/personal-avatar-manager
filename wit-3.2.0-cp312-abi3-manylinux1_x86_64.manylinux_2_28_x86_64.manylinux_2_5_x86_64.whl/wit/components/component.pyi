from dataclasses import dataclass
from enum import StrEnum
from typing import Any
from wit.components.context import Context as Context

@dataclass(frozen=True, slots=True)
class ServiceKey[ServiceT]:
    """A typed, stable key for one service contract."""
    name: str
    def __post_init__(self) -> None: ...
    def __str__(self) -> str: ...

class ComponentState(StrEnum):
    """Lifecycle state of one installed component instance."""
    PENDING = 'pending'
    LOADING = 'loading'
    ACTIVE = 'active'
    FAILED = 'failed'
    UNLOADING = 'unloading'
    DISPOSED = 'disposed'

@dataclass(frozen=True, slots=True)
class EffectInfo:
    """Read-only diagnostics for one live effect."""
    label: str
    children: tuple[EffectInfo, ...] = ...

class ContextualService:
    """Opt-in marker for services whose calls need the caller Context."""

class WitComponent[ConfigT]:
    """Single, instance-based contract implemented by component authors."""
    name: str | None
    requires: tuple[ServiceKey[Any], ...]
    optional_requires: tuple[ServiceKey[Any], ...]
    provides: tuple[ServiceKey[Any], ...]
    def validate_config(self, config: object) -> ConfigT:
        """Validate and optionally normalize config before installation."""
    async def setup(self, ctx: Context) -> object:
        """Create this activation's services, Hooks, and effects."""
    async def teardown(self, ctx: Context) -> None:
        """Run before owned effects are released for an activation."""

def validate_service_declaration(value: object, *, field: str) -> tuple[ServiceKey[Any], ...]: ...
