"""Component authoring and lifecycle API."""

from typing import TYPE_CHECKING

from wit._kernel.effects import EffectHandle
from wit.components.component import (
    ComponentState,
    ContextualService,
    EffectInfo,
    ServiceKey,
    WitComponent,
)
from wit.components.context import Context
from wit.components.lifecycle import COMPONENT_LIFECYCLE_EVENT_HOOK, ComponentLifecycleEvent

if TYPE_CHECKING:
    from wit._kernel.registry import ComponentHandle, ComponentRegistry

__all__ = (
    "COMPONENT_LIFECYCLE_EVENT_HOOK",
    "ComponentHandle",
    "ComponentLifecycleEvent",
    "ComponentRegistry",
    "ComponentState",
    "Context",
    "ContextualService",
    "EffectHandle",
    "EffectInfo",
    "ServiceKey",
    "WitComponent",
)


def __getattr__(name: str) -> object:
    if name in {"ComponentHandle", "ComponentRegistry"}:
        from wit._kernel.registry import ComponentHandle, ComponentRegistry

        return {"ComponentHandle": ComponentHandle, "ComponentRegistry": ComponentRegistry}[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
