"""Agent Loop contracts and implementations."""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from wit.loops.base import BaseAgentLoopComponent
    from wit.loops.execution import LoopExecution
    from wit.loops.react import ReActCursor, ReActLoopComponent, ReActPhase, ReActState
    from wit.loops.workflow import (
        BranchResult,
        Send,
        WorkflowApproval,
        WorkflowConflictError,
        WorkflowContext,
        WorkflowError,
        WorkflowGraph,
        WorkflowLoopComponent,
        WorkflowResult,
        WorkflowResume,
        WorkflowResumeError,
    )

__all__ = (
    "BaseAgentLoopComponent",
    "BranchResult",
    "LoopExecution",
    "ReActCursor",
    "ReActLoopComponent",
    "ReActPhase",
    "ReActState",
    "Send",
    "WorkflowApproval",
    "WorkflowConflictError",
    "WorkflowContext",
    "WorkflowError",
    "WorkflowGraph",
    "WorkflowLoopComponent",
    "WorkflowResult",
    "WorkflowResume",
    "WorkflowResumeError",
)


def __getattr__(name: str) -> object:
    if name == "BaseAgentLoopComponent":
        from wit.loops.base import BaseAgentLoopComponent

        return BaseAgentLoopComponent
    if name == "LoopExecution":
        from wit.loops.execution import LoopExecution

        return LoopExecution
    if name in {"ReActCursor", "ReActLoopComponent", "ReActPhase", "ReActState"}:
        from wit.loops.react import ReActCursor, ReActLoopComponent, ReActPhase, ReActState

        return {
            "ReActCursor": ReActCursor,
            "ReActLoopComponent": ReActLoopComponent,
            "ReActPhase": ReActPhase,
            "ReActState": ReActState,
        }[name]
    if name in {
        "WorkflowResult",
        "WorkflowLoopComponent",
        "WorkflowContext",
        "WorkflowResumeError",
        "WorkflowError",
        "WorkflowResume",
        "WorkflowApproval",
        "WorkflowConflictError",
        "BranchResult",
        "Send",
        "WorkflowGraph",
    }:
        from wit.loops import workflow

        return getattr(workflow, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
