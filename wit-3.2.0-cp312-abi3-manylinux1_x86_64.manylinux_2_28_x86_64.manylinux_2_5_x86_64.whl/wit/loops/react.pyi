from _typeshed import Incomplete
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from enum import StrEnum
from wit.agents.invocation import InvocationContext, InvocationEvent
from wit.conversation import AssistantMessage, Message
from wit.loops.base import BaseAgentLoopComponent
from wit.loops.execution import LoopExecution

__all__ = ['ReActCursor', 'ReActLoopComponent', 'ReActPhase', 'ReActState']

class ReActPhase(StrEnum):
    """Next safe ReAct action."""
    MODEL = 'model'
    TOOL = 'tool'
    COMPLETE = 'complete'

@dataclass(slots=True)
class ReActState:
    """Conversation and developer-owned short-term state for one thread."""
    messages: list[Message] = field(default_factory=list)
    custom: dict[str, object] = field(default_factory=dict)
    finish_reason: str | None = ...
    model_metadata: dict[str, object] = field(default_factory=dict)
    def __post_init__(self) -> None: ...

@dataclass(frozen=True, slots=True)
class ReActCursor:
    """Safe ReAct continuation point within one logical invocation."""
    phase: ReActPhase
    step: int
    tool_index: int = ...
    def __post_init__(self) -> None: ...

class ReActLoopComponent(BaseAgentLoopComponent[ReActState, ReActCursor]):
    """Drive a checkpoint-safe structured model, Tool, observation loop."""
    requires: Incomplete
    checkpoint_schema_version: str
    instructions: Incomplete
    max_steps: Incomplete
    def __init__(self, *, instructions: str | None = None, max_steps: int = 16) -> None: ...
    def _start_invocation(self, invocation: InvocationContext, committed_state: ReActState | None) -> tuple[ReActState, ReActCursor]: ...
    async def _stream_loop(self, execution: LoopExecution[ReActState, ReActCursor]) -> AsyncIterator[InvocationEvent]: ...
    @staticmethod
    def _current_invocation_tool_call_ids(state: ReActState) -> set[str]: ...
    @staticmethod
    def _pending_assistant(state: ReActState, cursor: ReActCursor) -> AssistantMessage: ...
    @staticmethod
    def _final_assistant(state: ReActState) -> AssistantMessage: ...
