from _typeshed import Incomplete
from collections.abc import AsyncIterator
from wit.agents.entry import BaseAgentEntryComponent
from wit.agents.invocation import InvocationContext, InvocationEvent, InvocationResult
from wit.loops.execution import LoopExecution

__all__ = ['BaseAgentLoopComponent']

class BaseAgentLoopComponent[StateT, CursorT](BaseAgentEntryComponent):
    """State execution shell for ephemeral and checkpoint-backed Agent Loops."""
    optional_requires: Incomplete
    _loop_executions: dict[str, LoopExecution[StateT, CursorT] | InvocationResult]
    def __init__(self) -> None: ...
    checkpoint_schema_version: str
    async def _probe_entry_execution(self, invocation: InvocationContext) -> InvocationResult | None: ...
    async def _prepare_entry_execution(self, invocation: InvocationContext) -> None: ...
    async def _stream(self, invocation: InvocationContext) -> AsyncIterator[InvocationEvent]: ...
    async def _finalize_entry_execution(self, invocation: InvocationContext, result: InvocationResult) -> InvocationResult: ...
    async def _abort_entry_execution(self, invocation: InvocationContext, error: BaseException) -> None: ...
    def _start_invocation(self, invocation: InvocationContext, committed_state: StateT | None) -> tuple[StateT, CursorT]:
        """Create working State and Cursor after the effective request is known."""
    async def _stream_loop(self, execution: LoopExecution[StateT, CursorT]) -> AsyncIterator[InvocationEvent]:
        """Advance one concrete Loop from the supplied State and Cursor."""
    @staticmethod
    def check_cancelled(invocation: InvocationContext) -> None: ...
