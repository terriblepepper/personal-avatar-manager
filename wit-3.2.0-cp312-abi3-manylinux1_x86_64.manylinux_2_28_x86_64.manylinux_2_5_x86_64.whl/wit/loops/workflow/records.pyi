from dataclasses import dataclass, field
from wit.loops.workflow.contracts import BranchResult as BranchResult, WorkflowApproval as WorkflowApproval

@dataclass
class Task:
    execution_id: str
    node: str
    scope: str
    input: object
    ancestors: set[str]
    stack: tuple[tuple[str, str], ...] = ...
    status: str = ...
    attempt: int = ...
    base: dict = field(default_factory=dict)
    output: object = ...
    route: object = ...
    effects: dict = field(default_factory=dict)
    pending_effects: set[str] = field(default_factory=set)
    answers: dict = field(default_factory=dict)
    error: str | None = ...

@dataclass
class Frame:
    scope: str
    join: str
    keys: tuple[str, ...]
    stack: tuple[tuple[str, str], ...]
    ancestors: set[str]
    results: dict[str, BranchResult] = field(default_factory=dict)

@dataclass
class Scope:
    path: tuple[str, ...]
    state: dict
    parent: str | None = ...
    writers: dict = field(default_factory=dict)
    output: object = ...
    done: bool = ...

@dataclass
class Cursor:
    tasks: dict[str, Task] = field(default_factory=dict)
    frames: dict[str, Frame] = field(default_factory=dict)
    scopes: dict[str, Scope] = field(default_factory=dict)
    waiting: dict[str, WorkflowApproval] = field(default_factory=dict)
    pending_effects: set[str] = field(default_factory=set)
    sequence: int = ...
