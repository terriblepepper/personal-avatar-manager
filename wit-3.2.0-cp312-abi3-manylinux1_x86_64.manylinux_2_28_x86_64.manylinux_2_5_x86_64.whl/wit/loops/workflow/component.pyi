from _typeshed import Incomplete
from collections.abc import Generator
from wit.agents.invocation import InvocationResult as InvocationResult
from wit.checkpoints import CHECKPOINT_RUNTIME as CHECKPOINT_RUNTIME
from wit.components import ServiceKey as ServiceKey
from wit.loops.base import BaseAgentLoopComponent as BaseAgentLoopComponent
from wit.loops.workflow.contracts import WorkflowResume as WorkflowResume, WorkflowResumeError as WorkflowResumeError
from wit.loops.workflow.graph import WorkflowGraph as WorkflowGraph
from wit.loops.workflow.records import Cursor as Cursor, Scope as Scope
from wit.loops.workflow.scheduler import ROOT as ROOT, Scheduler as Scheduler, new_task as new_task
from wit.loops.workflow.state import snapshot as snapshot, state_copy as state_copy
from wit.models import MODEL as MODEL
from wit.tools import TOOL_RUNTIME as TOOL_RUNTIME

class WorkflowLoopComponent(BaseAgentLoopComponent[dict, Cursor]):
    optional_requires: Incomplete
    requires: Incomplete
    graph: Incomplete
    max_concurrency: Incomplete
    max_steps: Incomplete
    checkpoint_schema_version: Incomplete
    def __init__(self, graph: WorkflowGraph, *, max_concurrency: int = 8, max_steps: int = 10000, services: tuple[ServiceKey, ...] = ()) -> None: ...
    def _start_invocation(self, invocation, committed_state): ...
    async def _probe_entry_execution(self, invocation): ...
    async def _prepare_entry_execution(self, invocation) -> None: ...
    async def _stream_loop(self, execution) -> Generator[Incomplete]: ...
    async def _finalize_entry_execution(self, invocation, result): ...
