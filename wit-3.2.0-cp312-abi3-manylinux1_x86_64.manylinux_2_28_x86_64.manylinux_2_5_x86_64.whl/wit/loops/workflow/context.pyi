import asyncio
from _typeshed import Incomplete
from collections.abc import Awaitable, Callable as Callable
from dataclasses import dataclass
from wit.agents.invocation import InvocationContext as InvocationContext, InvocationEvent as InvocationEvent
from wit.loops.workflow._callbacks import validate_callback as validate_callback
from wit.loops.workflow.contracts import WorkflowApproval as WorkflowApproval, WorkflowError as WorkflowError
from wit.loops.workflow.state import snapshot as snapshot
from wit.tools import TOOL_RUNTIME as TOOL_RUNTIME, ToolResult as ToolResult

class ApprovalWait(Exception):
    approval: Incomplete
    def __init__(self, approval) -> None: ...

@dataclass
class Message:
    kind: str
    execution_id: str
    data: object = ...
    future: asyncio.Future | None = ...

class WorkflowContext:
    """One node attempt. Keep external mutations inside effect() or tool()."""
    state: dict[str, object]
    input: Incomplete
    execution_id: Incomplete
    node_id: Incomplete
    attempt: Incomplete
    namespace: Incomplete
    branches: Incomplete
    invocation: InvocationContext
    _task: Incomplete
    _mailbox: Incomplete
    _alive: Incomplete
    _inflight: Incomplete
    _activities: Incomplete
    def __init__(self, task, state, invocation, mailbox, alive) -> None: ...
    def _ensure_active(self) -> None: ...
    async def _request(self, kind, data): ...
    def _key(self, key): ...
    async def emit(self, data: object, *, kind: str = 'chunk') -> None: ...
    async def effect[ResultT](self, key: str, kind: str, operation: Callable[[str], ResultT | Awaitable[ResultT]]) -> ResultT:
        """Persist intent/result around operation(op_id), after validating its signature.

        Pass op_id to the external API as its idempotency key when supported.
        The callback may be synchronous or asynchronous; it takes one positional ID.
        """
    async def aclose(self) -> None:
        """Drain operations started through this context, including child Tasks."""
    async def tool(self, key: str, name: str, arguments: object) -> ToolResult: ...
    async def approve(self, key: str, prompt: object) -> object: ...
    def event(self, kind, data=None): ...
