from dataclasses import dataclass
from wit.agents.invocation import InvocationEntity as InvocationEntity, InvocationRequest as InvocationRequest, InvocationResult as InvocationResult

class WorkflowError(RuntimeError):
    """Invalid workflow execution or unsupported runtime value."""
class WorkflowConflictError(WorkflowError):
    """Independent executions changed the same business-state field."""
class WorkflowResumeError(WorkflowError):
    """Approval answers do not match the saved waiting protocol."""

@dataclass(frozen=True, slots=True)
class Send:
    key: str
    node: str
    input: object = ...

@dataclass(frozen=True, slots=True)
class BranchResult:
    key: str
    execution_id: str
    node_id: str
    output: object

@dataclass(frozen=True, slots=True)
class WorkflowResult:
    state: dict[str, object]
    output: object

@dataclass(frozen=True, slots=True)
class WorkflowApproval:
    approval_id: str
    execution_id: str
    key: str
    prompt: object

@dataclass(frozen=True, slots=True)
class WorkflowResume:
    answers: dict[str, object]
    def __post_init__(self) -> None: ...
    def to_request(self, waiting: InvocationResult, *, entity: InvocationEntity | None = None) -> InvocationRequest:
        """Resume a waiting result with its original thread and logical invocation IDs.

        For entity-scoped calls, explicitly supply the same trusted entity scope.
        Answers and the saved checkpoint are validated by the Workflow on invocation.
        """
