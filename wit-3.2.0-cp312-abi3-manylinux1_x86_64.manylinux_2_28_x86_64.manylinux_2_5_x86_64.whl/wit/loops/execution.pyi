from _typeshed import Incomplete
from collections.abc import Mapping
from wit.agents.invocation import InvocationContext, InvocationResult
from wit.checkpoints.contracts import CheckpointEffect, CheckpointRuntime, CheckpointVersion

__all__ = ['LoopExecution']

class LoopExecution[StateT, CursorT]:
    """One physical attempt over typed working State and a safe Cursor."""
    invocation: Incomplete
    state: Incomplete
    cursor: Incomplete
    options: Incomplete
    version: Incomplete
    resumed: Incomplete
    _runtime: Incomplete
    _ended: bool
    def __init__(self, invocation: InvocationContext, *, state: StateT, cursor: CursorT, options: Mapping[str, object], version: CheckpointVersion | None = None, resumed: bool = False, runtime: CheckpointRuntime | None = None) -> None: ...
    @property
    def thread_id(self) -> str | None: ...
    @property
    def invocation_id(self) -> str: ...
    @property
    def call_id(self) -> str: ...
    @property
    def persistent(self) -> bool: ...
    @property
    def ended(self) -> bool: ...
    async def checkpoint(self, *, state: StateT | object = ..., cursor: CursorT | object = ...) -> CheckpointVersion | None:
        """Save a complete business boundary using compare-and-set."""
    async def effects_checkpoint(self, *, state: StateT, cursor: CursorT, started: tuple[CheckpointEffect, ...] = (), resolved: tuple[str, ...] = ()) -> CheckpointVersion | None:
        """Coordinator boundary; publish local state only after successful persistence."""
    async def effect_started(self, operation_id: str, kind: str, *, state: StateT | object = ..., cursor: CursorT | object = ...) -> CheckpointVersion | None:
        """Persist an unsafe external-effect boundary before dispatch."""
    async def effect_committed(self, *, state: StateT | object = ..., cursor: CursorT | object = ...) -> CheckpointVersion | None:
        """Atomically save an effect result and return to a replay-safe cursor."""
    async def _complete_from_entry(self, result: InvocationResult) -> CheckpointVersion | None:
        """Commit the Entry-selected result; not a Loop authoring operation."""
    async def interrupt(self, reason: str | None = None) -> CheckpointVersion | None:
        """Release this attempt while retaining only its last saved boundary."""
    async def recovery_required(self, reason: str) -> CheckpointVersion | None:
        """Block automatic recovery when a Tool outcome may be ambiguous."""
    async def fail(self, error: BaseException) -> CheckpointVersion | None:
        """Record an unrecoverable invocation failure without committing State."""
    async def _finish_uncommitted(self, operation: str, *, reason: str | None = None, error: BaseException | None = None) -> CheckpointVersion | None: ...
    def _persistent_identity(self) -> tuple[str, CheckpointVersion]: ...
    def _ensure_open(self) -> None: ...
