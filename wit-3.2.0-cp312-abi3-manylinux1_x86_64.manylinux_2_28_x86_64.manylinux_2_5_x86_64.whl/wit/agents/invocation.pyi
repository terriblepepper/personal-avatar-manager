import asyncio
from _typeshed import Incomplete
from collections.abc import AsyncIterator, Mapping
from contextlib import AbstractContextManager
from dataclasses import dataclass, field
from datetime import datetime
from typing import Protocol
from wit.components import Context

__all__ = ['AGENT_ENTRY', 'AGENT_INVOCATION_AFTER_HOOK', 'AGENT_INVOCATION_BEFORE_HOOK', 'AGENT_INVOCATION_HOOK', 'AgentEntry', 'AgentInvocationAfter', 'AgentInvocationBefore', 'AgentInvocationEvent', 'InvocationContext', 'InvocationEntity', 'InvocationEvent', 'InvocationRequest', 'InvocationResult']

class InvocationEntity(Protocol):
    """Identity scope that can bind one execution and partition checkpoints."""
    @property
    def checkpoint_namespace(self) -> str: ...
    def bind(self) -> AbstractContextManager[None]: ...

class AgentEntry(Protocol):
    async def invoke(self, request: InvocationRequest) -> InvocationResult: ...
    def stream(self, request: InvocationRequest) -> AsyncIterator[InvocationEvent]: ...

class _InvocationCancellation(asyncio.Event):
    """Monotonic signal combining framework, request, and deadline cancellation."""
    _request_cancellation: Incomplete
    _deadline: Incomplete
    _request_changed: Incomplete
    _reason: str | None
    def __init__(self, request_cancellation: asyncio.Event | None = None, deadline: datetime | None = None) -> None: ...
    @property
    def reason(self) -> str | None: ...
    def bind_request(self, cancellation: asyncio.Event | None, deadline: datetime | None) -> None:
        """Replace the request signal without clearing cancellation already observed."""
    def is_set(self) -> bool: ...
    def _set(self, reason: str) -> None: ...
    def clear(self) -> None:
        """Keep effective invocation cancellation monotonic once published."""
    def set(self) -> None: ...
    async def wait(self) -> bool: ...

@dataclass(frozen=True, slots=True)
class InvocationRequest:
    """Developer input and per-call controls for one Agent execution."""
    input: object
    options: Mapping[str, object] = field(default_factory=dict)
    metadata: Mapping[str, object] = field(default_factory=dict)
    cancellation: asyncio.Event | None = ...
    deadline: datetime | None = ...
    thread_id: str | None = ...
    invocation_id: str | None = ...
    entity: InvocationEntity | None = ...
    def __post_init__(self) -> None: ...

@dataclass(slots=True)
class InvocationContext:
    """Short-lived context explicitly passed through one call path."""
    _call_id: str
    _thread_id: str | None
    _invocation_id: str
    request: InvocationRequest
    options: Mapping[str, object]
    deadline: datetime | None
    component_context: Context
    metadata: Mapping[str, object]
    closed: bool = ...
    _cancellation: _InvocationCancellation = field(default_factory=_InvocationCancellation, repr=False)
    _cancellation_reason: str | None = field(default=None, init=False, repr=False)
    def __post_init__(self) -> None: ...
    @classmethod
    def create(cls, request: InvocationRequest, *, component_context: Context) -> InvocationContext: ...
    @property
    def call_id(self) -> str:
        """Unique identity of this physical execution attempt."""
    @property
    def thread_id(self) -> str | None:
        """Identity of the persistent state line, when persistence is enabled."""
    @property
    def entity(self) -> InvocationEntity | None:
        """Trusted execution identity selection, separate from request metadata."""
    @property
    def checkpoint_thread_id(self) -> str | None: ...
    @property
    def invocation_id(self) -> str:
        """Identity of this logical invocation across attempts."""
    @property
    def tool_operation_id(self) -> str | None:
        """Stable logical Tool operation currently executing in this task."""
    @property
    def cancellation(self) -> asyncio.Event:
        """Return the monotonic signal for framework, request, or deadline cancellation."""
    @property
    def cancelled(self) -> bool: ...
    @property
    def deadline_reached(self) -> bool: ...
    def cancel(self) -> None: ...
    def raise_if_cancelled(self) -> None: ...
    def ensure_active(self) -> None: ...
    def close(self) -> None: ...
    def _replace_request(self, request: InvocationRequest) -> None:
        """Apply one before-Hook request replacement without changing call identity."""
    def _set_effective_options(self, options: Mapping[str, object]) -> None:
        """Apply options selected by a resumed logical invocation."""
    def _resolve_cancellation_reason(self) -> str | None: ...

@dataclass(frozen=True, slots=True)
class InvocationResult:
    """Final value and status for one successful Agent execution."""
    output: object = ...
    status: str = ...
    metadata: Mapping[str, object] = field(default_factory=dict)
    def __post_init__(self) -> None: ...

@dataclass(frozen=True, slots=True)
class AgentInvocationEvent:
    """Agent invocation information passed to an intercept handler as ``event``."""
    invocation: InvocationContext
    def __post_init__(self) -> None: ...
    @property
    def request(self) -> InvocationRequest: ...

class AgentInvocationBefore:
    """Mutable request slot shared by Agent invocation-before Hooks."""
    __slots__: Incomplete
    _invocation: Incomplete
    def __init__(self, invocation: InvocationContext, request: InvocationRequest) -> None: ...
    @property
    def invocation(self) -> InvocationContext: ...
    @property
    def request(self) -> InvocationRequest: ...
    _request: Incomplete
    @request.setter
    def request(self, value: InvocationRequest) -> None: ...

class AgentInvocationAfter:
    """Mutable result slot shared by Agent invocation-after Hooks."""
    __slots__: Incomplete
    _invocation: Incomplete
    def __init__(self, invocation: InvocationContext, result: InvocationResult) -> None: ...
    @property
    def invocation(self) -> InvocationContext: ...
    @property
    def request(self) -> InvocationRequest: ...
    @property
    def result(self) -> InvocationResult: ...
    _result: Incomplete
    @result.setter
    def result(self, value: InvocationResult) -> None: ...

@dataclass(frozen=True, slots=True)
class InvocationEvent:
    """One incremental or terminal event from an Agent execution."""
    kind: str
    data: object = ...
    result: InvocationResult | None = ...
    metadata: Mapping[str, object] = field(default_factory=dict)
    def __post_init__(self) -> None: ...
    @property
    def is_terminal(self) -> bool: ...
    @classmethod
    def final(cls, result: InvocationResult) -> InvocationEvent: ...

AGENT_ENTRY: Incomplete
AGENT_INVOCATION_BEFORE_HOOK: Incomplete
AGENT_INVOCATION_HOOK: Incomplete
AGENT_INVOCATION_AFTER_HOOK: Incomplete
