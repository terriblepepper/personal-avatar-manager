from _typeshed import Incomplete
from collections.abc import AsyncIterator
from typing import final
from wit.agents.execution import ActiveCallTracker
from wit.agents.invocation import InvocationContext, InvocationEvent, InvocationRequest, InvocationResult
from wit.components import Context
from wit.components.component import WitComponent

__all__ = ['BaseAgentEntryComponent']

class _AgentEntryServiceAdapter:
    """Framework-owned Agent Entry boundary around one Entry component."""
    __slots__: Incomplete
    _entry: Incomplete
    def __init__(self, entry: BaseAgentEntryComponent) -> None: ...
    async def invoke(self, request: InvocationRequest) -> InvocationResult: ...
    def stream(self, request: InvocationRequest) -> AsyncIterator[InvocationEvent]: ...

class BaseAgentEntryComponent(WitComponent[object]):
    """Framework execution shell around one developer-defined Entry stream."""
    provides: Incomplete
    def __init_subclass__(cls, **kwargs: object) -> None: ...
    _entry_context: Context | None
    _entry_calls: ActiveCallTracker | None
    def __init__(self) -> None: ...
    async def setup(self, ctx: Context) -> None: ...
    async def teardown(self, ctx: Context) -> None: ...
    async def setup_entry(self, ctx: Context) -> None:
        """Optionally acquire provider resources during component setup."""
    async def teardown_entry(self, ctx: Context) -> None:
        """Optionally release provider resources during component teardown."""
    @final
    async def invoke(self, request: InvocationRequest) -> InvocationResult:
        """Consume this Entry's managed stream and return its terminal result."""
    @final
    def stream(self, request: InvocationRequest) -> AsyncIterator[InvocationEvent]:
        """Stream this Entry through one managed InvocationContext and Agent Hook."""
    async def _stream(self, invocation: InvocationContext) -> AsyncIterator[InvocationEvent]:
        """Implement the complete developer-defined Agent execution flow."""
    async def _prepare_entry_execution(self, invocation: InvocationContext) -> None:
        """Internal extension point for the Loop shell."""
    async def _probe_entry_execution(self, invocation: InvocationContext) -> InvocationResult | None:
        """Internal replay probe used by the Loop shell before business Hooks."""
    async def _finalize_entry_execution(self, invocation: InvocationContext, result: InvocationResult) -> InvocationResult:
        """Internal extension point after Agent after Hooks select the result."""
    async def _abort_entry_execution(self, invocation: InvocationContext, error: BaseException) -> None:
        """Internal extension point for calls that end without a terminal result."""
    def _require_entry_context(self) -> Context: ...
    def _require_entry_tracker(self) -> ActiveCallTracker: ...
