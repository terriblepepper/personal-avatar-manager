import asyncio
from _typeshed import Incomplete
from collections.abc import AsyncIterator, Awaitable, Callable
from dataclasses import dataclass
from wit._kernel.hooks import InterceptHookKey
from wit.agents import InvocationContext
from wit.components import Context

__all__ = ['ActiveCallOwnership', 'ActiveCallTracker', 'ManagedAsyncIterator', 'close_async_iterator', 'ensure_same_agent_root', 'hooked_terminal_stream']

@dataclass(frozen=True, slots=True)
class _StreamFailure:
    error: BaseException

@dataclass(frozen=True, slots=True)
class _StreamItem[EventT]:
    event: EventT
    consumed: asyncio.Future[None]

async def close_async_iterator(iterator: AsyncIterator[object]) -> None:
    """Close an async iterator when it exposes the optional close protocol."""

class ManagedAsyncIterator[EventT]:
    """Add eager ownership and first-use checks around any async iterator."""
    _source: Incomplete
    _before_first: Incomplete
    _on_close: Incomplete
    _started: bool
    _closed: bool
    def __init__(self, source: AsyncIterator[EventT], *, before_first: Callable[[], None] | None = None, on_close: Callable[[], None] | None = None) -> None: ...
    def __aiter__(self) -> ManagedAsyncIterator[EventT]: ...
    async def __anext__(self) -> EventT: ...
    async def aclose(self) -> None: ...

class ActiveCallOwnership:
    """One call lifetime registered before an execution task necessarily exists."""
    _tracker: Incomplete
    _cancel: Incomplete
    _finish: Incomplete
    _active: bool
    def __init__(self, tracker: ActiveCallTracker, *, cancel: Callable[[], None], finish: Callable[[], None]) -> None: ...
    def cancel(self) -> None: ...
    def finish(self) -> None: ...

def ensure_same_agent_root(invocation: InvocationContext, owner_context: Context, *, service: str) -> None:
    """Keep one explicit InvocationContext inside the Agent root that owns the service."""

class ActiveCallTracker:
    """Own active execution tasks until a component activation is torn down."""
    _label: Incomplete
    _tasks: dict[asyncio.Task[object], int]
    _cancellers: dict[asyncio.Task[object], list[Callable[[], None]]]
    _ownerships: set[ActiveCallOwnership]
    _failures: list[BaseException]
    _closing: bool
    def __init__(self, label: str) -> None: ...
    def open_call(self, *, cancel: Callable[[], None], finish: Callable[[], None]) -> ActiveCallOwnership: ...
    def add(self, task: asyncio.Task[object], *, cancel: Callable[[], None] | None = None) -> None: ...
    def discard(self, task: asyncio.Task[object]) -> None: ...
    def record_failure(self, error: BaseException) -> None: ...
    def _release_ownership(self, ownership: ActiveCallOwnership) -> None: ...
    async def close(self) -> None: ...

async def hooked_terminal_stream[EventT, *HookArgs, ResultT](*, context: Context, hook_key: InterceptHookKey[*HookArgs, ResultT], hook_args: Callable[[], tuple[*HookArgs]], before: Callable[[], Awaitable[None]], after: Callable[[ResultT], Awaitable[ResultT]], stream_factory: Callable[[], AsyncIterator[EventT]], event_type: type[EventT], result_type: type[ResultT], is_terminal: Callable[[EventT], bool], get_result: Callable[[EventT], ResultT | None], make_terminal: Callable[[ResultT], EventT], tracker: ActiveCallTracker, cancel: Callable[[], None] | None, ensure_active: Callable[[], None], producer_started: Callable[[asyncio.Task[object]], None] | None = None, probe: Callable[[], Awaitable[ResultT | None]] | None = None, abort: Callable[[BaseException], Awaitable[None]] | None = None, settled: Callable[[], None] | None = None) -> AsyncIterator[EventT]:
    """Stream increments while one intercept Hook owns the final result."""
