"""Agent entry, invocation, execution, and container APIs."""

from typing import TYPE_CHECKING

from wit.agents.invocation import (
    AGENT_ENTRY,
    AGENT_INVOCATION_AFTER_HOOK,
    AGENT_INVOCATION_BEFORE_HOOK,
    AGENT_INVOCATION_HOOK,
    AgentEntry,
    AgentInvocationAfter,
    AgentInvocationBefore,
    AgentInvocationEvent,
    InvocationContext,
    InvocationEntity,
    InvocationEvent,
    InvocationRequest,
    InvocationResult,
)

if TYPE_CHECKING:
    from wit.agents.agent import WitAgent
    from wit.agents.entry import BaseAgentEntryComponent

__all__ = (
    "AGENT_ENTRY",
    "AGENT_INVOCATION_AFTER_HOOK",
    "AGENT_INVOCATION_BEFORE_HOOK",
    "AGENT_INVOCATION_HOOK",
    "AgentEntry",
    "AgentInvocationAfter",
    "AgentInvocationBefore",
    "AgentInvocationEvent",
    "BaseAgentEntryComponent",
    "InvocationContext",
    "InvocationEntity",
    "InvocationEvent",
    "InvocationRequest",
    "InvocationResult",
    "WitAgent",
)


def __getattr__(name: str) -> object:
    if name == "BaseAgentEntryComponent":
        from wit.agents.entry import BaseAgentEntryComponent

        return BaseAgentEntryComponent
    if name == "WitAgent":
        from wit.agents.agent import WitAgent

        return WitAgent
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
