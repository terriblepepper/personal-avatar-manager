from _typeshed import Incomplete
from wit.checkpoints.component import BaseCheckpointComponent
from wit.checkpoints.contracts import CheckpointCodec, CheckpointVersion, ThreadCheckpoint

__all__ = ['InMemoryCheckpointComponent']

class InMemoryCheckpointComponent(BaseCheckpointComponent):
    """Same-process current-state Checkpoint backend."""
    name: str
    _threads: dict[str, ThreadCheckpoint]
    _storage_lock: Incomplete
    def __init__(self, *, codec: CheckpointCodec | None = None) -> None: ...
    async def _load_thread(self, thread_id: str) -> ThreadCheckpoint | None: ...
    async def _store_thread(self, thread_id: str, checkpoint: ThreadCheckpoint, *, expected_version: CheckpointVersion | None) -> None: ...
