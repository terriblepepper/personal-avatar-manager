"""Optional attachment integration for hosts, models, and component authors."""

from .component import BaseAttachmentComponent
from .contracts import (
    ATTACHMENTS,
    AttachmentCapabilities,
    AttachmentError,
    AttachmentInfo,
    AttachmentService,
)

__all__ = (
    "ATTACHMENTS",
    "AttachmentCapabilities",
    "AttachmentError",
    "AttachmentInfo",
    "AttachmentService",
    "BaseAttachmentComponent",
)
