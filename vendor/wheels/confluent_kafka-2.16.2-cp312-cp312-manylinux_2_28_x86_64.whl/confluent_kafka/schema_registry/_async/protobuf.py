#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright 2020-2022 Confluent Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import asyncio as _locks
import io
from typing import Any, Awaitable, Callable, Coroutine, Dict, List, Optional, Set, Tuple, Union, cast

from google.protobuf import descriptor_pb2, json_format
from google.protobuf.descriptor import Descriptor, FileDescriptor
from google.protobuf.descriptor_pool import DescriptorPool
from google.protobuf.message import DecodeError, Message
from google.protobuf.message_factory import GetMessageClass

from confluent_kafka.schema_registry import (
    RuleMode,
    Schema,
    SchemaReference,
    dual_schema_id_deserializer,
    prefix_schema_id_serializer,
    reference_subject_name_strategy,
)
from confluent_kafka.schema_registry.common import asyncinit
from confluent_kafka.schema_registry.common.protobuf import (
    PROTOBUF_TYPE,
    _bytes,
    _ContextStringIO,
    _create_index_array,
    _init_pool,
    _is_builtin,
    _schema_to_str,
    _str_to_proto,
    transform,
    validate_message,
)
from confluent_kafka.schema_registry.common.schema_registry_client import RulePhase
from confluent_kafka.schema_registry.rule_registry import RuleRegistry
from confluent_kafka.schema_registry.schema_registry_client import AsyncSchemaRegistryClient
from confluent_kafka.schema_registry.serde import (
    AsyncBaseDeserializer,
    AsyncBaseSerializer,
    ParsedSchemaCache,
    SchemaId,
    ValidationRulesExecution,
    async_build_serde,
    clear_original_key,
    set_original_key,
)
from confluent_kafka.serialization import (
    DeserializerBuilder,
    MessageField,
    SerializationContext,
    SerializationError,
    SerializerBuilder,
)

__all__ = [
    '_resolve_named_schema',
    'AsyncProtobufSerializer',
    'AsyncProtobufSerializerBuilder',
    'AsyncProtobufDeserializer',
    'AsyncProtobufDeserializerBuilder',
]


async def _resolve_named_schema(
    schema: Schema,
    schema_registry_client: AsyncSchemaRegistryClient,
    pool: DescriptorPool,
    visited: Optional[Set[str]] = None,
):
    """
    Resolves named schemas referenced by the provided schema recursively.

    :param schema: Schema to resolve named schemas for.
    :param schema_registry_client: AsyncSchemaRegistryClient to use for retrieval.
    :param pool: DescriptorPool to add resolved schemas to.
    :return: DescriptorPool
    """
    if visited is None:
        visited = set()
    if schema.references is not None:
        for ref in schema.references:
            if ref.name is None:
                raise ValueError("Name cannot be None")

            if _is_builtin(ref.name) or ref.name in visited:
                continue
            visited.add(ref.name)

            if ref.subject is None or ref.version is None:
                raise ValueError("Subject or version cannot be None")
            referenced_schema = await schema_registry_client.get_version(ref.subject, ref.version, True, 'serialized')
            if referenced_schema.schema.schema_str is None:
                raise ValueError("Schema string cannot be None")
            await _resolve_named_schema(referenced_schema.schema, schema_registry_client, pool, visited)
            file_descriptor_proto = _str_to_proto(ref.name, referenced_schema.schema.schema_str)
            pool.Add(file_descriptor_proto)


@asyncinit
class AsyncProtobufSerializer(AsyncBaseSerializer):
    """
    Serializer for Protobuf Message derived classes. Serialization format is Protobuf,
    with Confluent Schema Registry framing.

    Configuration properties:

    +-------------------------------------+----------+------------------------------------------------------+
    | Property Name                       | Type     | Description                                          |
    +=====================================+==========+======================================================+
    |                                     |          | If True, automatically register the configured       |
    | ``auto.register.schemas``           | bool     | schema with Confluent Schema Registry if it has      |
    |                                     |          | not previously been associated with the relevant     |
    |                                     |          | subject (determined via subject.name.strategy).      |
    |                                     |          |                                                      |
    |                                     |          | Defaults to True.                                    |
    |                                     |          |                                                      |
    |                                     |          | Raises SchemaRegistryError if the schema was not     |
    |                                     |          | registered against the subject, or could not be      |
    |                                     |          | successfully registered.                             |
    +-------------------------------------+----------+------------------------------------------------------+
    |                                     |          | Whether to normalize schemas, which will             |
    | ``normalize.schemas``               | bool     | transform schemas to have a consistent format,       |
    |                                     |          | including ordering properties and references.        |
    +-------------------------------------+----------+------------------------------------------------------+
    |                                     |          | Whether to use the given schema ID for               |
    | ``use.schema.id``                   | int      | serialization.                                       |
    |                                     |          |                                                      |
    +-------------------------------------+----------+------------------------------------------------------+
    |                                     |          | Whether to use the latest subject version for        |
    | ``use.latest.version``              | bool     | serialization.                                       |
    |                                     |          |                                                      |
    |                                     |          | WARNING: There is no check that the latest           |
    |                                     |          | schema is backwards compatible with the object       |
    |                                     |          | being serialized.                                    |
    |                                     |          |                                                      |
    |                                     |          | Defaults to False.                                   |
    +-------------------------------------+----------+------------------------------------------------------+
    |                                     |          | Whether to use the latest subject version with       |
    | ``use.latest.with.metadata``        | dict     | the given metadata.                                  |
    |                                     |          |                                                      |
    |                                     |          | WARNING: There is no check that the latest           |
    |                                     |          | schema is backwards compatible with the object       |
    |                                     |          | being serialized.                                    |
    |                                     |          |                                                      |
    |                                     |          | Defaults to None.                                    |
    +-------------------------------------+----------+------------------------------------------------------+
    |                                     |          | Whether or not to skip known types when resolving    |
    | ``skip.known.types``                | bool     | schema dependencies.                                 |
    |                                     |          |                                                      |
    |                                     |          | Defaults to True.                                    |
    +-------------------------------------+----------+------------------------------------------------------+
    |                                     |          | The type of subject name strategy to use.            |
    | ``subject.name.strategy.type``      | str      | Valid values are: TOPIC, RECORD, TOPIC_RECORD,       |
    |                                     |          | ASSOCIATED.                                          |
    |                                     |          |                                                      |
    |                                     |          | Defaults to ASSOCIATED if neither this nor           |
    |                                     |          | subject.name.strategy is specified.                  |
    +-------------------------------------+----------+------------------------------------------------------+
    |                                     |          | Configuration dictionary passed to strategies        |
    | ``subject.name.strategy.conf``      | dict     | that require additional configuration, such as       |
    |                                     |          | ASSOCIATED.                                          |
    |                                     |          |                                                      |
    |                                     |          | Defaults to None.                                    |
    +-------------------------------------+----------+------------------------------------------------------+
    |                                     |          | Callable(SerializationContext, str) -> str           |
    |                                     |          |                                                      |
    | ``subject.name.strategy``           | callable | Defines how Schema Registry subject names are        |
    |                                     |          | constructed. Standard naming strategies are          |
    |                                     |          | defined in the confluent_kafka.schema_registry       |
    |                                     |          | namespace. Takes precedence over                     |
    |                                     |          | subject.name.strategy.type if both are set.          |
    |                                     |          |                                                      |
    |                                     |          | Defaults to None.                                    |
    +-------------------------------------+----------+------------------------------------------------------+
    |                                     |          | Callable(SerializationContext, str) -> str           |
    |                                     |          |                                                      |
    | ``reference.subject.name.strategy`` | callable | Defines how Schema Registry subject names for schema |
    |                                     |          | references are constructed.                          |
    |                                     |          |                                                      |
    |                                     |          | Defaults to reference_subject_name_strategy          |
    +-------------------------------------+----------+------------------------------------------------------+
    |                                     |          | Callable(bytes, SerializationContext, schema_id)     |
    |                                     |          |   -> bytes                                           |
    |                                     |          |                                                      |
    | ``schema.id.serializer``            | callable | Defines how the schema id/guid is serialized.        |
    |                                     |          | Defaults to prefix_schema_id_serializer.             |
    +-------------------------------------+----------+------------------------------------------------------+

    Schemas are registered against subject names in Confluent Schema Registry that
    define a scope in which the schemas can be evolved. By default, the subject name
    is formed by concatenating the topic name with the message field (key or value)
    separated by a hyphen.

    i.e. {topic name}-{message field}

    Alternative naming strategies may be configured with the property
    ``subject.name.strategy``.

    Supported subject name strategies

    +--------------------------------------+------------------------------+
    | Subject Name Strategy                | Output Format                |
    +======================================+==============================+
    | topic_subject_name_strategy(default) | {topic name}-{message field} |
    +--------------------------------------+------------------------------+
    | topic_record_subject_name_strategy   | {topic name}-{record name}   |
    +--------------------------------------+------------------------------+
    | record_subject_name_strategy         | {record name}                |
    +--------------------------------------+------------------------------+

    See `Subject name strategy <https://docs.confluent.io/current/schema-registry/serializer-formatter.html#subject-name-strategy>`_ for additional details.

    Args:
        msg_type (Message): Protobuf Message type.

        schema_registry_client (SchemaRegistryClient): Schema Registry
            client instance.

        conf (dict): ProtobufSerializer configuration.

    See Also:
        `Protobuf API reference <https://googleapis.dev/python/protobuf/latest/google/protobuf.html>`_
    """  # noqa: E501

    __slots__ = [
        '_skip_known_types',
        '_known_subjects',
        '_known_subjects_lock',
        '_msg_class',
        '_index_array',
        '_schema',
        '_schema_id',
        '_ref_reference_subject_func',
        '_use_deprecated_format',
        '_parsed_schemas',
    ]

    _default_conf = {
        'auto.register.schemas': True,
        'normalize.schemas': False,
        'use.schema.id': None,
        'use.latest.version': False,
        'use.latest.with.metadata': None,
        'skip.known.types': True,
        'subject.name.strategy.type': None,
        'subject.name.strategy.conf': None,
        'subject.name.strategy': None,
        'reference.subject.name.strategy': reference_subject_name_strategy,
        'schema.id.serializer': prefix_schema_id_serializer,
        'use.deprecated.format': False,
        'validation.rules.execution': ValidationRulesExecution.DISABLED,
        'validation.rules.fail.fast': False,
        'validation.rules.executor': None,
    }

    async def __init_impl(
        self,
        msg_type: Message,
        schema_registry_client: AsyncSchemaRegistryClient,
        conf: Optional[dict] = None,
        rule_conf: Optional[dict] = None,
        rule_registry: Optional[RuleRegistry] = None,
    ):
        super().__init__()

        conf_copy = self._default_conf.copy()
        if conf is not None:
            conf_copy.update(conf)

        self._auto_register = cast(bool, conf_copy.pop('auto.register.schemas'))
        if not isinstance(self._auto_register, bool):
            raise ValueError("auto.register.schemas must be a boolean value")

        self._normalize_schemas = cast(bool, conf_copy.pop('normalize.schemas'))
        if not isinstance(self._normalize_schemas, bool):
            raise ValueError("normalize.schemas must be a boolean value")

        self._use_schema_id = cast(Optional[int], conf_copy.pop('use.schema.id'))
        if self._use_schema_id is not None and not isinstance(self._use_schema_id, int):
            raise ValueError("use.schema.id must be an int value")

        self._use_latest_version = cast(bool, conf_copy.pop('use.latest.version'))
        if not isinstance(self._use_latest_version, bool):
            raise ValueError("use.latest.version must be a boolean value")
        if self._use_latest_version and self._auto_register:
            raise ValueError("cannot enable both use.latest.version and auto.register.schemas")

        self._use_latest_with_metadata = cast(Optional[dict], conf_copy.pop('use.latest.with.metadata'))
        if self._use_latest_with_metadata is not None and not isinstance(self._use_latest_with_metadata, dict):
            raise ValueError("use.latest.with.metadata must be a dict value")

        self._skip_known_types = cast(bool, conf_copy.pop('skip.known.types'))
        if not isinstance(self._skip_known_types, bool):
            raise ValueError("skip.known.types must be a boolean value")

        self._use_deprecated_format = cast(bool, conf_copy.pop('use.deprecated.format'))
        if not isinstance(self._use_deprecated_format, bool):
            raise ValueError("use.deprecated.format must be a boolean value")
        if self._use_deprecated_format:
            raise ValueError("use.deprecated.format is no longer supported")

        self.configure_subject_name_strategy(
            subject_name_strategy_type=cast(Any, conf_copy.pop('subject.name.strategy.type')),
            subject_name_strategy_conf=cast(Any, conf_copy.pop('subject.name.strategy.conf')),
            subject_name_strategy=cast(Any, conf_copy.pop('subject.name.strategy')),
        )

        self._ref_reference_subject_func = cast(
            Callable[[Optional[SerializationContext], Any], Optional[str]],
            conf_copy.pop('reference.subject.name.strategy'),
        )
        if not callable(self._ref_reference_subject_func):
            raise ValueError("reference.subject.name.strategy must be callable")

        self._schema_id_serializer = cast(
            Callable[[bytes, Optional[SerializationContext], Any], bytes], conf_copy.pop('schema.id.serializer')
        )
        if not callable(self._schema_id_serializer):
            raise ValueError("schema.id.serializer must be callable")

        self.configure_validation_rules(conf_copy)

        if len(conf_copy) > 0:
            raise ValueError("Unrecognized properties: {}".format(", ".join(conf_copy.keys())))

        self._registry = schema_registry_client
        self._rule_registry = rule_registry if rule_registry else RuleRegistry.get_global_instance()
        self._schema_id: Optional[SchemaId] = None
        self._known_subjects: set[str] = set()
        self._known_subjects_lock = _locks.Lock()
        self._msg_class = msg_type
        self._parsed_schemas = ParsedSchemaCache()

        descriptor = msg_type.DESCRIPTOR
        self._index_array = _create_index_array(descriptor)
        self._schema = Schema(_schema_to_str(descriptor.file), schema_type='PROTOBUF')

        for rule in self._rule_registry.get_executors():
            rule.configure(self._registry.config() if self._registry else {}, rule_conf if rule_conf else {})
        for action in self._rule_registry.get_actions():
            action.configure(self._registry.config() if self._registry else {}, rule_conf if rule_conf else {})

    __init__ = __init_impl

    @staticmethod
    def _write_varint(buf: io.BytesIO, val: int, zigzag: bool = True):
        """
        Writes val to buf, either using zigzag or uvarint encoding.

        Args:
            buf (BytesIO): buffer to write to.
            val (int): integer to be encoded.
            zigzag (bool): whether to encode in zigzag or uvarint encoding
        """

        if zigzag:
            val = (val << 1) ^ (val >> 63)

        while (val & ~0x7F) != 0:
            buf.write(_bytes((val & 0x7F) | 0x80))
            val >>= 7
        buf.write(_bytes(val))

    @staticmethod
    def _encode_varints(buf: io.BytesIO, ints: List[int], zigzag: bool = True):
        """
        Encodes each int as a uvarint onto buf

        Args:
            buf (BytesIO): buffer to write to.
            ints ([int]): ints to be encoded.
            zigzag (bool): whether to encode in zigzag or uvarint encoding
        """

        assert len(ints) > 0
        # The root element at the 0 position does not need a length prefix.
        if ints == [0]:
            buf.write(_bytes(0x00))
            return

        AsyncProtobufSerializer._write_varint(buf, len(ints), zigzag=zigzag)

        for value in ints:
            AsyncProtobufSerializer._write_varint(buf, value, zigzag=zigzag)

    async def _resolve_dependencies(
        self, ctx: SerializationContext, file_desc: FileDescriptor
    ) -> List[SchemaReference]:
        """
        Resolves and optionally registers schema references recursively.

        Args:
            ctx (SerializationContext): Serialization context.

            file_desc (FileDescriptor): file descriptor to traverse.
        """

        schema_refs = []
        for dep in file_desc.dependencies:
            if self._skip_known_types and _is_builtin(dep.name):
                continue
            dep_refs = await self._resolve_dependencies(ctx, dep)
            subject = self._ref_reference_subject_func(ctx, dep)
            schema = Schema(_schema_to_str(dep), references=dep_refs, schema_type='PROTOBUF')
            if self._auto_register:
                await self._registry.register_schema(subject, schema, normalize_schemas=self._normalize_schemas)

            reference = await self._registry.lookup_schema(subject, schema, normalize_schemas=self._normalize_schemas)
            # schema_refs are per file descriptor
            schema_refs.append(SchemaReference(dep.name, subject, reference.version))
        return schema_refs

    def __call__(  # type: ignore[override]
        self, message: Message, ctx: Optional[SerializationContext] = None
    ) -> Coroutine[Any, Any, Optional[bytes]]:
        return self.__serialize(message, ctx)

    async def __serialize(self, message: Message, ctx: Optional[SerializationContext] = None) -> Optional[bytes]:
        try:
            if message is None:
                return None
            return await self.__serialize_impl(message, ctx)
        finally:
            # Track the key for use when serializing the value, such as for a DLQ
            if ctx is not None and ctx.field == MessageField.KEY:
                set_original_key(message)
            else:
                clear_original_key()

    async def __serialize_impl(self, message: Message, ctx: Optional[SerializationContext] = None) -> Optional[bytes]:
        """
        Serializes an instance of a class derived from Protobuf Message, and prepends
        it with Confluent Schema Registry framing.

        Args:
            message (Message): An instance of a class derived from Protobuf Message.

            ctx (SerializationContext): Metadata relevant to the serialization.
                operation.

        Raises:
            SerializerError if any error occurs during serialization.

        Returns:
            None if messages is None, else a byte array containing the Protobuf
            serialized message with Confluent Schema Registry framing.
        """

        if message is None:
            return None

        if not isinstance(message, self._msg_class):
            raise ValueError("message must be of type {} not {}".format(self._msg_class, type(message)))

        subject = (
            (
                await self._subject_name_func(
                    ctx, message.DESCRIPTOR.full_name, self._registry, self._subject_name_conf
                )
                if self._strategy_accepts_client
                else self._subject_name_func(ctx, message.DESCRIPTOR.full_name)
            )
            if ctx
            else None
        )
        latest_schema = None
        if subject is not None:
            latest_schema = await self._get_reader_schema(subject, fmt='serialized')

        # schema_id is kept as a local variable (rather than read back from self._schema_id)
        # so that concurrent __serialize calls on a shared serializer instance can't clobber
        # each other's result between this point and where it's used below.
        schema_id = self._schema_id
        if latest_schema is not None:
            schema_id = SchemaId(PROTOBUF_TYPE, latest_schema.schema_id, latest_schema.guid, self._index_array)
            self._schema_id = schema_id

        elif subject is not None and subject not in self._known_subjects and ctx is not None:
            async with self._known_subjects_lock:
                if subject not in self._known_subjects:
                    references = await self._resolve_dependencies(ctx, message.DESCRIPTOR.file)
                    schema = Schema(self._schema.schema_str, self._schema.schema_type, references)

                    if self._auto_register:
                        registered_schema = await self._registry.register_schema_full_response(
                            subject, schema, normalize_schemas=self._normalize_schemas
                        )
                        schema_id = SchemaId(
                            PROTOBUF_TYPE, registered_schema.schema_id, registered_schema.guid, self._index_array
                        )
                    else:
                        registered_schema = await self._registry.lookup_schema(
                            subject, schema, normalize_schemas=self._normalize_schemas
                        )
                        schema_id = SchemaId(
                            PROTOBUF_TYPE, registered_schema.schema_id, registered_schema.guid, self._index_array
                        )

                    self._schema = schema
                    self._known_subjects.add(subject)
                    self._schema_id = schema_id
                else:
                    schema_id = self._schema_id

        if latest_schema is not None:
            fd_proto, pool = await self._get_parsed_schema(latest_schema.schema)
            fd = pool.FindFileByName(fd_proto.name)
            desc = fd.message_types_by_name[message.DESCRIPTOR.name]

            def field_transformer(rule_ctx, field_transform, msg):
                return transform(rule_ctx, desc, msg, field_transform)  # noqa: E731

            if self._validation_enabled(ValidationRulesExecution.BEFORE_DOMAIN_RULES):
                self._validate_inline_rules(desc, message)

            if ctx is not None and subject is not None:
                message = self._execute_rules(
                    ctx, subject, RuleMode.WRITE, None, latest_schema.schema, message, None, field_transformer
                )

            if self._validation_enabled(ValidationRulesExecution.AFTER_DOMAIN_RULES):
                self._validate_inline_rules(desc, message)
        elif self._validation_enabled():
            # No domain rules run on this path, so before/after collapse to one point.
            self._validate_inline_rules(message.DESCRIPTOR, message)

        with _ContextStringIO() as fo:
            fo.write(message.SerializeToString())
            if schema_id is not None:
                schema_id.message_indexes = self._index_array
            buffer = fo.getvalue()

            if latest_schema is not None and ctx is not None and subject is not None:
                buffer = self._execute_rules_with_phase(
                    ctx, subject, RulePhase.ENCODING, RuleMode.WRITE, None, latest_schema.schema, buffer, None, None
                )

            return self._schema_id_serializer(buffer, ctx, schema_id)

    def _validate_inline_rules(self, desc: Descriptor, message: Message) -> None:
        """
        Evaluate the descriptor's inline validation rules against ``message``, raising
        a single SerializationError listing every violation found.
        """
        self._raise_validation_violations(
            validate_message(self._validation_rule_executor, desc, message, self._validation_rules_fail_fast)
        )

    async def _get_parsed_schema(self, schema: Schema) -> Tuple[descriptor_pb2.FileDescriptorProto, DescriptorPool]:
        result = self._parsed_schemas.get_parsed_schema(schema)
        if result is not None:
            return result

        pool = DescriptorPool()
        _init_pool(pool)
        await _resolve_named_schema(schema, self._registry, pool)
        if schema.schema_str is None:
            raise ValueError("Schema string cannot be None")
        fd_proto = _str_to_proto("default", schema.schema_str)
        pool.Add(fd_proto)
        self._parsed_schemas.set(schema, (fd_proto, pool))
        return fd_proto, pool


class AsyncProtobufSerializerBuilder(SerializerBuilder):
    """
    Builds an :py:class:`AsyncProtobufSerializer` for a serializing producer.

    *This class is experimental and subject to incompatible API changes in future versions of the library.*

    Pass one to a producer through the ``key.serializer.builder`` or
    ``value.serializer.builder`` configuration property and it constructs the
    Schema Registry client and the serializer for you, and lets the producer
    supply the Kafka cluster id to the serializer::

        producer = await AsyncSerializingProducer({
            'bootstrap.servers': brokers,
            'value.serializer.builder': AsyncProtobufSerializerBuilder(
                schema_registry_config={'url': schema_registry_url},
                message_type=User,
            ),
        })

    Every value also has a setter, each returning the builder so they chain::

        AsyncProtobufSerializerBuilder().set_schema_registry_config(conf).set_message_type(User)

    The message type is required; the rest are optional.

    See :py:class:`AsyncProtobufSerializer` for what the individual values mean.
    """

    def __init__(
        self,
        schema_registry_config: Optional[dict] = None,
        schema_registry_client: Optional[AsyncSchemaRegistryClient] = None,
        message_type: Optional[Message] = None,
        serializer_config: Optional[dict] = None,
        rule_config: Optional[dict] = None,
        rule_registry: Optional[RuleRegistry] = None,
        serializer_init: Optional[Callable[['AsyncProtobufSerializer'], Awaitable[None]]] = None,
    ) -> None:
        self._schema_registry_conf = schema_registry_config
        self._schema_registry_client = schema_registry_client
        self._msg_type = message_type
        self._serializer_conf = serializer_config
        self._rule_conf = rule_config
        self._rule_registry = rule_registry
        self._serializer_init = serializer_init

    def set_schema_registry_config(self, schema_registry_conf: dict) -> 'AsyncProtobufSerializerBuilder':
        """Configuration for the Schema Registry client to build. Cannot be combined with a client."""
        self._schema_registry_conf = schema_registry_conf
        return self

    def set_schema_registry_client(
        self, schema_registry_client: AsyncSchemaRegistryClient
    ) -> 'AsyncProtobufSerializerBuilder':
        """An existing Schema Registry client to use, instead of building one."""
        self._schema_registry_client = schema_registry_client
        return self

    def set_message_type(self, msg_type: Message) -> 'AsyncProtobufSerializerBuilder':
        """The protobuf message class this serializer accepts. Required."""
        self._msg_type = msg_type
        return self

    def set_serializer_config(self, serializer_conf: dict) -> 'AsyncProtobufSerializerBuilder':
        """Serializer configuration, e.g. ``{'auto.register.schemas': False}``."""
        self._serializer_conf = serializer_conf
        return self

    def set_rule_config(self, rule_conf: dict) -> 'AsyncProtobufSerializerBuilder':
        """Configuration passed to the rule executors and actions."""
        self._rule_conf = rule_conf
        return self

    def set_rule_registry(self, rule_registry: RuleRegistry) -> 'AsyncProtobufSerializerBuilder':
        """Rule registry to use instead of the global one."""
        self._rule_registry = rule_registry
        return self

    def set_serializer_init(
        self, serializer_init: Callable[['AsyncProtobufSerializer'], Awaitable[None]]
    ) -> 'AsyncProtobufSerializerBuilder':
        """
        Coroutine function awaited with the serializer once built, for
        any setup that the other setters do not cover.
        """
        self._serializer_init = serializer_init
        return self

    def build(  # type: ignore[override]
        self, conf: Dict[str, Any], is_key: bool
    ) -> Coroutine[Any, Any, Tuple['AsyncProtobufSerializer', Dict[str, Any]]]:
        """
        Build the serializer. See :py:func:`SerializerBuilder.build`.

        No Schema Registry property is read from the client configuration today,
        so it is handed back unchanged.

        Raises:
            ValueError: If no message type was set.
        """
        return self.__build(conf, is_key)

    async def __build(self, conf: Dict[str, Any], is_key: bool) -> Tuple['AsyncProtobufSerializer', Dict[str, Any]]:
        if self._msg_type is None:
            raise ValueError("Protobuf serializer requires a message type; call set_message_type()")

        serializer = await async_build_serde(
            self._schema_registry_client,
            self._schema_registry_conf,
            lambda client: AsyncProtobufSerializer(
                self._msg_type,
                client,
                self._serializer_conf,
                self._rule_conf,
                self._rule_registry,
            ),
            self._serializer_init,
        )

        return serializer, dict(conf)


@asyncinit
class AsyncProtobufDeserializer(AsyncBaseDeserializer):
    """
    Deserializer for Protobuf serialized data with Confluent Schema Registry framing.

    Args:
        message_type (Message derived type): Protobuf Message type.
        conf (dict): Configuration dictionary.

    ProtobufDeserializer configuration properties:

    +-------------------------------------+----------+------------------------------------------------------+
    | Property Name                       | Type     | Description                                          |
    +-------------------------------------+----------+------------------------------------------------------+
    |                                     |          | Whether to use the latest subject version for        |
    | ``use.latest.version``              | bool     | deserialization.                                     |
    |                                     |          |                                                      |
    |                                     |          | Defaults to False.                                   |
    +-------------------------------------+----------+------------------------------------------------------+
    |                                     |          | Whether to use the latest subject version with       |
    | ``use.latest.with.metadata``        | dict     | the given metadata.                                  |
    |                                     |          |                                                      |
    |                                     |          | Defaults to None.                                    |
    +-------------------------------------+----------+------------------------------------------------------+
    |                                     |          | The type of subject name strategy to use.            |
    | ``subject.name.strategy.type``      | str      | Valid values are: TOPIC, RECORD, TOPIC_RECORD,       |
    |                                     |          | ASSOCIATED.                                          |
    |                                     |          |                                                      |
    |                                     |          | Defaults to ASSOCIATED if neither this nor           |
    |                                     |          | subject.name.strategy is specified.                  |
    +-------------------------------------+----------+------------------------------------------------------+
    |                                     |          | Configuration dictionary passed to strategies        |
    | ``subject.name.strategy.conf``      | dict     | that require additional configuration, such as       |
    |                                     |          | ASSOCIATED.                                          |
    |                                     |          |                                                      |
    |                                     |          | Defaults to None.                                    |
    +-------------------------------------+----------+------------------------------------------------------+
    |                                     |          | Callable(SerializationContext, str) -> str           |
    |                                     |          |                                                      |
    | ``subject.name.strategy``           | callable | Defines how Schema Registry subject names are        |
    |                                     |          | constructed. Standard naming strategies are          |
    |                                     |          | defined in the confluent_kafka.schema_registry       |
    |                                     |          | namespace. Takes precedence over                     |
    |                                     |          | subject.name.strategy.type if both are set.          |
    |                                     |          |                                                      |
    |                                     |          | Defaults to None.                                    |
    +-------------------------------------+----------+------------------------------------------------------+
    |                                     |          | Callable(bytes, SerializationContext, schema_id)     |
    |                                     |          |   -> io.BytesIO                                      |
    |                                     |          |                                                      |
    | ``schema.id.deserializer``          | callable | Defines how the schema id/guid is deserialized.      |
    |                                     |          | Defaults to dual_schema_id_deserializer.             |
    +-------------------------------------+----------+------------------------------------------------------+


    See Also:
    `Protobuf API reference <https://googleapis.dev/python/protobuf/latest/google/protobuf.html>`_
    """

    __slots__ = ['_msg_class', '_use_deprecated_format', '_parsed_schemas']

    _default_conf = {
        'use.latest.version': False,
        'use.latest.with.metadata': None,
        'subject.name.strategy.type': None,
        'subject.name.strategy.conf': None,
        'subject.name.strategy': None,
        'schema.id.deserializer': dual_schema_id_deserializer,
        'use.deprecated.format': False,
    }

    async def __init_impl(
        self,
        message_type: Message,
        conf: Optional[dict] = None,
        schema_registry_client: Optional[AsyncSchemaRegistryClient] = None,
        rule_conf: Optional[dict] = None,
        rule_registry: Optional[RuleRegistry] = None,
    ):
        super().__init__()

        self._registry = schema_registry_client
        self._rule_registry = rule_registry if rule_registry else RuleRegistry.get_global_instance()
        self._parsed_schemas = ParsedSchemaCache()
        self._use_schema_id = None

        conf_copy = self._default_conf.copy()
        if conf is not None:
            conf_copy.update(conf)

        self._use_latest_version = cast(bool, conf_copy.pop('use.latest.version'))
        if not isinstance(self._use_latest_version, bool):
            raise ValueError("use.latest.version must be a boolean value")

        self._use_latest_with_metadata = cast(Optional[dict], conf_copy.pop('use.latest.with.metadata'))
        if self._use_latest_with_metadata is not None and not isinstance(self._use_latest_with_metadata, dict):
            raise ValueError("use.latest.with.metadata must be a dict value")

        self.configure_subject_name_strategy(
            subject_name_strategy_type=cast(Any, conf_copy.pop('subject.name.strategy.type')),
            subject_name_strategy_conf=cast(Any, conf_copy.pop('subject.name.strategy.conf')),
            subject_name_strategy=cast(Any, conf_copy.pop('subject.name.strategy')),
        )

        self._schema_id_deserializer = cast(
            Callable[[bytes, Optional[SerializationContext], Any], io.BytesIO], conf_copy.pop('schema.id.deserializer')
        )
        if not callable(self._schema_id_deserializer):
            raise ValueError("schema.id.deserializer must be callable")

        self._use_deprecated_format = cast(bool, conf_copy.pop('use.deprecated.format'))
        if not isinstance(self._use_deprecated_format, bool):
            raise ValueError("use.deprecated.format must be a boolean value")
        if self._use_deprecated_format:
            raise ValueError("use.deprecated.format is no longer supported")

        descriptor = message_type.DESCRIPTOR
        self._msg_class = GetMessageClass(descriptor)

        for rule in self._rule_registry.get_executors():
            rule.configure(self._registry.config() if self._registry else {}, rule_conf if rule_conf else {})
        for action in self._rule_registry.get_actions():
            action.configure(self._registry.config() if self._registry else {}, rule_conf if rule_conf else {})

    __init__ = __init_impl

    def __call__(
        self, data: Optional[bytes], ctx: Optional[SerializationContext] = None
    ) -> Coroutine[Any, Any, Optional[bytes]]:
        return self.__deserialize(data, ctx)

    async def __deserialize(self, data: Optional[bytes], ctx: Optional[SerializationContext] = None) -> Optional[bytes]:
        try:
            if data is None:
                return None
            return await self.__deserialize_impl(data, ctx)
        finally:
            # Track the key for use when deserializing the value, such as for a DLQ
            if ctx is not None and ctx.field == MessageField.KEY:
                set_original_key(data)
            else:
                clear_original_key()

    async def __deserialize_impl(
        self, data: Optional[bytes], ctx: Optional[SerializationContext] = None
    ) -> Optional[bytes]:
        """
        Deserialize a serialized protobuf message with Confluent Schema Registry
        framing.

        Args:
            data (bytes): Serialized protobuf message with Confluent Schema
                           Registry framing.

            ctx (SerializationContext): Metadata relevant to the serialization
                operation.

        Returns:
            Message: Protobuf Message instance.

        Raises:
            SerializerError: If there was an error reading the Confluent framing
                data, or parsing the protobuf serialized message.
        """

        if data is None:
            return None

        subject = (
            (
                await self._subject_name_func(ctx, None, self._registry, self._subject_name_conf)
                if self._strategy_accepts_client
                else self._subject_name_func(ctx, None)
            )
            if ctx
            else None
        )
        latest_schema = None
        if subject is not None and self._registry is not None:
            latest_schema = await self._get_reader_schema(subject, fmt='serialized')

        schema_id = SchemaId(PROTOBUF_TYPE)
        payload = self._schema_id_deserializer(data, ctx, schema_id)
        msg_index = schema_id.message_indexes

        if self._registry is not None:
            writer_schema_raw = await self._get_writer_schema(schema_id, subject, fmt='serialized')
            fd_proto, pool = await self._get_parsed_schema(writer_schema_raw)
            writer_schema = pool.FindFileByName(fd_proto.name)
            writer_desc = self._get_message_desc(pool, writer_schema, msg_index if msg_index is not None else [])
            if subject is None:
                subject = (
                    (
                        await self._subject_name_func(
                            ctx, writer_desc.full_name, self._registry, self._subject_name_conf
                        )
                        if self._strategy_accepts_client
                        else self._subject_name_func(ctx, writer_desc.full_name)
                    )
                    if ctx
                    else None
                )
                if subject is not None:
                    latest_schema = await self._get_reader_schema(subject, fmt='serialized')
        else:
            writer_schema_raw = None
            writer_schema = None

        if ctx is not None and subject is not None:
            payload = self._execute_rules_with_phase(
                ctx, subject, RulePhase.ENCODING, RuleMode.READ, None, writer_schema_raw, payload, None, None, data
            )
        if isinstance(payload, bytes):
            payload = io.BytesIO(payload)

        reader_schema_raw: Optional[Schema] = None
        if latest_schema is not None and subject is not None and writer_schema_raw is not None:
            migrations = await self._get_migrations(subject, writer_schema_raw, latest_schema, None)
            reader_schema_raw = latest_schema.schema
            fd_proto, pool = await self._get_parsed_schema(latest_schema.schema)
            reader_schema = pool.FindFileByName(fd_proto.name)
        else:
            migrations = None
            reader_schema_raw = writer_schema_raw
            reader_schema = writer_schema

        if reader_schema is not None:
            # Initialize reader desc to first message in file
            reader_desc = self._get_message_desc(pool, reader_schema, [0])
            # Attempt to find a reader desc with the same name as the writer
            reader_desc = reader_schema.message_types_by_name.get(writer_desc.name, reader_desc)

        if migrations and ctx is not None and subject is not None:
            msg = GetMessageClass(writer_desc)()
            try:
                msg.ParseFromString(payload.read())
            except DecodeError as e:
                raise SerializationError(str(e))

            obj_dict = json_format.MessageToDict(msg, True)
            obj_dict = self._execute_migrations(ctx, subject, migrations, obj_dict)
            msg = GetMessageClass(reader_desc)()
            msg = json_format.ParseDict(obj_dict, msg)
        else:
            # Protobuf Messages are self-describing; no need to query schema
            msg = self._msg_class()
            try:
                msg.ParseFromString(payload.read())
            except DecodeError as e:
                raise SerializationError(str(e))

        def field_transformer(rule_ctx, field_transform, message):
            return transform(rule_ctx, reader_desc, message, field_transform)  # noqa: E731

        if ctx is not None and subject is not None:
            msg = self._execute_rules(
                ctx, subject, RuleMode.READ, None, reader_schema_raw, msg, None, field_transformer, data
            )
        return msg

    async def _get_parsed_schema(self, schema: Schema) -> Tuple[descriptor_pb2.FileDescriptorProto, DescriptorPool]:
        result = self._parsed_schemas.get_parsed_schema(schema)
        if result is not None:
            return result

        pool = DescriptorPool()
        _init_pool(pool)
        await _resolve_named_schema(schema, self._registry, pool)
        if schema.schema_str is None:
            raise ValueError("Schema string cannot be None")
        fd_proto = _str_to_proto("default", schema.schema_str)
        pool.Add(fd_proto)
        self._parsed_schemas.set(schema, (fd_proto, pool))
        return fd_proto, pool

    def _get_message_desc(self, pool: DescriptorPool, fd: FileDescriptor, msg_index: List[int]) -> Descriptor:
        file_desc_proto = descriptor_pb2.FileDescriptorProto()
        fd.CopyToProto(file_desc_proto)
        full_name, desc_proto = self._get_message_desc_proto("", file_desc_proto, msg_index)
        package = file_desc_proto.package
        qualified_name = package + "." + full_name if package else full_name
        return pool.FindMessageTypeByName(qualified_name)

    def _get_message_desc_proto(
        self,
        path: str,
        desc: Union[descriptor_pb2.FileDescriptorProto, descriptor_pb2.DescriptorProto],
        msg_index: List[int],
    ) -> Tuple[str, descriptor_pb2.DescriptorProto]:
        index = msg_index[0]
        if isinstance(desc, descriptor_pb2.FileDescriptorProto):
            messages = desc.message_type
            if index < 0 or index >= len(messages):
                raise SerializationError(
                    "message index {} out of range, schema has {} top-level message(s)".format(index, len(messages))
                )
            msg = messages[index]
            path = path + "." + msg.name if path else msg.name
            if len(msg_index) == 1:
                return path, msg
            return self._get_message_desc_proto(path, msg, msg_index[1:])
        else:
            messages = desc.nested_type
            if index < 0 or index >= len(messages):
                raise SerializationError(
                    "message index {} out of range, message has {} nested message(s)".format(index, len(messages))
                )
            msg = messages[index]
            path = path + "." + msg.name if path else msg.name
            if len(msg_index) == 1:
                return path, msg
            return self._get_message_desc_proto(path, msg, msg_index[1:])


class AsyncProtobufDeserializerBuilder(DeserializerBuilder):
    """
    Builds an :py:class:`AsyncProtobufDeserializer` for a deserializing consumer.

    *This class is experimental and subject to incompatible API changes in future versions of the library.*

    The deserializing counterpart of :py:class:`AsyncProtobufSerializerBuilder`.
    Pass one to a consumer through the ``key.deserializer.builder`` or
    ``value.deserializer.builder`` configuration property::

        consumer = await AsyncDeserializingConsumer[None, User]({
            'bootstrap.servers': brokers,
            'group.id': group,
            'value.deserializer.builder': AsyncProtobufDeserializerBuilder(
                schema_registry_config={'url': schema_registry_url},
                message_type=User,
            ),
        })

    Every value also has a setter, each returning the builder so they chain::

        AsyncProtobufDeserializerBuilder().set_schema_registry_config(conf).set_message_type(User)

    The message type is required; the rest are optional.

    See :py:class:`AsyncProtobufDeserializer` for what the individual values mean.
    """

    def __init__(
        self,
        schema_registry_config: Optional[dict] = None,
        schema_registry_client: Optional[AsyncSchemaRegistryClient] = None,
        message_type: Optional[Message] = None,
        deserializer_config: Optional[dict] = None,
        rule_config: Optional[dict] = None,
        rule_registry: Optional[RuleRegistry] = None,
        deserializer_init: Optional[Callable[['AsyncProtobufDeserializer'], Awaitable[None]]] = None,
    ) -> None:
        self._schema_registry_conf = schema_registry_config
        self._schema_registry_client = schema_registry_client
        self._msg_type = message_type
        self._deserializer_conf = deserializer_config
        self._rule_conf = rule_config
        self._rule_registry = rule_registry
        self._deserializer_init = deserializer_init

    def set_schema_registry_config(self, schema_registry_conf: dict) -> 'AsyncProtobufDeserializerBuilder':
        """Configuration for the Schema Registry client to build. Cannot be combined with a client."""
        self._schema_registry_conf = schema_registry_conf
        return self

    def set_schema_registry_client(
        self, schema_registry_client: AsyncSchemaRegistryClient
    ) -> 'AsyncProtobufDeserializerBuilder':
        """An existing Schema Registry client to use, instead of building one."""
        self._schema_registry_client = schema_registry_client
        return self

    def set_message_type(self, msg_type: Message) -> 'AsyncProtobufDeserializerBuilder':
        """The protobuf message class this deserializer returns. Required."""
        self._msg_type = msg_type
        return self

    def set_deserializer_config(self, deserializer_conf: dict) -> 'AsyncProtobufDeserializerBuilder':
        """Deserializer configuration, e.g. ``{'use.deprecated.format': False}``."""
        self._deserializer_conf = deserializer_conf
        return self

    def set_rule_config(self, rule_conf: dict) -> 'AsyncProtobufDeserializerBuilder':
        """Configuration passed to the rule executors and actions."""
        self._rule_conf = rule_conf
        return self

    def set_rule_registry(self, rule_registry: RuleRegistry) -> 'AsyncProtobufDeserializerBuilder':
        """Rule registry to use instead of the global one."""
        self._rule_registry = rule_registry
        return self

    def set_deserializer_init(
        self, deserializer_init: Callable[['AsyncProtobufDeserializer'], Awaitable[None]]
    ) -> 'AsyncProtobufDeserializerBuilder':
        """
        Coroutine function awaited with the deserializer once built, for
        any setup that the other setters do not cover.
        """
        self._deserializer_init = deserializer_init
        return self

    def build(  # type: ignore[override]
        self, conf: Dict[str, Any], is_key: bool
    ) -> Coroutine[Any, Any, Tuple['AsyncProtobufDeserializer', Dict[str, Any]]]:
        """
        Build the deserializer. See :py:func:`DeserializerBuilder.build`.

        No Schema Registry property is read from the client configuration today,
        so it is handed back unchanged.

        Raises:
            ValueError: If no message type was set.
        """
        return self.__build(conf, is_key)

    async def __build(self, conf: Dict[str, Any], is_key: bool) -> Tuple['AsyncProtobufDeserializer', Dict[str, Any]]:
        if self._msg_type is None:
            raise ValueError("Protobuf deserializer requires a message type; call set_message_type()")

        deserializer = await async_build_serde(
            self._schema_registry_client,
            self._schema_registry_conf,
            lambda client: AsyncProtobufDeserializer(
                self._msg_type,
                self._deserializer_conf,
                client,
                self._rule_conf,
                self._rule_registry,
            ),
            self._deserializer_init,
        )

        return deserializer, dict(conf)
