import decimal
import ipaddress
import logging
import socket
from io import BytesIO
from typing import Any, List, Optional, Set, Union
from urllib.parse import urlsplit

import referencing
from jsonschema import ValidationError, validate
from referencing import Registry, Resource
from referencing._core import Resolver
from referencing.exceptions import Unresolvable

from confluent_kafka.schema_registry import RuleKind
from confluent_kafka.schema_registry.common._httpx_compat import httpx
from confluent_kafka.schema_registry.serde import (
    VALIDATION_RULES_PROP,
    FieldTransform,
    FieldType,
    RuleConditionError,
    RuleContext,
    ValidationRule,
    ValidationRuleError,
    ValidationRuleExecutor,
    evaluate_validation_rule,
    parse_validation_rules,
)

__all__ = [
    'JsonMessage',
    'JsonSchema',
    'DEFAULT_SPEC',
    '_retrieve_via_httpx',
    'transform',
    '_transform_field',
    'validate_message',
    '_validate_subschemas',
    'get_type',
    '_disjoint',
    'get_inline_tags',
    '_json_loads',
    '_json_dumps',
    '_HAS_ORJSON',
]

# JSON codec: prefer orjson for speed, but fall back to the stdlib json module
# when orjson is unavailable (e.g. on free-threaded CPython builds that do not
# yet have orjson wheels). Both implementations accept str/bytes/bytearray for
# loads and return a str from dumps. The stdlib fallback mirrors orjson's wire
# output (compact separators, non-ASCII preserved) so serialized bytes stay
# consistent.
#
# Catch any exception (not just ImportError): orjson is a compiled extension and
# may be present yet fail to import/initialize (ABI mismatch, broken shared lib,
# init error raising OSError/RuntimeError/etc.). In that case we still degrade to
# the stdlib codec rather than letting the failure break this module -- and with
# it all JSON (de)serialization. Note `except Exception` deliberately does not
# catch KeyboardInterrupt/SystemExit (those are BaseException).
try:
    import orjson

    _HAS_ORJSON = True

    def _json_loads(data: Union[str, bytes, bytearray]) -> Any:
        return orjson.loads(data)

    def _json_dumps(obj: Any) -> str:
        return orjson.dumps(obj).decode("utf-8")

except Exception as _orjson_exc:
    if not isinstance(_orjson_exc, ImportError):
        # Absence (ImportError) is the normal optional-dependency case and is
        # silent; a present-but-broken orjson is unexpected, so surface it.
        logging.getLogger(__name__).warning(
            "orjson is installed but failed to import; falling back to the " "stdlib json module",
            exc_info=True,
        )

    import json as _stdlib_json

    _HAS_ORJSON = False

    def _json_loads(data: Union[str, bytes, bytearray]) -> Any:
        # json.loads accepts bytes/bytearray (auto-detecting the encoding)
        # since Python 3.6, matching orjson.loads.
        return _stdlib_json.loads(data)

    def _json_dumps(obj: Any) -> str:
        return _stdlib_json.dumps(obj, separators=(",", ":"), ensure_ascii=False)


JSON_TYPE = "JSON"

JsonMessage = Union[
    None,  # 'null' Avro type
    str,  # 'string' and 'enum'
    float,  # 'float' and 'double'
    int,  # 'int' and 'long'
    decimal.Decimal,  # 'fixed'
    bool,  # 'boolean'
    list,  # 'array'
    dict,  # 'map' and 'record'
]

JsonSchema = Union[bool, dict]

DEFAULT_SPEC = referencing.jsonschema.DRAFT7  # type: ignore[attr-defined]

log = logging.getLogger(__name__)


class _ContextStringIO(BytesIO):
    """
    Wrapper to allow use of StringIO via 'with' constructs.
    """

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
        return False


def _is_blocked_ip(ip) -> bool:
    mapped = getattr(ip, 'ipv4_mapped', None)
    if mapped is not None:
        ip = mapped
    return not ip.is_global


def _guard_external_uri(uri: str):
    parts = urlsplit(uri)
    if parts.scheme not in ('http', 'https'):
        raise ValueError("Refusing to retrieve schema from non-HTTP(S) URI: {}".format(uri))
    host = parts.hostname
    if not host:
        raise ValueError("Refusing to retrieve schema from URI without a host: {}".format(uri))
    try:
        infos = socket.getaddrinfo(host, parts.port or (443 if parts.scheme == 'https' else 80))
    except socket.gaierror as ex:
        raise ValueError("Could not resolve schema URI host {}: {}".format(host, ex)) from ex
    for info in infos:
        if _is_blocked_ip(ipaddress.ip_address(info[4][0])):
            raise ValueError("Refusing to retrieve schema from non-public address: {}".format(uri))


def _retrieve_via_httpx(uri: str):
    _guard_external_uri(uri)
    response = httpx.get(uri, follow_redirects=False)
    return Resource.from_contents(response.json(), default_specification=DEFAULT_SPEC)


def transform(
    ctx: RuleContext,
    schema: JsonSchema,
    ref_registry: Registry,
    ref_resolver: Resolver,
    path: str,
    message: JsonMessage,
    field_transform: FieldTransform,
) -> Optional[JsonMessage]:
    # Only proceed to transform the message if schema is of dict type
    if message is None or schema is None or isinstance(schema, bool):
        return message

    field_ctx = ctx.current_field()
    if field_ctx is not None:
        field_ctx.field_type = get_type(schema)
    if isinstance(schema.get("type"), list) and len(schema["type"]) > 0:
        subschema = _validate_subtypes(schema, message, ref_registry, ref_resolver)
        if subschema is not None:
            return transform(ctx, subschema, ref_registry, ref_resolver, path, message, field_transform)
    all_of = schema.get("allOf")
    any_of = schema.get("anyOf")
    one_of = schema.get("oneOf")
    if all_of is not None or any_of is not None or one_of is not None:
        if all_of is not None:
            for subschema in all_of:
                message = transform(ctx, subschema, ref_registry, ref_resolver, path, message, field_transform)
        elif one_of is not None:
            for subschema in one_of:
                resolved = _validate_subschema(subschema, message, ref_registry, ref_resolver)
                if resolved is not None:
                    message = transform(ctx, resolved, ref_registry, ref_resolver, path, message, field_transform)
                    break
        elif any_of is not None:
            for subschema in any_of:
                resolved = _validate_subschema(subschema, message, ref_registry, ref_resolver)
                if resolved is not None:
                    message = transform(ctx, resolved, ref_registry, ref_resolver, path, message, field_transform)
        # Also visit sibling properties/items at this level
        # (siblings to allOf/anyOf/oneOf).
        props = schema.get("properties")
        if props is not None and isinstance(message, dict):
            for prop_name, prop_schema in props.items():
                if isinstance(prop_schema, dict):
                    _transform_field(
                        ctx, path, prop_name, message, prop_schema, ref_registry, ref_resolver, field_transform
                    )
        items = schema.get("items")
        if items is not None and isinstance(message, list):
            message = [
                transform(ctx, items, ref_registry, ref_resolver, path, item, field_transform) for item in message
            ]
        return message
    items = schema.get("items")
    if items is not None:
        if isinstance(message, list):
            return [transform(ctx, items, ref_registry, ref_resolver, path, item, field_transform) for item in message]
    ref = schema.get("$ref")
    if ref is not None:
        ref_schema = ref_resolver.lookup(ref)
        # As above: the resolver from the lookup carries the referenced resource's base URI.
        return transform(ctx, ref_schema.contents, ref_registry, ref_schema.resolver, path, message, field_transform)

    schema_type = get_type(schema)
    if schema_type == FieldType.RECORD:
        props = schema.get("properties")
        if not isinstance(message, dict):
            log.warning("Incompatible message type for record schema")
            return message
        if props is not None:
            for prop_name, prop_schema in props.items():
                if isinstance(prop_schema, dict):
                    _transform_field(
                        ctx, path, prop_name, message, prop_schema, ref_registry, ref_resolver, field_transform
                    )
        return message
    if schema_type in (FieldType.ENUM, FieldType.STRING, FieldType.INT, FieldType.DOUBLE, FieldType.BOOLEAN):
        if field_ctx is not None:
            rule_tags = ctx.rule.tags
            if not rule_tags or not _disjoint(set(rule_tags), field_ctx.tags):
                return field_transform(ctx, field_ctx, message)
    return message


def _transform_field(
    ctx: RuleContext,
    path: str,
    prop_name: str,
    message: dict,
    prop_schema: dict,
    ref_registry: Registry,
    ref_resolver: Resolver,
    field_transform: FieldTransform,
):
    full_name = path + "." + prop_name
    try:
        ctx.enter_field(message, full_name, prop_name, get_type(prop_schema), get_inline_tags(prop_schema))
        value = message.get(prop_name)
        if value is not None:
            new_value = transform(ctx, prop_schema, ref_registry, ref_resolver, full_name, value, field_transform)
            if ctx.rule.kind == RuleKind.CONDITION:
                if new_value is False:
                    raise RuleConditionError(ctx.rule)
            else:
                message[prop_name] = new_value
    finally:
        ctx.exit_field()


def validate_message(
    executor: Optional[ValidationRuleExecutor],
    schema: Optional[JsonSchema],
    ref_registry: Registry,
    ref_resolver: Resolver,
    message: JsonMessage,
    fail_fast: bool = False,
) -> List[ValidationRuleError]:
    """
    Walk ``message`` against ``schema``, evaluating every inline ``confluent:rules``
    CHECK constraint encountered and collecting all failures. Read-only — the message
    is not modified.

    Two kinds of rules are evaluated:

    - Object-level (``confluent:rules`` on an object schema) — ``this`` is the object.
    - Property-level (``confluent:rules`` on a property schema) — ``this`` is the
      property value. Honors the skip-on-null contract: a property that is absent or
      null does not have its rules invoked.

    Failures are appended with their location, rooted at ``$`` to match the JVM client
    (e.g. ``$.addr.zip``, ``$.tags[3]``). The walk continues after each failure unless
    ``fail_fast`` is set.
    """
    violations: List[ValidationRuleError] = []
    if executor is None or schema is None or message is None:
        return violations
    _validate_message(executor, schema, ref_registry, ref_resolver, "$", message, fail_fast, violations)
    return violations


def _validate_message(
    executor: ValidationRuleExecutor,
    schema: JsonSchema,
    ref_registry: Registry,
    ref_resolver: Resolver,
    path: str,
    message: JsonMessage,
    fail_fast: bool,
    out: List[ValidationRuleError],
):
    """
    Mirrors :func:`transform`'s dispatch shape: type arrays, then the combined
    keywords (allOf/anyOf/oneOf) with their sibling properties/items, then items,
    then ``$ref``, then object properties.
    """
    if message is None or schema is None or isinstance(schema, bool):
        return

    if isinstance(schema.get("type"), list) and len(schema["type"]) > 0:
        subschema = _validate_subtypes(schema, message, ref_registry, ref_resolver)
        if subschema is not None:
            _validate_message(executor, subschema, ref_registry, ref_resolver, path, message, fail_fast, out)
        return

    all_of = schema.get("allOf")
    any_of = schema.get("anyOf")
    one_of = schema.get("oneOf")
    if all_of is not None or any_of is not None or one_of is not None:
        if all_of is not None:
            for subschema in all_of:
                _validate_message(executor, subschema, ref_registry, ref_resolver, path, message, fail_fast, out)
                if fail_fast and out:
                    return
        elif one_of is not None:
            for subschema in one_of:
                resolved = _validate_subschema(subschema, message, ref_registry, ref_resolver)
                if resolved is not None:
                    _validate_message(executor, resolved, ref_registry, ref_resolver, path, message, fail_fast, out)
                    break
        elif any_of is not None:
            for subschema in any_of:
                resolved = _validate_subschema(subschema, message, ref_registry, ref_resolver)
                if resolved is not None:
                    _validate_message(executor, resolved, ref_registry, ref_resolver, path, message, fail_fast, out)
                    if fail_fast and out:
                        return
        if fail_fast and out:
            return
        # Also visit sibling properties/items at this level
        # (siblings to allOf/anyOf/oneOf).
        _validate_object(executor, schema, ref_registry, ref_resolver, path, message, fail_fast, out)
        if fail_fast and out:
            return
        items = schema.get("items")
        if items is not None and isinstance(message, list):
            for i, item in enumerate(message):
                _validate_message(executor, items, ref_registry, ref_resolver, f"{path}[{i}]", item, fail_fast, out)
                if fail_fast and out:
                    return
        return

    items = schema.get("items")
    if items is not None and isinstance(message, list):
        for i, item in enumerate(message):
            _validate_message(executor, items, ref_registry, ref_resolver, f"{path}[{i}]", item, fail_fast, out)
            if fail_fast and out:
                return
        return

    ref = schema.get("$ref")
    if ref is not None:
        ref_schema = ref_resolver.lookup(ref)
        # Recurse with the resolver the lookup returned, not the original one: it is scoped
        # to the referenced resource, so a relative $ref inside it resolves against the
        # right base URI.
        _validate_message(
            executor, ref_schema.contents, ref_registry, ref_schema.resolver, path, message, fail_fast, out
        )
        return

    _validate_object(executor, schema, ref_registry, ref_resolver, path, message, fail_fast, out)


def _validate_object(
    executor: ValidationRuleExecutor,
    schema: JsonSchema,
    ref_registry: Registry,
    ref_resolver: Resolver,
    path: str,
    message: JsonMessage,
    fail_fast: bool,
    out: List[ValidationRuleError],
):
    """
    Evaluate object-level rules, then each declared property's rules, then recurse
    into the property values. Undeclared properties (``additionalProperties`` /
    ``patternProperties``) are not walked, matching the JVM client.
    """
    if isinstance(schema, bool) or not isinstance(message, dict):
        return
    # Object-level rules: this = the object value.
    for rule in _read_validation_rules(schema):
        evaluate_validation_rule(executor, rule, schema, message, path, out)
        if fail_fast and out:
            return
    props = schema.get("properties")
    if props is None:
        return
    for prop_name, prop_schema in props.items():
        if not isinstance(prop_schema, dict):
            continue
        full_name = f"{path}.{prop_name}"
        value = message.get(prop_name)
        # Skip-on-null: an absent or null property does not invoke the executor.
        if value is not None:
            for rule in _read_validation_rules(prop_schema):
                evaluate_validation_rule(executor, rule, prop_schema, value, full_name, out)
                if fail_fast and out:
                    return
        _validate_message(executor, prop_schema, ref_registry, ref_resolver, full_name, value, fail_fast, out)
        if fail_fast and out:
            return


def _read_validation_rules(schema: JsonSchema) -> List[ValidationRule]:
    """
    Read the ``confluent:rules`` keyword off a schema. Unknown keywords are preserved
    verbatim in the parsed schema dict, so this is a plain lookup.
    """
    if not isinstance(schema, dict):
        return []
    return parse_validation_rules(schema.get(VALIDATION_RULES_PROP))


def _validate_subtypes(
    schema: dict, message: JsonMessage, registry: Registry, resolver: Optional[Resolver] = None
) -> Optional[JsonSchema]:
    """
    Validate the message against the subtypes.

    Each candidate type is tried on a shallow copy of the schema, so the parsed
    schema - which is cached and shared across concurrent serializations - is never
    mutated, not even temporarily.

    Args:
        schema: The schema to validate the message against.
        message: The message to validate.
        registry: The registry to use for the validation.
        resolver: The resolver anchored to the full document, used so that a $ref inside
            the candidate (e.g. in "items") resolves against the whole schema rather than
            just this fragment.
    Returns:
        A copy of the schema narrowed to the matching type, otherwise None.
    """
    schema_type = schema.get("type")
    if not isinstance(schema_type, list) or len(schema_type) == 0:
        return None
    for typ in schema_type:
        subschema = {**schema, "type": typ}
        try:
            kwargs = {"_resolver": resolver} if resolver is not None else {}
            validate(instance=message, schema=subschema, registry=registry, **kwargs)
            return subschema
        except (ValidationError, Unresolvable):
            pass
    return None


def _validate_subschemas(
    subschemas: List[JsonSchema],
    message: JsonMessage,
    registry: Registry,
    resolver: Resolver,
) -> Optional[JsonSchema]:
    """
    Validate the message against the subschemas.
    Args:
        subschemas: The list of subschemas to validate the message against.
        message: The message to validate.
        registry: The registry to use for the validation.
        resolver: The resolver to use for the validation.
    Returns:
        The validated schema if the message is valid against the subschemas, otherwise None.
    """
    for subschema in subschemas:
        resolved = _validate_subschema(subschema, message, registry, resolver)
        if resolved is not None:
            return resolved
    return None


def _validate_subschema(
    subschema: JsonSchema,
    message: JsonMessage,
    registry: Registry,
    resolver: Resolver,
) -> Optional[JsonSchema]:
    """
    Validate the message against a single subschema.
    Returns the resolved subschema (with $ref followed) if valid, otherwise None.
    """
    if not isinstance(subschema, dict):
        return None
    try:
        ref = subschema.get("$ref")
        if ref is not None:
            resolved = resolver.lookup(ref)
            subschema = resolved.contents
            # Pass _resolver (not resolver) to use the new referencing library's
            # Resolver with correct context for nested $ref resolution
            validate(instance=message, schema=subschema, registry=registry, _resolver=resolved.resolver)
        else:
            validate(instance=message, schema=subschema, registry=registry)
        return subschema
    except ValidationError:
        return None


def get_type(schema: JsonSchema) -> FieldType:
    if isinstance(schema, bool):
        return FieldType.COMBINED

    schema_type = schema.get("type")
    if schema.get("const") is not None or schema.get("enum") is not None:
        return FieldType.ENUM
    if schema_type == "object":
        props = schema.get("properties")
        if not props:
            return FieldType.MAP
        return FieldType.RECORD
    if schema_type == "array":
        return FieldType.ARRAY
    if schema_type == "string":
        return FieldType.STRING
    if schema_type == "integer":
        return FieldType.INT
    if schema_type == "number":
        return FieldType.DOUBLE
    if schema_type == "boolean":
        return FieldType.BOOLEAN
    if schema_type == "null":
        return FieldType.NULL

    props = schema.get("properties")
    if props is not None:
        return FieldType.RECORD

    return FieldType.NULL


def _disjoint(tags1: Set[str], tags2: Set[str]) -> bool:
    for tag in tags1:
        if tag in tags2:
            return False
    return True


def get_inline_tags(schema: dict) -> Set[str]:
    tags = schema.get("confluent:tags")
    if tags is None:
        return set()
    else:
        return set(tags)
