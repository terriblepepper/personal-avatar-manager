# Copyright 2026 Confluent Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""CEL bindings for the ``variant(...)`` constructor and the ``variants.*`` accessor
functions - the Python counterpart of Java's ``rules/cel/builtin`` variant glue.

celpy has no overload-set concept (one callable per name, internal arity/type dispatch) and
no opaque type, so a :class:`Variant` flows through CEL as a plain Python object, exactly as
``decimal.Decimal`` does for the decimal functions.

Null model (matching the Java reference / Spark Variant semantics):

* CEL null (Python ``None``) = *absent*: a missing field, an out-of-bounds index, a
  type-mismatched receiver, or a non-Variant input.
* a Variant whose top type is ``NULL`` = *present, but the value is variant-null*.

``variants.field``/``path``/``index`` return CEL null on a miss; ``variants.isNull`` is true
only for a real Variant with top type NULL. Distinguish the two with
``result == null`` (absent) vs ``variants.isNull(result)`` (variant-null).
"""

import typing
from datetime import datetime, timedelta, timezone

import celpy
from celpy import celtypes

from confluent_kafka.schema_registry.confluent.type import variant_utils as vu
from confluent_kafka.schema_registry.confluent.type.variant_utils import Variant, VariantType
from confluent_kafka.schema_registry.rules.cel import variant_path

try:
    from confluent_kafka.schema_registry.confluent.type import variant_pb2

    _PROTO_VARIANT_CLS: typing.Any = variant_pb2.Variant
except ImportError:
    _PROTO_VARIANT_CLS = None

_VARIANT_PROTO_NAME = "confluent.type.Variant"
_EPOCH_UTC = datetime(1970, 1, 1, tzinfo=timezone.utc)
_INT32_MAX = 2**31 - 1

# VariantType -> the coarse label variants.type returns, matching Java variantTypeName:
# integer widths collapse to "int", float/double to "double", decimal widths to "decimal",
# and all four timestamp variants to "timestamp".
_TYPE_LABELS = {
    VariantType.OBJECT: "object",
    VariantType.ARRAY: "array",
    VariantType.NULL: "null",
    VariantType.BOOLEAN: "boolean",
    VariantType.BYTE: "int",
    VariantType.SHORT: "int",
    VariantType.INT: "int",
    VariantType.LONG: "int",
    VariantType.FLOAT: "double",
    VariantType.DOUBLE: "double",
    VariantType.DECIMAL4: "decimal",
    VariantType.DECIMAL8: "decimal",
    VariantType.DECIMAL16: "decimal",
    VariantType.DATE: "date",
    VariantType.TIME: "time",
    VariantType.TIMESTAMP_TZ: "timestamp",
    VariantType.TIMESTAMP_NTZ: "timestamp",
    VariantType.TIMESTAMP_NANOS_TZ: "timestamp",
    VariantType.TIMESTAMP_NANOS_NTZ: "timestamp",
    VariantType.STRING: "string",
    VariantType.BINARY: "bytes",
    VariantType.UUID: "uuid",
}

_INT_TYPES = (VariantType.BYTE, VariantType.SHORT, VariantType.INT, VariantType.LONG)
_DECIMAL_TYPES = (VariantType.DECIMAL4, VariantType.DECIMAL8, VariantType.DECIMAL16)
_TIMESTAMP_TYPES = (
    VariantType.TIMESTAMP_TZ,
    VariantType.TIMESTAMP_NTZ,
    VariantType.TIMESTAMP_NANOS_TZ,
    VariantType.TIMESTAMP_NANOS_NTZ,
)
_MICROS_TIMESTAMP_TYPES = (VariantType.TIMESTAMP_TZ, VariantType.TIMESTAMP_NTZ)


def _coerce_bytes(v: typing.Any) -> bytes:
    if isinstance(v, (bytes, bytearray)):
        return bytes(v)
    if isinstance(v, memoryview):
        return v.tobytes()
    if isinstance(v, celtypes.BytesType):
        return bytes(v)
    raise celpy.CELEvalError(f"variant: expected bytes, got {type(v).__name__}")


def _variant_or_absent(value: bytes, metadata: bytes) -> typing.Optional[Variant]:
    """Build a Variant, or ``None`` when there is no metadata at all -- a protobuf field left
    unset, or an Avro variant record whose byte fields are empty. The Variant constructor reads
    the metadata version byte, so an empty buffer has to be caught before construction; callers
    report the ``None`` as CEL null, which every ``variants.*`` accessor already propagates."""
    if not metadata:
        return None
    return Variant(value, metadata)


def _to_variant(v: typing.Any) -> typing.Optional[Variant]:
    """Runtime dispatch backing ``variant(dyn)``: accept the shapes proto/Avro decoders
    produce. Rejects strings (use ``variants.parseJson``). CEL null passes through as CEL
    null (matching the Java reference: ``variant(null) -> CEL null``)."""
    if v is None:
        return None
    if isinstance(v, Variant):
        return v
    # A confluent.type.Variant proto message: the generated class, or any message whose
    # descriptor full name matches (covers DynamicMessage / alternate bindings).
    if _PROTO_VARIANT_CLS is not None and isinstance(v, _PROTO_VARIANT_CLS):
        return _variant_or_absent(_coerce_bytes(v.value), _coerce_bytes(v.metadata))
    if getattr(getattr(v, "DESCRIPTOR", None), "full_name", "") == _VARIANT_PROTO_NAME:
        return _variant_or_absent(_coerce_bytes(v.value), _coerce_bytes(v.metadata))
    # celpy binds a proto-message field as a wrapper that keeps the message on ``.msg``.
    proto_msg = getattr(v, "msg", None)
    if (
        proto_msg is not None
        and getattr(getattr(proto_msg, "DESCRIPTOR", None), "full_name", "") == _VARIANT_PROTO_NAME
    ):
        return _variant_or_absent(_coerce_bytes(proto_msg.value), _coerce_bytes(proto_msg.metadata))
    # An Avro variant-logical field reaches CEL as a map with {"metadata", "value"} byte
    # entries (celpy MapType is a dict subclass).
    if isinstance(v, dict):
        md = v.get("metadata")
        val = v.get("value")
        if md is not None and val is not None:
            return _variant_or_absent(_coerce_bytes(val), _coerce_bytes(md))
        if md is not None or val is not None:
            missing = "value" if val is None else "metadata"
            raise celpy.CELEvalError(f"variant: cannot convert map to Variant: missing '{missing}' entry")
    if isinstance(v, (str, celtypes.StringType)):
        raise celpy.CELEvalError(
            "variant: cannot convert string to Variant; use variants.parseJson(s) for "
            "strict JSON parsing or variants.tryParseJson(s) for soft mode"
        )
    raise celpy.CELEvalError(f"variant: cannot convert {type(v).__name__} to Variant")


def _variant(*args: typing.Any) -> typing.Optional[Variant]:
    """The ``variant(...)`` constructor. ``variant(dyn)`` runtime-dispatches (CEL null in ->
    CEL null out); ``variant(bytes, bytes)`` builds directly from (value, metadata) bytes."""
    if len(args) == 2:
        metadata = _coerce_bytes(args[1])
        if not metadata:
            # Passing empty metadata explicitly is a rule-authoring mistake rather than an
            # absent field, so it is reported instead of yielding null.
            raise celpy.CELEvalError("variant(value, metadata): metadata is empty, so there is no variant to read")
        return Variant(_coerce_bytes(args[0]), metadata)
    if len(args) != 1:
        raise celpy.CELEvalError(f"variant: expected 1 or 2 args, got {len(args)}")
    return _to_variant(args[0])


def _parse_json(s: typing.Any) -> Variant:
    """``variants.parseJson(string)`` - strict; raises on malformed JSON."""
    if not isinstance(s, (str, celtypes.StringType)):
        raise celpy.CELEvalError("variants.parseJson: expected a string")
    try:
        return vu.parse_json(str(s))
    except (vu.VariantError, ValueError) as ex:
        raise celpy.CELEvalError(f"variants.parseJson: {ex}") from ex


def _try_parse_json(s: typing.Any) -> typing.Optional[Variant]:
    """``variants.tryParseJson(string)`` - soft; CEL null on any parse failure.

    Soft about *parsing*, not about the argument type: Java declares this binding over
    ``String`` exactly as it does the strict form, so a non-string argument is a rule error
    there. Stringifying instead turned ``tryParseJson(123)`` into a numeric variant.
    """
    if not isinstance(s, (str, celtypes.StringType)):
        raise celpy.CELEvalError("variants.tryParseJson: expected a string")
    try:
        return vu.parse_json(str(s))
    except Exception:  # noqa: BLE001 - soft form: any parse failure -> CEL null
        return None


def _type(v: typing.Any) -> typing.Any:
    """``variants.type(Variant)`` - the type label as a string; propagates CEL null."""
    variant = _require_variant_or_null(v, "variants.type")
    if variant is None:
        return None
    return celtypes.StringType(_TYPE_LABELS[variant.get_type()])


def _is_null(o: typing.Any) -> celtypes.BoolType:
    """``variants.isNull(dyn)`` - true iff input is a Variant whose top type is NULL.

    Coerces like every other accessor. ``isinstance(o, Variant)`` alone answered False for the
    shapes a variant-typed *field* decodes to - a celpy MessageType wrapping a
    confluent.type.Variant, or the map an Avro variant record yields - which the dyn declaration
    admits, so a bare variant holding an explicit JSON null reported "not null". CEL null and any
    non-variant stay False rather than raising: this predicate never errors.
    """
    if isinstance(o, Variant):
        return celtypes.BoolType(o.get_type() == VariantType.NULL)
    try:
        coerced = _require_variant_or_null(o, "variants.isNull")
    except Exception:
        return celtypes.BoolType(False)
    return celtypes.BoolType(coerced is not None and coerced.get_type() == VariantType.NULL)


def _require_variant_or_null(o: typing.Any, fn: str) -> typing.Optional[Variant]:
    """A ``variants.*`` navigation argument: CEL null passes through as ``None``; a real
    Variant is returned; anything else is a hard error (the dyn signature lets a misused
    non-Variant reach the binding)."""
    if o is None:
        return None
    if isinstance(o, Variant):
        return o
    # Otherwise accept the shapes a variant-typed *field* decodes to -- a proto
    # confluent.type.Variant message (celpy wraps one as a MessageType), or the mapping an
    # Avro variant record decodes to -- so such a field can be used without a variant(...)
    # call, as on the other clients. An unrecognized shape still gets a clear message.
    try:
        return _to_variant(o)
    except celpy.CELEvalError as ex:
        raise celpy.CELEvalError(f"{fn}: expected Variant, got {type(o).__name__}") from ex
    return o


def _path(o: typing.Any, path: typing.Any) -> typing.Optional[Variant]:
    """``variants.path(dyn, string)`` - navigate a JSONPath subset; CEL null on a miss;
    malformed path raises."""
    # Java declares this `(DYN, STRING)`, so a non-string path has no matching overload there
    # whatever the receiver holds - and Go, JS and C++ enforce it the same way, in the declared
    # overload. celpy has no overload-set concept, so the check has to be explicit; without it
    # `str(path)` looked up the path "1" for variants.path(v, 1). Checked *before* the receiver
    # for the same reason: the argument error does not depend on the receiver's shape, so a
    # null receiver must not turn a mistyped call into CEL null. Same contract as
    # variants.field, variants.index, variants.as and variants.tryAs.
    if not isinstance(path, (str, celtypes.StringType)):
        raise celpy.CELEvalError(f"variants.path: expected a string path, got {type(path).__name__}")
    v = _require_variant_or_null(o, "variants.path")
    if v is None:
        return None
    try:
        return variant_path.walk(v, str(path))
    except ValueError as ex:
        raise celpy.CELEvalError(f"variants.path: {ex}") from ex


def _field(o: typing.Any, key: typing.Any) -> typing.Optional[Variant]:
    """``variants.field(dyn, string)`` - object field by key; CEL null on a miss or a
    non-object receiver."""
    # Java binds this as (Object, String), so a non-string key has no matching overload;
    # str(key) would have looked up "1" for variants.field(v, 1). Same contract as
    # variants.index and variants.parseJson.
    if not isinstance(key, (str, celtypes.StringType)):
        raise celpy.CELEvalError(f"variants.field: expected a string key, got {type(key).__name__}")
    v = _require_variant_or_null(o, "variants.field")
    if v is None or v.get_type() != VariantType.OBJECT:
        return None
    return v.get_field_by_key(str(key))


def _index(o: typing.Any, idx: typing.Any) -> typing.Optional[Variant]:
    """``variants.index(dyn, int)`` - array element by index; CEL null on out-of-bounds or a
    non-array receiver."""
    # The index is checked before the receiver, the way variants.field checks its key. Java
    # declares this overload as (DYN, INT), so a double or a bool fails to bind whatever the
    # receiver turns out to hold; checking the receiver first made the argument's own type
    # depend on it, and `variants.index(anObject, 1.5)` answered CEL null instead of
    # reporting the wrong type. int() would then have quietly floored 1.9 to element 1 and
    # read true as element 1.
    # UintType alongside the bools because it subclasses ``int`` too; the reference declares
    # variants.index as (DYN, INT), so `variants.index(v, 1u)` has no matching overload.
    if isinstance(idx, (bool, celtypes.BoolType, celtypes.UintType)) or not isinstance(idx, (int, celtypes.IntType)):
        raise celpy.CELEvalError(f"variants.index: expected an int index, got {type(idx).__name__}")
    v = _require_variant_or_null(o, "variants.index")
    if v is None or v.get_type() != VariantType.ARRAY:
        return None
    i = int(idx)
    if i < 0 or i > _INT32_MAX:
        return None
    return v.get_element_at_index(i)


# The CEL timestamp range in epoch seconds, matching the reference's
# TimestampUtils.MIN/MAX_EPOCH_SECOND.
_MIN_EPOCH_SECOND = -62135596800
_MAX_EPOCH_SECOND = 253402300799


def _variant_get_timestamp(v: Variant) -> typing.Optional[celtypes.TimestampType]:
    """Backing for ``variants.as(v, 'timestamp')``.

    MICROS-precision variants (TIMESTAMP_TZ/NTZ) store microseconds since the epoch and
    are used as-is. NANOS-precision variants (TIMESTAMP_NANOS_TZ/NTZ) store nanoseconds:
    the Java reference (TimestampUtils.fromEpochNanos) splits them with
    ``Math.floorDiv``/``Math.floorMod`` into (seconds, nanos) and keeps the full
    nanosecond field in a protobuf ``Timestamp``. celpy's ``TimestampType`` is a subclass
    of ``datetime.datetime``, whose finest resolution is one microsecond, so the epoch
    value is floored to microseconds. Python ``//`` is floor division (matching Java
    ``Math.floorDiv``), so pre-epoch (negative) values round toward negative infinity
    exactly as Java does -- e.g. -1 ns -> -1 us, never 0. The only residual difference
    from Java is the sub-microsecond nanoseconds that a ``datetime`` cannot represent;
    this is an inherent limit of the CEL timestamp type, not a rounding discrepancy.

    Returns ``None`` when the value falls outside the CEL timestamp range (0001-9999). A
    variant timestamp spans the whole int64 range, so that is reachable from data; ``None``
    rather than an exception because the caller decides -- ``variants.as`` raises and names the
    range, ``variants.tryAs`` answers CEL null, the same split those two already apply to a type
    mismatch. ``datetime`` cannot represent such a value at all, so the arithmetic below would
    raise ``OverflowError`` and escape ``tryAs`` as well.
    """
    raw = v.get_long()
    micros = raw if v.get_type() in _MICROS_TIMESTAMP_TYPES else raw // 1000
    seconds = micros // 1_000_000
    if seconds < _MIN_EPOCH_SECOND or seconds > _MAX_EPOCH_SECOND:
        return None
    return celtypes.TimestampType(_EPOCH_UTC + timedelta(microseconds=micros))


def _variant_as(o: typing.Any, type_str: str, null_on_error: bool) -> typing.Any:
    """Backing for ``variants.as`` (strict) and ``variants.tryAs`` (soft). Extracts a typed
    value; on a type mismatch the strict form raises and the soft form returns CEL null.
    Types with no CEL extraction (object/array/null/date/time/uuid) always raise."""
    fn = "variants.tryAs" if null_on_error else "variants.as"
    v = _require_variant_or_null(o, fn)
    if v is None:
        return None
    t = v.get_type()
    if type_str == "string":
        if t == VariantType.STRING:
            return celtypes.StringType(v.get_string())
    elif type_str == "int":
        if t in _INT_TYPES:
            return celtypes.IntType(v.get_long())
    elif type_str == "double":
        if t == VariantType.FLOAT:
            return celtypes.DoubleType(float(v.get_float()))
        if t == VariantType.DOUBLE:
            return celtypes.DoubleType(v.get_double())
    elif type_str == "boolean":
        if t == VariantType.BOOLEAN:
            return celtypes.BoolType(v.get_boolean())
    elif type_str == "decimal":
        if t in _DECIMAL_TYPES:
            return v.get_decimal()
    elif type_str == "timestamp":
        if t in _TIMESTAMP_TYPES:
            ts = _variant_get_timestamp(v)
            if ts is not None:
                return ts
            if null_on_error:
                return None
            raise celpy.CELEvalError(
                f"variants.as: timestamp {v.get_long()} is outside "
                "0001-01-01T00:00:00Z..9999-12-31T23:59:59.999999999Z"
            )
    elif type_str == "bytes":
        if t == VariantType.BINARY:
            return celtypes.BytesType(v.get_binary())
    elif type_str in ("object", "array", "null", "date", "time", "uuid"):
        # Not extractable as a CEL scalar - always an error, even in the soft form.
        raise celpy.CELEvalError(
            f"variants.as: type '{type_str}' is not supported for extraction "
            "(use variants.type/variants.path/variants.field/variants.index instead)"
        )
    else:
        if null_on_error:
            return None
        raise celpy.CELEvalError(
            f"variants.as: unknown type '{type_str}' (expected one of: string, int, "
            "double, boolean, decimal, timestamp, bytes)"
        )
    # Recognized type string, but the variant's actual type does not match.
    if null_on_error:
        return None
    raise celpy.CELEvalError(f"variants.as: variant is not {type_str}-typed (type={t.value})")


def _require_type_name(type_str: typing.Any, fn: str) -> str:
    """The type-name argument as a string.

    Java declares both overloads as (DYN, STRING), so a non-string second argument fails to
    bind. `str()` accepted anything, which mattered most for the soft form: `variants.tryAs(v,
    1)` stringified to "1", took the unknown-type branch and returned CEL **null**. Null is
    tryAs's answer for a type *mismatch*, not for a call that names no type at all, so a
    wrong-typed argument was indistinguishable from a variant of the wrong shape.
    """
    if not isinstance(type_str, (str, celtypes.StringType)):
        raise celpy.CELEvalError(f"{fn}: expected a string type name, got {type(type_str).__name__}")
    return str(type_str)


def _as(o: typing.Any, type_str: typing.Any) -> typing.Any:
    """``variants.as(dyn, string)`` - typed extraction; raises on type mismatch."""
    return _variant_as(o, _require_type_name(type_str, "variants.as"), null_on_error=False)


def _try_as(o: typing.Any, type_str: typing.Any) -> typing.Any:
    """``variants.tryAs(dyn, string)`` - typed extraction; CEL null on type mismatch."""
    return _variant_as(o, _require_type_name(type_str, "variants.tryAs"), null_on_error=True)


def _to_json(v: typing.Any) -> typing.Any:
    """``variants.toJson(Variant)`` - serialize to a JSON string; propagates CEL null."""
    variant = _require_variant_or_null(v, "variants.toJson")
    if variant is None:
        return None
    return celtypes.StringType(variant.to_json())


# Typed as Any rather than celpy.CELFunction: these functions return this client's own
# Decimal and Variant values, which are not in celpy's declared return union - the CEL
# surface is extended with opaque types celpy does not know. celpy dispatches them fine
# at runtime; only its annotation is narrower than what an extension can return.
VARIANT_FUNCS: typing.Dict[str, typing.Any] = {
    "variant": _variant,
    "variants.parseJson": _parse_json,
    "variants.tryParseJson": _try_parse_json,
    "variants.type": _type,
    "variants.isNull": _is_null,
    "variants.path": _path,
    "variants.field": _field,
    "variants.index": _index,
    "variants.as": _as,
    "variants.tryAs": _try_as,
    "variants.toJson": _to_json,
}
